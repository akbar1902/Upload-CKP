# CKP Companion — Auto Input

Ekstensi Chrome untuk mengambil daftar CKP (dari SIKAP atau file Excel), menampilkan pratinjau dan validasi, lalu membantu mengisi form kegiatan di KipApp.

## Baru di 0.5.0 — ambil CKP langsung dari SIKAP

Tidak perlu CKP App atau file Excel lagi:

1. Buka panel CKP Companion → kartu **Ambil CKP dari SIKAP** → **Hubungkan SIKAP**.
2. Tab SIKAP terbuka. Login bila diminta, lalu klik **Setujui & hubungkan**. Cukup sekali per Chrome.
3. Pilih **CKP bulan** (versi terbaru yang sudah disubmit di SIKAP) → **Ambil kegiatan**.
4. Buka KipApp → tabel **Pelaksanaan Kinerja** → **Isi & simpan semua kegiatan**.

- Yang diambil hanya CKP milik akun yang menyetujui sambungan; versi arsip tidak pernah diambil.
- Bila CKP yang sama diambil lagi setelah sebagian kegiatan tersimpan, panel menawarkan
  melanjutkan progres agar kegiatan tidak tersimpan dua kali di KipApp.
- Sambungan memakai token integrasi SIKAP (sama seperti CKP App). Cabut kapan saja di
  SIKAP → **All in CKP App** → daftar token, atau klik **Putuskan** di panel.
- Butuh izin tambahan untuk `https://sikap-ckp.vercel.app/*`.

Mulai versi **0.4.0**, ekstensi mendukung **profil pegawai**. Setiap rekan sekantor
punya sesi kegiatan sendiri, dan saat CKP-App mengirim data lewat tombol
**Kirim ke KipApp**, ekstensi otomatis memilih profil yang sesuai. Ini penting
karena RK tiap pegawai berbeda.

## Pasang di Chrome

1. Buka `chrome://extensions`.
2. Aktifkan **Developer mode**.
3. Pilih **Load unpacked**.
4. Pilih folder **ini** (folder yang berisi `manifest.json`, biasanya `ckp-v034` atau `ckp-companion` di dalam paket rekan).
5. Buka `https://kipapp.bps.go.id/`, lalu klik ikon CKP Companion di toolbar untuk membuka panel.

Setelah menerima pembaruan kode ekstensi, klik tombol **Reload** pada kartu CKP Companion di `chrome://extensions`, lalu muat ulang halaman KipApp.

> **Penting:** versi terbaru adalah **0.4.1** dengan profil pegawai. Kalau panel masih
> menampilkan **v0.3.6** atau **0.4.0**, extension lama belum ter-reload. Hapus extension lama,
> lalu **Load unpacked** lagi folder yang berisi `manifest.json` versi 0.4.1.
> Buka CKP App di **Chrome yang sama** (bukan Edge) agar bridge handoff aktif.

Mulai v0.4.1, **Rencana Kinerja diisi paling akhir** setelah field lain selesai. Extension
menunggu dropdown RK benar-benar memuat pilihan (dengan retry buka ulang) supaya tidak
gagal saat daftar RK di KipApp belum siap.

## Profil pegawai

- Di bagian atas panel ada kartu **Profil pegawai**. Klik **Ganti** untuk memilih
  profil rekan, menambah profil baru, mengubah nama, atau menghapus profil.
- Profil dari CKP-App (id, nama, NIP) dibuat otomatis saat handoff, jadi cukup
  pastikan profil yang dipilih di CKP-App sudah benar sebelum klik **Kirim ke KipApp**.
- File Excel yang dipilih manual masuk ke profil yang sedang aktif. Ganti profil
  dulu bila file itu milik rekan lain.
- Handoff otomatis dari CKP-App hanya aktif saat aplikasi dibuka lewat
  `localhost`/`127.0.0.1` (komputer server). Bila CKP-App diakses lewat IP LAN,
  gunakan **Export Excel** lalu pilih file itu di panel.
- Status kegiatan, file, dan progres disimpan terpisah per profil di
  `chrome.storage.local` (`ckp-companion-state-v2:<id-profil>`). Data versi lama
  otomatis dimigrasikan menjadi profil pertama.

## Alur penggunaan

1. Pilih file `.xlsx`, `.xls`, atau `.csv` yang berisi daftar kegiatan.
2. Pilih lembar kerja jika file memiliki beberapa lembar. Buka **Periksa pemetaan kolom** jika ada kolom yang tidak cocok.
3. Pastikan Anda sudah masuk ke tabel **Pelaksanaan Kinerja** di KipApp, lalu klik **Isi & simpan semua kegiatan**.
4. Ekstensi mengisi form, menekan **Save**, lalu melanjutkan ke baris berikutnya sampai selesai.
5. Jika data tidak cocok, kolom gagal terisi, atau KipApp menolak penyimpanan, proses berhenti di baris itu. Perbaiki/periksa form di KipApp; gunakan **Sudah disimpan · lanjut** setelah Anda memastikan kegiatan tersebut sudah tersimpan.

Tanggal mulai dan selesai yang sama akan memakai satu tanggal tanpa mengaktifkan **Gunakan periode tanggal**. Jika tanggalnya berbeda, ekstensi mengaktifkan pilihan periode dan mengisi tanggal mulai serta tanggal selesai.

Ekstensi hanya menekan **Save** jika semua kolom terisi dan terverifikasi. Status tersimpan dicatat setelah KipApp menutup form atau menampilkan konfirmasi sukses. Jika hasil penyimpanan tidak dapat dipastikan, ekstensi berhenti agar tidak mengirim ulang kegiatan yang mungkin sudah tersimpan. File Excel dibaca di browser; status kegiatan disimpan di penyimpanan lokal ekstensi agar panel dapat dibuka kembali.

Mulai versi 0.3.1, kolom teks difokuskan langsung dari elemen form KipApp, lalu diisi dengan input keyboard Chrome. Ekstensi memeriksa bahwa kolom yang fokus sesuai dengan kolom sasaran sebelum mengetik dan memeriksa kembali nilainya setelah form berpotensi dirender ulang. Ini memerlukan izin **Debugger**, yang menampilkan peringatan izin dari Chrome. Kode membatasi pemakaian ke tab `kipapp.bps.go.id` dan melepas sesi debugger setelah tiap input.

Pembaca Excel menggunakan SheetJS Community Edition. Lisensi Apache 2.0 disertakan di `vendor/SHEETJS-LICENSE.txt`.

## Kolom yang dikenali

Tanggal mulai, tanggal selesai, rencana kinerja, kegiatan, progres, capaian, dan bukti dukung. Pemetaan awal mengikuti nama header; jika header tidak terdeteksi, pemetaan mengikuti posisi kolom yang digunakan skrip Auto Input sebelumnya.

## Batasan versi awal

- Ekstensi menargetkan halaman `kipapp.bps.go.id` dan form **Pelaksanaan Kinerja**.
- KipApp dapat mengubah label atau struktur form sewaktu-waktu. Pesan di panel menunjukkan bila kolom belum ditemukan.
- Kolom tanggal selesai akan diisi bila KipApp menampilkan kolom tanggal kedua. Jika form hanya menyediakan satu tanggal, panel memberi peringatan.
