const LEGACY_STORAGE_KEY = 'ckp-companion-state-v1';
const PROFILE_STORAGE_KEY = 'ckp-companion-profiles-v1';
const STATE_KEY_PREFIX = 'ckp-companion-state-v2:';
const EXTENSION_VERSION = chrome.runtime.getManifest().version;
const FIELD_DEFS = [
  { key: 'tanggalMulai', label: 'Tanggal mulai', aliases: ['tanggal mulai', 'tgl mulai', 'tanggal pelaksanaan', 'tanggal'], fallback: 1 },
  { key: 'tanggalSelesai', label: 'Tanggal selesai', aliases: ['tanggal selesai', 'tgl selesai', 'tanggal akhir', 'tgl akhir'], fallback: 2 },
  { key: 'rencanaKinerja', label: 'Rencana kinerja', aliases: ['rencana kinerja skp', 'rencana kinerja', 'rencana kerja'], fallback: 5 },
  { key: 'kegiatan', label: 'Kegiatan', aliases: ['deskripsi kegiatan', 'uraian kegiatan', 'kegiatan'], fallback: 6 },
  { key: 'progres', label: 'Progres', aliases: ['progres', 'progress', 'persentase progres'], fallback: 7 },
  { key: 'capaian', label: 'Capaian', aliases: ['deskripsi capaian', 'capaian', 'hasil capaian'], fallback: 8 },
  { key: 'dataDukung', label: 'Bukti dukung', aliases: ['link data dukung', 'data dukung', 'bukti dukung', 'link bukti', 'evidence'], fallback: 9 }
];

const $ = (selector) => document.querySelector(selector);
const els = {
  versionTag: $('#versionTag'), handoffBanner: $('#handoffBanner'),
  profileAvatar: $('#profileAvatar'), profileName: $('#profileName'), profileNip: $('#profileNip'),
  profileToggle: $('#profileToggle'), profilePanel: $('#profilePanel'), profileSelect: $('#profileSelect'),
  newProfileName: $('#newProfileName'), newProfileNip: $('#newProfileNip'),
  addProfileButton: $('#addProfileButton'), renameProfileButton: $('#renameProfileButton'), deleteProfileButton: $('#deleteProfileButton'),
  importView: $('#importView'), workspaceView: $('#workspaceView'), fileInput: $('#fileInput'), hiddenFileInput: $('#hiddenFileInput'), dropZone: $('#dropZone'), importError: $('#importError'),
  fileName: $('#fileName'), sheetInfo: $('#sheetInfo'), sheetSelect: $('#sheetSelect'), mappingFields: $('#mappingFields'), replaceFileButton: $('#replaceFileButton'), clearSessionButton: $('#clearSessionButton'),
  totalCount: $('#totalCount'), readyCount: $('#readyCount'), doneCount: $('#doneCount'), progressBar: $('#progressBar'), rowNumber: $('#rowNumber'), rowStatus: $('#rowStatus'),
  activityTitle: $('#activityTitle'), activityPlan: $('#activityPlan'), activityDate: $('#activityDate'), activityProgress: $('#activityProgress'), rowWarnings: $('#rowWarnings'),
  filledNotice: $('#filledNotice'), fillButton: $('#fillButton'), openKipappButton: $('#openKipappButton'), markDoneButton: $('#markDoneButton'), actionMessage: $('#actionMessage'),
  previewBody: $('#previewBody'), previewCount: $('#previewCount')
};

function stateKey(profileId) {
  return `${STATE_KEY_PREFIX}${profileId || 'utama'}`;
}
function profilKosong(profile) {
  return {
    fileName: '', sheetNames: [], sheets: [], selectedSheet: '', mapping: {}, records: [], currentIndex: 0,
    handoffSource: '', handoffAt: 0,
    profileId: (profile && profile.id) || '', profileName: (profile && profile.nama) || '', profileNip: (profile && profile.nip) || '',
  };
}

let profil = { profiles: [], activeId: '' };
let state = profilKosong(null);
let busy = false;
let batchProgress = null;

function normalized(value) {
  return String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('id').replace(/[^a-z0-9]+/g, ' ').trim();
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
}

function cellDisplay(cell) {
  if (!cell) return { text: '', url: '', raw: '', format: '' };
  const link = cell.l?.Target || cell.l?.target || cell.l?.Url || cell.l?.url || '';
  const raw = cell.v instanceof Date ? cell.v.toISOString() : (cell.v ?? '');
  const text = link || cell.w || (cell.v instanceof Date ? cell.v.toLocaleDateString('id-ID') : cell.v ?? '');
  return { text: String(text ?? '').trim(), url: String(link || '').trim(), raw, format: String(cell.z || '') };
}

function getMatrix(sheet) {
  if (!sheet?.['!ref']) return [];
  const range = XLSX.utils.decode_range(sheet['!ref']);
  const rows = [];
  for (let row = range.s.r; row <= range.e.r; row += 1) {
    const values = [];
    for (let col = range.s.c; col <= range.e.c; col += 1) {
      values.push(cellDisplay(sheet[XLSX.utils.encode_cell({ r: row, c: col })]));
    }
    rows.push(values);
  }
  return rows;
}

function guessHeaders(matrix) {
  let best = { row: -1, mapping: {}, score: 0 };
  const scanLimit = Math.min(matrix.length, 18);
  for (let row = 0; row < scanLimit; row += 1) {
    const cells = matrix[row] || [];
    const mapping = {};
    for (const field of FIELD_DEFS) {
      const index = cells.findIndex((cell) => {
        const header = normalized(cell.text);
        return field.aliases.some((alias) => header === normalized(alias));
      });
      if (index >= 0) mapping[field.key] = index;
    }
    const score = Object.keys(mapping).length;
    if (score > best.score) best = { row, mapping, score };
  }
  if (best.score >= 3 && (best.mapping.kegiatan !== undefined || best.mapping.rencanaKinerja !== undefined)) return best;
  return { row: -1, mapping: Object.fromEntries(FIELD_DEFS.map((field) => [field.key, field.fallback])), score: 0 };
}

function sheetColumns(sheetData) {
  const row = sheetData.headerRow >= 0 ? sheetData.matrix[sheetData.headerRow] : null;
  return sheetData.matrix[0]?.map((_, index) => {
    const title = row?.[index]?.text;
    return title || `Kolom ${index + 1}`;
  }) || [];
}

function excelDateToIso(cell) {
  const raw = cell?.raw;
  const text = String(cell?.text ?? '').trim();
  if (raw instanceof Date) return raw.toISOString().slice(0, 10);
  if (typeof raw === 'number' && /[dmy]/i.test(cell?.format || '')) {
    const parts = XLSX.SSF.parse_date_code(raw);
    if (parts) return `${parts.y}-${String(parts.m).padStart(2, '0')}-${String(parts.d).padStart(2, '0')}`;
  }
  const iso = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) return `${iso[1]}-${iso[2].padStart(2, '0')}-${iso[3].padStart(2, '0')}`;

  const months = { januari: '01', februari: '02', maret: '03', april: '04', mei: '05', juni: '06', juli: '07', agustus: '08', september: '09', oktober: '10', november: '11', desember: '12' };
  const named = normalized(text).match(/^(\d{1,2})\s+([a-z]+)\s+(\d{4})$/);
  if (named && months[named[2]]) return `${named[3]}-${months[named[2]]}-${named[1].padStart(2, '0')}`;
  const numeric = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (numeric) return `${numeric[3]}-${numeric[2].padStart(2, '0')}-${numeric[1].padStart(2, '0')}`;
  return text;
}

function displayDate(iso) {
  const match = String(iso || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  return match ? `${match[3]}/${match[2]}/${match[1]}` : (iso || 'Tanggal belum diisi');
}

function cellValue(row, columnIndex) {
  if (columnIndex === undefined || columnIndex === null || columnIndex < 0) return null;
  return row?.[columnIndex] || null;
}

function buildRecords(sheetData, mapping, previousRecords = [], savedStatuses = {}) {
  const previousStatuses = new Map(Object.entries(savedStatuses).map(([rowNumber, status]) => [Number(rowNumber), status]));
  previousRecords.forEach((record) => previousStatuses.set(record.rowNumber, record.status));
  const firstDataRow = sheetData.headerRow >= 0 ? sheetData.headerRow + 1 : 0;
  const records = [];
  for (let index = firstDataRow; index < sheetData.matrix.length; index += 1) {
    const row = sheetData.matrix[index] || [];
    if (row.every((cell) => !cell?.text)) continue;
    const values = Object.fromEntries(FIELD_DEFS.map((field) => [field.key, cellValue(row, mapping[field.key])]));
    const stringValue = (cell) => String(cell?.url || cell?.text || '').trim();
    const kegiatan = stringValue(values.kegiatan);
    const rencanaKinerja = stringValue(values.rencanaKinerja);
    const tanggalMulai = values.tanggalMulai ? excelDateToIso(values.tanggalMulai) : '';
    const tanggalSelesai = values.tanggalSelesai ? excelDateToIso(values.tanggalSelesai) : '';
    const progresText = stringValue(values.progres).replace(/\s*%\s*$/, '').replace(',', '.');
    const record = {
      rowNumber: index + 1,
      no: stringValue(row[0]) || String(records.length + 1),
      tanggalMulai,
      tanggalSelesai,
      rencanaKinerja,
      kegiatan,
      progres: progresText,
      capaian: stringValue(values.capaian),
      dataDukung: stringValue(values.dataDukung),
      status: previousStatuses.get(index + 1) || 'pending'
    };
    if (![record.tanggalMulai, record.rencanaKinerja, record.kegiatan, record.progres, record.capaian, record.dataDukung].some(Boolean)) continue;
    record.warnings = [];
    if (!record.tanggalMulai) record.warnings.push('Tanggal mulai belum diisi.');
    if (!record.rencanaKinerja) record.warnings.push('Rencana kinerja belum diisi.');
    if (!record.kegiatan) record.warnings.push('Uraian kegiatan belum diisi.');
    if (!record.progres) record.warnings.push('Progres belum diisi.');
    if (!record.capaian) record.warnings.push('Capaian belum diisi.');
    if (!record.dataDukung) record.warnings.push('Tautan bukti dukung belum diisi.');
    records.push(record);
  }
  return records;
}

async function simpanRegistry() {
  // activeId hanya diubah oleh aksi eksplisit (ganti/tambah profil/handoff),
  // bukan oleh persist biasa — supaya handoff tidak tertimpa sesi lama.
  await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profil });
}

async function persist() {
  try {
    state.extensionVersion = EXTENSION_VERSION;
    state.profileId = state.profileId || profil.activeId || '';
    state.profileName = state.profileName || (profil.profiles.find((p) => p.id === state.profileId) || {}).nama || '';
    state.profileNip = state.profileNip || (profil.profiles.find((p) => p.id === state.profileId) || {}).nip || '';
    state.statusesBySheet ||= {};
    if (state.selectedSheet) state.statusesBySheet[state.selectedSheet] = Object.fromEntries(state.records.map((record) => [record.rowNumber, record.status]));
    await chrome.storage.local.set({ [stateKey(state.profileId)]: state });
    await simpanRegistry();
  } catch (error) { showActionMessage(`Status sesi belum tersimpan di ekstensi: ${error.message}`, true); }
}

function profilAktif() {
  return profil.profiles.find((p) => p.id === profil.activeId) || profil.profiles[0] || null;
}

function idProfilBaru(nama) {
  const dasar = String(nama || 'pegawai').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 28) || 'pegawai';
  let id = `ext-${dasar}`;
  let n = 1;
  while (profil.profiles.some((p) => p.id === id)) id = `ext-${dasar}-${++n}`;
  return id;
}

async function muatProfilRegistry() {
  const saved = await chrome.storage.local.get([PROFILE_STORAGE_KEY, LEGACY_STORAGE_KEY]);
  let reg = saved[PROFILE_STORAGE_KEY];
  if (!reg || !Array.isArray(reg.profiles) || !reg.profiles.length) {
    // Migrasi dari versi lama: satu sesi menjadi satu profil.
    const lama = saved[LEGACY_STORAGE_KEY];
    const namaLama = (lama && lama.profileName) || 'Pegawai 1';
    const profile = { id: 'utama', nama: namaLama, nip: (lama && lama.profileNip) || '' };
    reg = { profiles: [profile], activeId: profile.id };
    if (lama) {
      const isi = { ...lama, profileId: profile.id, profileName: profile.nama, profileNip: profile.nip };
      await chrome.storage.local.set({ [stateKey(profile.id)]: isi });
    }
    await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: reg });
  }
  profil = reg;
  if (!profil.profiles.some((p) => p.id === profil.activeId)) profil.activeId = profil.profiles[0].id;
  return profil;
}

async function muatStateProfil(profileId) {
  const key = stateKey(profileId);
  const saved = await chrome.storage.local.get(key);
  const p = profil.profiles.find((x) => x.id === profileId) || null;
  const isi = saved[key];
  if (isi && typeof isi === 'object') {
    state = { ...profilKosong(p), ...isi, profileId, profileName: p ? p.nama : (isi.profileName || ''), profileNip: p ? p.nip : (isi.profileNip || '') };
    state.statusesBySheet ||= {};
    if (!Array.isArray(state.records)) state.records = [];
  } else {
    state = profilKosong(p);
    state.profileId = profileId;
  }
  return state;
}

async function gantiProfil(profileId, { pesan = true } = {}) {
  if (!profileId) return;
  if (busy) return showActionMessage('Selesaikan proses pengisian yang sedang berjalan sebelum ganti profil.', true);
  const p = profil.profiles.find((x) => x.id === profileId);
  if (!p) return;
  if (state.profileId) await persist();
  profil.activeId = profileId;
  await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profil });
  await muatStateProfil(profileId);
  clearActionMessage();
  render();
  if (pesan) showActionMessage(`Profil aktif: ${p.nama}. Sesi kegiatan tiap pegawai disimpan terpisah.`);
}

async function tambahProfil(nama, nip) {
  const namaBersih = String(nama || '').replace(/\s+/g, ' ').trim().slice(0, 120);
  if (!namaBersih) return showActionMessage('Nama rekan belum diisi.', true);
  const profile = { id: idProfilBaru(namaBersih), nama: namaBersih, nip: String(nip || '').trim().slice(0, 40) };
  profil.profiles.push(profile);
  await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profil });
  await gantiProfil(profile.id, { pesan: false });
  showActionMessage(`Profil ${profile.nama} ditambahkan dan langsung dipakai.`);
}

async function ubahNamaProfil() {
  const p = profilAktif();
  if (!p) return;
  const nama = window.prompt('Nama profil pegawai:', p.nama);
  if (nama === null) return;
  const namaBersih = String(nama).replace(/\s+/g, ' ').trim();
  if (!namaBersih) return showActionMessage('Nama profil tidak boleh kosong.', true);
  p.nama = namaBersih.slice(0, 120);
  state.profileName = p.nama;
  await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profil });
  await persist();
  render();
  showActionMessage(`Nama profil diubah menjadi ${p.nama}.`);
}

async function hapusProfilAktif() {
  if (profil.profiles.length <= 1) return showActionMessage('Minimal harus ada satu profil pegawai.', true);
  const p = profilAktif();
  if (!p) return;
  if (!confirm(`Hapus profil “${p.nama}”? Sesi kegiatan yang belum selesai untuk profil ini ikut terhapus.`)) return;
  profil.profiles = profil.profiles.filter((x) => x.id !== p.id);
  await chrome.storage.local.remove(stateKey(p.id));
  profil.activeId = profil.profiles[0].id;
  await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: profil });
  await muatStateProfil(profil.activeId);
  clearActionMessage();
  render();
  showActionMessage(`Profil ${p.nama} dihapus. Sekarang memakai ${profilAktif().nama}.`);
}

function showActionMessage(message, isError = false) {
  els.actionMessage.textContent = message;
  els.actionMessage.classList.toggle('error', isError);
  els.actionMessage.classList.remove('hidden');
}

function clearActionMessage() {
  els.actionMessage.classList.add('hidden');
  els.actionMessage.classList.remove('error');
}

function renderMapping() {
  const sheetData = state.sheets.find((sheet) => sheet.name === state.selectedSheet);
  if (!sheetData) return;
  const columns = sheetColumns(sheetData);
  els.mappingFields.innerHTML = FIELD_DEFS.map((field) => {
    const selected = state.mapping[field.key];
    const options = ['<option value="">Tidak dipakai</option>'].concat(columns.map((column, index) => `<option value="${index}" ${index === selected ? 'selected' : ''}>${escapeHtml(column)}</option>`));
    return `<label>${escapeHtml(field.label)}<select data-map-field="${field.key}">${options.join('')}</select></label>`;
  }).join('');
  els.mappingFields.querySelectorAll('select').forEach((select) => select.addEventListener('change', () => {
    if (busy) return;
    const field = select.dataset.mapField;
    state.mapping[field] = select.value === '' ? null : Number(select.value);
    state.records = buildRecords(sheetData, state.mapping, state.records);
    state.currentIndex = Math.min(state.currentIndex, Math.max(0, state.records.length - 1));
    persist();
    render();
  }));
  els.mappingFields.querySelectorAll('select').forEach((select) => { select.disabled = busy; });
}

function renderPreview() {
  els.previewCount.textContent = `${state.records.length} baris`;
  if (!state.records.length) {
    els.previewBody.innerHTML = '<tr><td colspan="3"><div class="empty-complete">Belum ada baris kegiatan yang terbaca. Periksa pemetaan kolom.</div></td></tr>';
    return;
  }
  els.previewBody.innerHTML = state.records.map((record, index) => {
    const status = record.status === 'done' ? ['done', 'Tersimpan'] : record.status === 'filled' ? ['filled', 'Periksa'] : record.warnings.length ? ['', 'Cek data'] : ['', 'Menunggu'];
    return `<tr data-index="${index}" class="${index === state.currentIndex ? 'selected' : ''}"><td>${escapeHtml(record.no)}</td><td><div class="table-activity" title="${escapeHtml(record.kegiatan)}">${escapeHtml(record.kegiatan || '(Kegiatan belum diisi)')}</div></td><td><span class="table-status ${status[0]}">${status[1]}</span></td></tr>`;
  }).join('');
  els.previewBody.querySelectorAll('tr[data-index]').forEach((row) => row.addEventListener('click', () => {
    if (busy) return;
    state.currentIndex = Number(row.dataset.index);
    persist();
    clearActionMessage();
    render();
  }));
}

function renderCurrent() {
  const record = state.records[state.currentIndex];
  const doneCount = state.records.filter((item) => item.status === 'done').length;
  const pendingCount = state.records.filter((item) => item.status === 'pending').length;
  const filledCount = state.records.filter((item) => item.status === 'filled').length;
  const isComplete = state.records.length > 0 && doneCount === state.records.length;

  els.totalCount.textContent = String(state.records.length);
  els.readyCount.textContent = String(pendingCount + filledCount);
  els.doneCount.textContent = String(doneCount);
  els.progressBar.style.width = `${state.records.length ? (doneCount / state.records.length) * 100 : 0}%`;
  els.currentCard = $('#currentCard');

  if (isComplete) {
    els.rowNumber.textContent = 'BULAN INI';
    els.rowStatus.textContent = 'Selesai';
    els.rowStatus.className = 'status-pill status-done';
    els.activityTitle.textContent = 'Semua kegiatan sudah ditandai tersimpan';
    els.activityPlan.textContent = `Anda sudah melewati ${state.records.length} kegiatan dari file ini.`;
    els.activityDate.textContent = 'CKP bulanan';
    els.activityProgress.textContent = 'Selesai';
    els.rowWarnings.classList.add('hidden');
    els.filledNotice.classList.add('hidden');
    els.fillButton.disabled = true;
    els.fillButton.innerHTML = '<span>Semua kegiatan selesai</span><span class="button-arrow" aria-hidden="true">✓</span>';
    els.markDoneButton.classList.add('hidden');
    return;
  }

  if (!record) {
    els.activityTitle.textContent = 'Belum ada kegiatan yang bisa ditampilkan';
    return;
  }
  els.rowNumber.textContent = `KEGIATAN ${record.no || state.currentIndex + 1}`;
  els.activityTitle.textContent = record.kegiatan || 'Uraian kegiatan belum diisi';
  els.activityPlan.textContent = record.rencanaKinerja ? `Rencana kinerja · ${record.rencanaKinerja}` : 'Rencana kinerja belum diisi';
  const isDateRange = Boolean(record.tanggalMulai && record.tanggalSelesai && record.tanggalMulai !== record.tanggalSelesai);
  els.activityDate.textContent = record.tanggalMulai ? `${displayDate(record.tanggalMulai)}${isDateRange ? ` – ${displayDate(record.tanggalSelesai)}` : ''}` : 'Tanggal belum diisi';
  els.activityProgress.textContent = `Progres ${record.progres || '—'}${record.progres && !record.progres.endsWith('%') ? '%' : ''}`;

  if (record.status === 'done') {
    els.rowStatus.textContent = 'Tersimpan';
    els.rowStatus.className = 'status-pill status-done';
    els.fillButton.disabled = busy;
    els.fillButton.innerHTML = '<span>Lanjutkan kegiatan berikutnya</span><span class="button-arrow" aria-hidden="true">→</span>';
  } else if (record.status === 'filled') {
    els.rowStatus.textContent = record.warnings.length ? 'Perlu diperiksa' : 'Periksa & simpan';
    els.rowStatus.className = `status-pill ${record.warnings.length ? 'status-warning' : 'status-filled'}`;
    els.fillButton.disabled = true;
    els.fillButton.innerHTML = record.warnings.length
      ? '<span>Periksa isian di KipApp</span><span class="button-arrow" aria-hidden="true">!</span>'
      : '<span>Form sudah terisi di KipApp</span><span class="button-arrow" aria-hidden="true">✓</span>';
  } else if (record.warnings.length) {
    els.rowStatus.textContent = 'Periksa data';
    els.rowStatus.className = 'status-pill status-warning';
    els.fillButton.disabled = true;
    els.fillButton.innerHTML = `<span>${busy ? batchButtonLabel() : 'Periksa data Excel'}</span><span class="button-arrow" aria-hidden="true">${busy ? '…' : '!'}</span>`;
  } else {
    els.rowStatus.textContent = 'Menunggu';
    els.rowStatus.className = 'status-pill status-ready';
    els.fillButton.disabled = busy;
    els.fillButton.innerHTML = `<span>${busy ? batchButtonLabel() : 'Isi & simpan semua kegiatan'}</span><span class="button-arrow" aria-hidden="true">${busy ? '…' : '→'}</span>`;
  }

  els.rowWarnings.innerHTML = record.warnings.length ? `<strong>Perlu diperiksa</strong><br>${record.warnings.map(escapeHtml).join('<br>')}` : '';
  els.rowWarnings.classList.toggle('hidden', record.warnings.length === 0);
  els.filledNotice.classList.toggle('hidden', record.status !== 'filled');
  els.markDoneButton.classList.toggle('hidden', record.status !== 'filled' || busy);
}

function batchButtonLabel() {
  return batchProgress ? `Kegiatan ${batchProgress.current} dari ${batchProgress.total}…` : 'Menyiapkan…';
}

// Versi banner selalu ikut manifest (tidak hardcode lagi).
if (els.versionTag) els.versionTag.textContent = `v${EXTENSION_VERSION}`;

function renderProfil() {
  const p = profilAktif();
  const nama = (p && p.nama) || 'Pegawai';
  if (els.profileAvatar) els.profileAvatar.textContent = (nama.trim()[0] || '?').toUpperCase();
  if (els.profileName) els.profileName.textContent = nama;
  if (els.profileNip) els.profileNip.textContent = p && p.nip ? `NIP ${p.nip}` : 'NIP belum diisi';
  if (els.profileSelect) {
    els.profileSelect.innerHTML = profil.profiles.map((x) => `<option value="${escapeHtml(x.id)}" ${x.id === profil.activeId ? 'selected' : ''}>${escapeHtml(x.nama)}${x.nip ? ` · ${escapeHtml(x.nip)}` : ''}</option>`).join('');
    els.profileSelect.value = profil.activeId;
  }
  if (els.deleteProfileButton) els.deleteProfileButton.disabled = profil.profiles.length <= 1;
}

function renderHandoffBanner() {
  const banner = els.handoffBanner;
  if (!banner) return;
  if ((state.handoffSource === 'ckp-app-web' || state.handoffSource === 'sikap') && state.records?.length) {
    const kapan = state.handoffAt ? new Date(state.handoffAt).toLocaleString('id-ID', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
    const siap = state.records.filter((r) => r.status !== 'done').length;
    const untuk = state.profileName ? ` untuk <strong>${escapeHtml(state.profileName)}</strong>` : '';
    const judul = state.handoffSource === 'sikap' ? 'Diambil dari SIKAP ✓' : 'Terhubung ke CKP-App ✓';
    banner.innerHTML = `<span><strong>${judul}</strong>${escapeHtml(state.records.length)} kegiatan masuk${untuk}${kapan ? ` · ${escapeHtml(kapan)}` : ''} · ${siap} siap diisi ke KipApp.</span><button type="button" id="handoffHide" aria-label="Tutup">✕</button>`;
    banner.classList.remove('hidden');
    banner.querySelector('#handoffHide')?.addEventListener('click', async () => {
      state.handoffSource = '';
      banner.classList.add('hidden');
      persist();
    });
  } else {
    banner.classList.add('hidden');
    banner.innerHTML = '';
  }
}

function render() {
  const hasFile = Boolean(state.fileName && state.sheets.length);
  renderProfil();
  els.importView.classList.toggle('hidden', hasFile);
  els.workspaceView.classList.toggle('hidden', !hasFile);
  els.fileName.textContent = state.fileName || 'Daftar kegiatan';
  els.sheetInfo.textContent = `${state.records.length} kegiatan terbaca${state.profileName ? ` · ${state.profileName}` : ''}`;
  els.replaceFileButton.disabled = busy;
  els.sheetSelect.disabled = busy;
  els.openKipappButton.disabled = busy;
  els.sheetSelect.innerHTML = state.sheets.map((sheet) => `<option value="${escapeHtml(sheet.name)}" ${sheet.name === state.selectedSheet ? 'selected' : ''}>${escapeHtml(sheet.name)}</option>`).join('');
  if (hasFile) renderMapping();
  renderHandoffBanner();
  renderCurrent();
  renderPreview();
}

async function parseFile(file) {
  els.importError.classList.add('hidden');
  if (!file) return;
  const previousState = state;
  try {
    const data = new Uint8Array(await file.arrayBuffer());
    const workbook = XLSX.read(data, { type: 'array', cellDates: false });
    const sheets = workbook.SheetNames.map((name) => {
      const matrix = getMatrix(workbook.Sheets[name]);
      const guessed = guessHeaders(matrix);
      return { name, matrix, headerRow: guessed.row, guessedMapping: guessed.mapping };
    });
    const selected = sheets[0];
    if (!selected || !selected.matrix.length) throw new Error('File tidak memiliki lembar kerja berisi data.');
    const p = profilAktif();
    const nextState = {
      fileName: file.name,
      sheetNames: workbook.SheetNames,
      sheets,
      selectedSheet: selected.name,
      mapping: { ...selected.guessedMapping },
      records: buildRecords(selected, selected.guessedMapping),
      statusesBySheet: {},
      currentIndex: 0,
      handoffSource: '',
      handoffAt: 0,
      profileId: (p && p.id) || profil.activeId || '',
      profileName: (p && p.nama) || '',
      profileNip: (p && p.nip) || '',
    };
    if (!nextState.records.length) throw new Error('Belum ada baris kegiatan yang dikenali. Periksa lembar dan pemetaan kolom.');
    state = nextState;
    await persist();
    clearActionMessage();
    render();
  } catch (error) {
    state = previousState;
    const message = `File belum bisa dibaca: ${error.message || 'format file tidak dikenal.'}`;
    if (state.fileName) showActionMessage(message, true);
    else {
      els.importError.textContent = message;
      els.importError.classList.remove('hidden');
    }
  }
}

function selectSheet(name) {
  const selected = state.sheets.find((sheet) => sheet.name === name);
  if (!selected) return;
  state.statusesBySheet ||= {};
  if (state.selectedSheet) state.statusesBySheet[state.selectedSheet] = Object.fromEntries(state.records.map((record) => [record.rowNumber, record.status]));
  state.selectedSheet = name;
  state.mapping = { ...selected.guessedMapping };
  state.records = buildRecords(selected, state.mapping, [], state.statusesBySheet[name] || {});
  state.currentIndex = 0;
  state.handoffSource = '';
  state.handoffAt = 0;
  clearActionMessage();
  persist();
  render();
}

async function getKipappTab() {
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (active?.url?.startsWith('https://kipapp.bps.go.id/')) return active;
  const [existing] = await chrome.tabs.query({ url: 'https://kipapp.bps.go.id/*' });
  if (existing) {
    await chrome.tabs.update(existing.id, { active: true });
    return existing;
  }
  const created = await chrome.tabs.create({ url: 'https://kipapp.bps.go.id/' });
  return { ...created, justOpened: true };
}

async function sendFillMessage(tab, record) {
  try {
    return await chrome.tabs.sendMessage(tab.id, { type: 'CKP_FILL_ROW', row: record });
  } catch {
    await new Promise((resolve) => setTimeout(resolve, 800));
    return chrome.tabs.sendMessage(tab.id, { type: 'CKP_FILL_ROW', row: record });
  }
}

function pendingOrder() {
  const count = state.records.length;
  if (!count) return [];
  let start = state.records.findIndex((record, index) => index >= state.currentIndex && record.status !== 'done');
  if (start < 0) start = state.records.findIndex((record) => record.status !== 'done');
  if (start < 0) return [];
  return Array.from({ length: count }, (_, offset) => (start + offset) % count)
    .filter((index) => state.records[index].status !== 'done');
}

async function runBatch() {
  if (busy) return;
  const order = pendingOrder();
  if (!order.length) {
    render();
    return;
  }
  clearActionMessage();
  busy = true;
  batchProgress = { current: 1, total: order.length };
  state.currentIndex = order[0];
  render();
  let savedThisRun = 0;
  try {
    const tab = await getKipappTab();
    if (tab.justOpened) {
      showActionMessage('KipApp dibuka. Login dan masuk ke tabel Pelaksanaan Kinerja, lalu jalankan “Isi & simpan semua kegiatan” lagi.');
      return;
    }
    for (let position = 0; position < order.length; position += 1) {
      const record = state.records[order[position]];
      state.currentIndex = order[position];
      batchProgress = { current: position + 1, total: order.length };
      renderCurrent();
      await persist();

      if (record.status === 'filled') {
        showActionMessage(`Kegiatan ${record.no} sudah pernah diisi dan menunggu pemeriksaan. Periksa atau simpan di KipApp, lalu tandai “Sudah disimpan · lanjut” sebelum menjalankan daftar lagi.`);
        break;
      }
      if (record.warnings?.length) {
        showActionMessage(`Kegiatan ${record.no} belum diproses karena data Excel perlu dilengkapi: ${record.warnings.join(' ')}`, true);
        break;
      }

      let fillResponse;
      try {
        fillResponse = await sendFillMessage(tab, record);
      } catch (error) {
        record.status = 'filled';
        record.warnings = [`Status pengisian belum dapat dipastikan. Periksa form KipApp sebelum mencoba lagi. ${error.message || ''}`.trim()];
        await persist();
        showActionMessage(record.warnings[0], true);
        break;
      }
      if (!fillResponse?.ok) {
        record.status = 'filled';
        record.warnings = [fillResponse?.error || 'KipApp belum merespons. Periksa form sebelum melanjutkan.'];
        await persist();
        showActionMessage(record.warnings[0], true);
        break;
      }

      record.status = 'filled';
      record.warnings = [...new Set([...(record.warnings || []), ...(fillResponse.warnings || [])])];
      await persist();
      renderCurrent();
      if (record.warnings.length) {
        showActionMessage(`Kegiatan ${record.no} berhenti untuk diperiksa: ${record.warnings.join(' ')}`, true);
        break;
      }

      showActionMessage(`Menyimpan kegiatan ${position + 1} dari ${order.length}…`);
      let saveResponse;
      try {
        saveResponse = await chrome.tabs.sendMessage(tab.id, { type: 'CKP_SAVE_ROW' });
      } catch (error) {
        record.warnings = [`Hasil klik simpan belum dapat dipastikan. Periksa KipApp sebelum mengulang agar tidak menyimpan duplikat. ${error.message || ''}`.trim()];
        await persist();
        showActionMessage(record.warnings[0], true);
        break;
      }
      if (!saveResponse?.ok) {
        record.warnings = [saveResponse?.error || 'KipApp belum mengonfirmasi penyimpanan. Periksa form sebelum melanjutkan.'];
        await persist();
        showActionMessage(record.warnings[0], true);
        break;
      }

      record.status = 'done';
      record.warnings = [];
      savedThisRun += 1;
      const nextIndex = order[position + 1];
      if (nextIndex !== undefined) state.currentIndex = nextIndex;
      await persist();
      render();
      if (nextIndex !== undefined) await new Promise((resolve) => setTimeout(resolve, 450));
    }
    const remaining = state.records.some((record) => record.status !== 'done');
    if (!remaining) {
      showActionMessage(`${savedThisRun ? `${savedThisRun} kegiatan berhasil diisi dan disimpan.` : 'Semua kegiatan sudah tersimpan.'}`);
    }
  } catch (error) {
    showActionMessage(error.message || 'Tidak berhasil memproses daftar kegiatan.', true);
  } finally {
    busy = false;
    batchProgress = null;
    render();
  }
}

async function confirmSaved() {
  const record = state.records[state.currentIndex];
  if (!record || record.status !== 'filled') return;
  record.status = 'done';
  const next = state.records.findIndex((item, index) => index > state.currentIndex && item.status !== 'done');
  if (next >= 0) state.currentIndex = next;
  else {
    const earlierPending = state.records.findIndex((item) => item.status !== 'done');
    if (earlierPending >= 0) state.currentIndex = earlierPending;
  }
  await persist();
  clearActionMessage();
  render();
}

async function openKipapp() {
  const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (tabs[0]?.url?.startsWith('https://kipapp.bps.go.id/')) return;
  await chrome.tabs.create({ url: 'https://kipapp.bps.go.id/' });
  showActionMessage('KipApp dibuka di tab baru. Login dan masuk ke tabel Pelaksanaan Kinerja.');
}

els.fileInput.addEventListener('change', (event) => {
  const file = event.target.files?.[0];
  event.target.value = '';
  parseFile(file);
});
els.hiddenFileInput.addEventListener('change', (event) => parseFile(event.target.files?.[0]));
els.replaceFileButton.addEventListener('click', () => els.hiddenFileInput.click());
els.clearSessionButton.addEventListener('click', async () => {
  if (busy) return;
  if (!confirm('Hapus sesi profil ini dan mulai dari kosong?')) return;
  const id = state.profileId;
  state = profilKosong(profilAktif());
  state.profileId = id;
  await chrome.storage.local.remove(stateKey(id));
  clearActionMessage();
  render();
});
els.sheetSelect.addEventListener('change', (event) => selectSheet(event.target.value));
els.fillButton.addEventListener('click', runBatch);
els.markDoneButton.addEventListener('click', confirmSaved);
els.openKipappButton.addEventListener('click', openKipapp);

// Profil pegawai — tiap rekan punya sesi tersendiri.
els.profileToggle?.addEventListener('click', () => {
  const buka = els.profilePanel.classList.contains('hidden');
  els.profilePanel.classList.toggle('hidden', !buka);
  els.profileToggle.setAttribute('aria-expanded', String(buka));
});
els.profileSelect?.addEventListener('change', (event) => gantiProfil(event.target.value));
els.addProfileButton?.addEventListener('click', async () => {
  await tambahProfil(els.newProfileName.value, els.newProfileNip.value);
  els.newProfileName.value = '';
  els.newProfileNip.value = '';
});
els.renameProfileButton?.addEventListener('click', ubahNamaProfil);
els.deleteProfileButton?.addEventListener('click', hapusProfilAktif);

els.dropZone.addEventListener('keydown', (event) => {
  if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); els.fileInput.click(); }
});
els.dropZone.addEventListener('dragover', (event) => { event.preventDefault(); els.dropZone.classList.add('dragging'); });
els.dropZone.addEventListener('dragleave', () => els.dropZone.classList.remove('dragging'));
els.dropZone.addEventListener('drop', (event) => {
  event.preventDefault();
  els.dropZone.classList.remove('dragging');
  parseFile(event.dataTransfer.files?.[0]);
});
els.hiddenFileInput.addEventListener('click', (event) => { event.currentTarget.value = ''; });

(async () => {
  await muatProfilRegistry();
  await muatStateProfil(profil.activeId);
  const previousVersion = state.extensionVersion || '0.0.0';
  state.statusesBySheet ||= {};
  if (!Array.isArray(state.records)) state.records = [];
  let retryableRows = 0;
  if (previousVersion !== EXTENSION_VERSION) {
    for (const record of state.records) {
      const wasInputFailure = record.status === 'filled' && (record.warnings || []).some((warning) =>
        /belum cocok dengan data Excel di form KipApp|nilai form tidak bertahan|nilai textarea tidak bertahan|handler React tidak terdeteksi|belum menyimpan teks setelah input/i.test(warning)
      );
      if (wasInputFailure) {
        record.status = 'pending';
        record.warnings = [];
        retryableRows += 1;
      }
    }
  }
  state.extensionVersion = EXTENSION_VERSION;
  await persist();
  render();
  if (retryableRows) showActionMessage(`Versi ${EXTENSION_VERSION} siap. ${retryableRows} baris yang sebelumnya gagal mengisi kolom dibuka kembali; file Excel tetap tersimpan.`);
})().catch((error) => showActionMessage(`Gagal memuat sesi ekstensi: ${error.message}`, true));

// Handoff live: background ping saat user klik "Kirim ke KipApp" di CKP-App
// dan panel sedang terbuka → muat ulang tanpa buka-tutup panel.
// Profil yang dikirim CKP-App otomatis dipilih agar sesi rekan tidak tercampur.
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== 'CKP_HANDOFF_LIVE') return false;
  (async () => {
    await muatProfilRegistry();
    const target = message.profileId && profil.profiles.some((p) => p.id === message.profileId)
      ? message.profileId
      : profil.activeId;
    await muatStateProfil(target);
    state.currentIndex = 0;
    clearActionMessage();
    render();
    const untuk = message.profileName || state.profileName || '';
    const asal = state.handoffSource === 'sikap' ? 'Diambil dari SIKAP' : 'Terhubung ke CKP-App';
    showActionMessage(`${asal}${untuk ? ` (profil ${untuk})` : ''}: ${message.saved || state.records.length} kegiatan masuk, siap diisi ke KipApp.`);
    sendResponse({ ok: true });
  })();
  return true;
});
