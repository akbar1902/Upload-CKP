(() => {
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  async function waitForCondition(predicate, { timeout = 6000, interval = 150 } = {}) {
    const deadline = Date.now() + timeout;
    while (Date.now() < deadline) {
      try {
        const value = predicate();
        if (value) return value;
      } catch {
        /* elemen bisa hilang saat React render ulang */
      }
      await sleep(interval);
    }
    return null;
  }

  const isVisible = (element) => {
    if (!(element instanceof Element)) return false;
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  };
  const normalize = (value) => String(value || '').normalize('NFKC').replace(/\s+/g, ' ').trim().toLocaleLowerCase('id');

  function getDialog() {
    const candidates = [...document.querySelectorAll('[role="dialog"], .ant-modal, .modal')].filter(isVisible);
    return candidates.at(-1) || document;
  }

  function setValue(element, value) {
    if (!element || value === undefined || value === null || String(value) === '') return false;
    const prototype = element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;
    if (setter) setter.call(element, String(value));
    else element.value = String(value);
    element.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: String(value) }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    element.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  }

  function dismissDatePopup(scope) {
    const activityField = findByPlaceholder(scope, /deskripsi kegiatan|kegiatan/i);
    if (activityField) {
      activityField.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      activityField.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      activityField.click();
      activityField.focus();
    }
  }

  function visibleInputs(scope) {
    return [...scope.querySelectorAll('input, textarea')].filter((input) => isVisible(input) && !['checkbox', 'radio', 'button', 'submit'].includes(input.type));
  }

  function findByPlaceholder(scope, pattern) {
    return visibleInputs(scope).filter((input) => pattern.test(input.placeholder || input.getAttribute('aria-label') || '')).at(-1) || null;
  }

  async function typeTextAsUser(input, value) {
    input.scrollIntoView({ block: 'center', inline: 'nearest' });
    await sleep(60);
    const rect = input.getBoundingClientRect();
    if (!isVisible(input) || rect.width < 4 || rect.height < 4) return { ok: false, error: 'Kolom tidak terlihat untuk menerima input keyboard.' };
    const targetHint = input.getAttribute('placeholder') || input.getAttribute('aria-label') || input.getAttribute('name') || '';
    try {
      input.focus({ preventScroll: true });
      if (typeof input.select === 'function') input.select();
    } catch {
      // CDP Ctrl+A below remains the selection fallback for number inputs.
    }
    if (document.activeElement !== input) return { ok: false, error: `Kolom “${targetHint || 'tanpa label'}” tidak menerima fokus.` };

    let response;
    try {
      response = await chrome.runtime.sendMessage({
        type: 'CKP_NATIVE_TEXT_INPUT',
        text: String(value),
        targetHint
      });
    } catch (error) {
      return { ok: false, error: error.message || 'Chrome tidak dapat mengirim input keyboard.' };
    }
    if (!response?.ok) return { ok: false, error: response?.error || 'Chrome tidak dapat mengetik ke kolom.' };
    await sleep(100);
    let currentInput = input;
    if (!currentInput.isConnected) {
      const candidates = visibleInputs(getDialog());
      currentInput = candidates.find((candidate) => targetHint && (
        candidate.getAttribute('placeholder') === targetHint ||
        candidate.getAttribute('aria-label') === targetHint ||
        candidate.getAttribute('name') === targetHint
      )) || null;
    }
    const actual = String(currentInput?.value || '').trim();
    const expected = String(value).trim();
    const matches = actual === expected || (currentInput?.type === 'number' && Number(actual) === Number(expected));
    return matches
      ? { ok: true }
      : { ok: false, error: `Kolom “${targetHint || 'tanpa label'}” belum menyimpan teks setelah input (terbaca ${actual.length} karakter).` };
  }


  function findFieldByLabel(scope, labelPattern) {
    const clean = (text) => String(text || '').replace(/[*:：]/g, '').replace(/\s+/g, ' ').trim();
    const isField = (el) => el && /^(INPUT|TEXTAREA)$/.test(el.tagName) && !['checkbox', 'radio', 'hidden', 'button', 'submit'].includes(el.type);
    // 1) Ant Design labels carry for="form-add_<field>" which points straight at the control.
    for (const label of scope.querySelectorAll('label[for]')) {
      if (!labelPattern.test(clean(label.textContent))) continue;
      const target = document.getElementById(label.getAttribute('for'));
      if (isField(target)) return target;
    }
    // 2) The label and its control share one .ant-form-item container (works in desktop and mobile layouts).
    for (const item of scope.querySelectorAll('.ant-form-item')) {
      const labelEl = item.querySelector('.ant-form-item-label label, label');
      if (!labelEl || !labelPattern.test(clean(labelEl.textContent))) continue;
      const control = [...item.querySelectorAll('textarea, input')].find(isField);
      if (control) return control;
    }
    // 3) Fallback: nearest control to the right of / below the label text.
    const labels = [...scope.querySelectorAll('label, span, div, p, td, th')].filter((element) => (
      isVisible(element) && !element.querySelector('input, textarea') && clean(element.textContent).length < 40 && labelPattern.test(clean(element.textContent))
    ));
    const fields = visibleInputs(scope);
    let best = null;
    for (const label of labels) {
      const lr = label.getBoundingClientRect();
      for (const field of fields) {
        const fr = field.getBoundingClientRect();
        const sameRow = lr.top + lr.height / 2 >= fr.top - 12 && lr.top + lr.height / 2 <= fr.bottom + 12 && fr.left >= lr.right - 8;
        const below = fr.top >= lr.bottom - 4 && fr.top - lr.bottom < 90 && Math.abs(fr.left - lr.left) < 40;
        if (!sameRow && !below) continue;
        const distance = sameRow ? fr.left - lr.right : (fr.top - lr.bottom) + 200;
        if (!best || distance < best.distance) best = { field, distance };
      }
    }
    return best?.field || null;
  }

  function fieldValue(input) {
    return String(input?.value ?? '').trim();
  }

  function sameValue(input, expected) {
    const actual = fieldValue(input);
    const wanted = String(expected).trim();
    return actual === wanted || (actual !== '' && wanted !== '' && !Number.isNaN(Number(actual)) && Number(actual) === Number(wanted));
  }

  // Enter a value and make sure it STAYS. Controlled components (React / Vue) silently reset the
  // field when they did not register the change, so every strategy is re-checked after a short delay.
  async function enterValue(input, value) {
    const text = String(value);
    const stays = async () => { await sleep(350); return input.isConnected && sameValue(input, text); };
    const errors = [];

    // A) native value setter + input/change events (no debugger, no focus needed)
    try {
      input.scrollIntoView({ block: 'center' });
      input.focus({ preventScroll: true });
      setValue(input, text);
      if (await stays()) return { ok: true, via: 'setter' };
      errors.push('setter');
    } catch (error) { errors.push(`setter: ${error.message}`); }

    // B) execCommand: behaves like paste, fires a real beforeinput/input sequence
    try {
      input.focus({ preventScroll: true });
      input.select?.();
      document.execCommand('insertText', false, text);
      if (await stays()) return { ok: true, via: 'execCommand' };
      errors.push('execCommand');
    } catch (error) { errors.push(`execCommand: ${error.message}`); }

    // C) real keyboard through chrome.debugger
    const typed = await typeTextAsUser(input, text);
    if (typed.ok && await stays()) return { ok: true, via: 'debugger' };
    errors.push(`debugger: ${typed.error || 'nilai tidak bertahan'}`);

    const idInfo = input.id ? `#${input.id}` : (input.placeholder || input.tagName);
    return { ok: false, error: `${idInfo}, terbaca ${fieldValue(input).length} karakter; percobaan: ${errors.join(' | ')}` };
  }

  async function fillTextField(scope, pattern, value, label, warnings, labelPattern) {
    scope = getDialog();
    const input = (labelPattern ? findFieldByLabel(scope, labelPattern) : null) || findByPlaceholder(scope, pattern) || (/kegiatan/.test(String(pattern)) && !/capaian/.test(String(pattern)) ? document.getElementById('form-add_kegiatan') : null);
    if (!input) {
      warnings.push(`Kolom ${label} tidak ditemukan.`);
      return false;
    }
    if (value === undefined || value === null || String(value).trim() === '') {
      warnings.push(`${label} kosong di file Excel.`);
      return false;
    }
    const result = await enterValue(input, value);
    if (!result.ok) {
      warnings.push(`${label} belum cocok dengan data Excel di form KipApp (${result.error}).`);
      return false;
    }
    return true;
  }

  function findCheckboxByText(scope, pattern) {
    const wrappers = [...scope.querySelectorAll('label, .ant-checkbox-wrapper, [role="checkbox"]')]
      .filter((element) => isVisible(element) && pattern.test(element.textContent || ''))
      .sort((left, right) => left.textContent.length - right.textContent.length);
    const wrapper = wrappers[0];
    if (!wrapper) return null;
    return {
      wrapper,
      input: wrapper.querySelector('input[type="checkbox"]'),
      checked: () => {
        const input = wrapper.querySelector('input[type="checkbox"]');
        return input ? input.checked : wrapper.getAttribute('aria-checked') === 'true' || wrapper.classList.contains('ant-checkbox-wrapper-checked') || Boolean(wrapper.querySelector('.ant-checkbox-checked'));
      }
    };
  }

  async function setPeriodMode(scope, shouldUseRange, warnings) {
    let control = findCheckboxByText(scope, /gunakan periode tanggal/i);
    if (!control) {
      if (shouldUseRange) warnings.push('Checkbox “Gunakan periode tanggal” tidak ditemukan.');
      return false;
    }
    if (control.checked() !== shouldUseRange) {
      if (control.input) control.input.click();
      else control.wrapper.click();
      await sleep(350);
      scope = getDialog();
      control = findCheckboxByText(scope, /gunakan periode tanggal/i);
    }
    const isSet = control?.checked() === shouldUseRange;
    if (!isSet && shouldUseRange) warnings.push('KipApp belum mengaktifkan input periode tanggal.');
    return isSet;
  }

  function clickAddButton() {
    const buttons = [...document.querySelectorAll('button, a, [role="button"], .btn')].filter(isVisible);
    const addButton = buttons.find((element) => /^(?:\+\s*)?(?:add|tambah)$/i.test(element.innerText?.replace(/\s+/g, ' ').trim() || element.getAttribute('aria-label') || ''));
    if (!addButton) return false;
    addButton.click();
    return true;
  }

  function cariSelectorRencana(scope) {
    const pickText = [...scope.querySelectorAll('*')].filter((element) => {
      if (element.children.length > 1 || !isVisible(element)) return false;
      return /pilih rencana kinerja skp/i.test(element.textContent || '');
    }).at(-1);
    if (pickText) {
      return pickText.closest('.ant-select')?.querySelector('.ant-select-selector') || pickText;
    }
    return [...scope.querySelectorAll('.ant-select-selector,[role="combobox"]')].filter(isVisible).at(-1) || null;
  }

  function bacaOpsiRencana() {
    return [...document.querySelectorAll('.ant-select-dropdown li, .ant-select-item-option, [role="option"]')]
      .filter(isVisible);
  }

  async function selectRencana(scope, desiredText, warnings) {
    const desired = normalize(desiredText);
    if (!desired) {
      warnings.push('Rencana kinerja kosong di file Excel.');
      return false;
    }

    // Jangan langsung menyerah: dropdown RK sering baru terisi beberapa detik
    // setelah form KipApp terbuka.
    let selector = await waitForCondition(() => {
      scope = getDialog();
      return cariSelectorRencana(scope);
    }, { timeout: 7000 });
    if (!selector) {
      warnings.push('Kolom rencana kinerja tidak ditemukan.');
      return false;
    }

    const cocokkan = (options) => {
      const exact = options.filter((option) => normalize(option.innerText || option.textContent) === desired);
      const partial = options.filter((option) => normalize(option.innerText || option.textContent).startsWith(desired));
      return exact.length === 1 ? exact[0] : (exact.length === 0 && partial.length === 1 ? partial[0] : null);
    };

    selector.click();
    let optionNodes = await waitForCondition(() => {
      const options = bacaOpsiRencana();
      return options.length ? options : null;
    }, { timeout: 3000 });

    // Kalau dropdown belum terbuka/terisi, tutup lalu coba buka sekali lagi
    // sambil menunggu lebih lama.
    if (!optionNodes) {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
      await sleep(250);
      scope = getDialog();
      selector = cariSelectorRencana(scope);
      selector?.click();
      optionNodes = await waitForCondition(() => {
        const options = bacaOpsiRencana();
        return options.length ? options : null;
      }, { timeout: 6000 });
    }

    let match = optionNodes ? cocokkan(optionNodes) : null;
    if (match) {
      match.click();
      await sleep(250);
      return true;
    }

    // Dropdown bisa berupa searchable select: ketik nama RK lalu tunggu hasil filter.
    scope = getDialog();
    const searchable = visibleInputs(scope).find((input) => input.closest('.ant-select') || input.getAttribute('role') === 'combobox');
    if (searchable) {
      try {
        searchable.focus({ preventScroll: true });
        setValue(searchable, desiredText);
      } catch {
        /* lanjut ke pengecekan di bawah */
      }
      const filtered = await waitForCondition(() => {
        const options = bacaOpsiRencana();
        return options.length ? options : null;
      }, { timeout: 3500 }) || [];
      match = cocokkan(filtered);
      if (match) {
        match.click();
        await sleep(250);
        return true;
      }
    }

    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    warnings.push(optionNodes && optionNodes.length
      ? `Rencana kinerja “${desiredText}” belum cocok dengan pilihan di KipApp (${optionNodes.length} opsi terbaca).`
      : 'Dropdown rencana kinerja belum memuat pilihan setelah ditunggu. Coba ulangi kegiatan ini.');
    return false;
  }

  async function fillDate(input, dateValue, scope) {
    if (!input || !dateValue) return false;
    if (input.type === 'date') {
      const filled = setValue(input, dateValue);
      input.blur();
      await sleep(100);
      return filled && Boolean(input.value);
    }

    input.click();
    await sleep(300);
    const popupInputs = [
      ...document.querySelectorAll('.ant-calendar-input'),
      ...document.querySelectorAll('.ant-calendar-picker-container input'),
      ...document.querySelectorAll('.ant-picker-dropdown input'),
      ...document.querySelectorAll('.ant-picker-panel input')
    ].filter(isVisible);
    const calendarInput = popupInputs.at(-1);
    if (calendarInput && calendarInput !== input) {
      setValue(calendarInput, dateValue);
      calendarInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
      calendarInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true }));
      calendarInput.blur();
      await sleep(150);
      input.blur();
      dismissDatePopup(scope);
      await sleep(100);
      return Boolean(input.value);
    }

    const wasReadonly = input.hasAttribute('readonly');
    if (wasReadonly) input.removeAttribute('readonly');
    const result = setValue(input, dateValue);
    if (wasReadonly) input.setAttribute('readonly', 'readonly');
    input.blur();
    dismissDatePopup(scope);
    await sleep(100);
    return result && Boolean(input.value);
  }


  // ---- Ant Design calendar helpers: pick dates by clicking the calendar like a person would ----
  const MONTH_INDEX = {
    januari: 0, jan: 0, january: 0, februari: 1, feb: 1, february: 1, maret: 2, mar: 2, march: 2,
    april: 3, apr: 3, mei: 4, may: 4, juni: 5, jun: 5, june: 5, juli: 6, jul: 6, july: 6,
    agustus: 7, agu: 7, agt: 7, agust: 7, aug: 7, august: 7, september: 8, sep: 8, sept: 8,
    oktober: 9, okt: 9, oct: 9, october: 9, november: 10, nov: 10, nop: 10, desember: 11, des: 11, dec: 11, december: 11
  };

  function parseIsoDate(iso) {
    const match = String(iso || '').match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    return match ? { y: Number(match[1]), m: Number(match[2]) - 1, d: Number(match[3]) } : null;
  }

  function visibleCalendarPopup() {
    return [...document.querySelectorAll('.ant-calendar-picker-container, .ant-calendar-range')]
      .filter(isVisible).at(-1) || null;
  }

  function calendarPanels(popup) {
    const parts = [...popup.querySelectorAll('.ant-calendar-range-part')];
    if (parts.length) return parts;
    const single = popup.matches?.('.ant-calendar') ? popup : popup.querySelector('.ant-calendar');
    return single ? [single] : [];
  }

  function panelMonth(panel) {
    const monthText = (panel.querySelector('.ant-calendar-month-select')?.textContent || '').trim();
    const yearText = (panel.querySelector('.ant-calendar-year-select')?.textContent || '').trim();
    let month = MONTH_INDEX[normalize(monthText).replace(/[^a-z]/g, '')];
    let year = parseInt(yearText, 10);
    if (month === undefined || !year) {
      const combined = (panel.querySelector('.ant-calendar-my-select')?.textContent || '').match(/([A-Za-z]+)\.?\s*(\d{4})/);
      if (combined) { month = MONTH_INDEX[combined[1].toLowerCase()]; year = Number(combined[2]); }
    }
    return month === undefined || !year ? null : { y: year, m: month };
  }

  function fireClick(element) {
    for (const type of ['mousedown', 'mouseup', 'click']) {
      element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    }
  }

  async function openCalendar(scope, which) {
    if (visibleCalendarPopup() && which === 'any') return true;
    const picker = scope.querySelector('.ant-calendar-picker');
    if (!picker) return false;
    const rangeInputs = [...picker.querySelectorAll('.ant-calendar-range-picker-input')];
    const trigger = rangeInputs.length ? (rangeInputs[which === 'end' ? 1 : 0] || rangeInputs[0]) : (picker.querySelector('.ant-calendar-picker-input') || picker);
    fireClick(trigger);
    await sleep(350);
    return Boolean(visibleCalendarPopup());
  }

  // Navigate until some panel shows the month, then click the day cell. Returns {ok, error}.
  async function clickCalendarDate(target, label) {
    for (let attempt = 0; attempt < 40; attempt += 1) {
      const popup = visibleCalendarPopup();
      if (!popup) return { ok: false, error: `Kalender KipApp tertutup sebelum ${label} dipilih.` };
      const panels = calendarPanels(popup);
      if (!panels.length) return { ok: false, error: 'Panel kalender KipApp tidak dikenali.' };
      const matching = panels.find((panel) => {
        const shown = panelMonth(panel);
        return shown && shown.y === target.y && shown.m === target.m;
      });
      if (matching) {
        const cells = [...matching.querySelectorAll('td.ant-calendar-cell')].filter((cell) =>
          !cell.classList.contains('ant-calendar-last-month-cell') && !cell.classList.contains('ant-calendar-next-month-btn-day') &&
          (cell.textContent || '').trim() === String(target.d));
        const cell = cells[0];
        if (!cell) return { ok: false, error: `Tanggal ${label} tidak ditemukan di kalender.` };
        if (cell.classList.contains('ant-calendar-disabled-cell')) {
          return { ok: false, error: `Tanggal ${label} dinonaktifkan oleh KipApp (kemungkinan di luar periode atau belum boleh dipilih).` };
        }
        fireClick(cell);
        await sleep(250);
        return { ok: true };
      }
      const first = panelMonth(panels[0]);
      if (!first) return { ok: false, error: 'Bulan di kalender KipApp tidak terbaca.' };
      const delta = (target.y * 12 + target.m) - (first.y * 12 + first.m);
      const selector = Math.abs(delta) >= 12
        ? (delta > 0 ? '.ant-calendar-next-year-btn' : '.ant-calendar-prev-year-btn')
        : (delta > 0 ? '.ant-calendar-next-month-btn' : '.ant-calendar-prev-month-btn');
      const button = panels[0].querySelector(selector) || popup.querySelector(selector);
      if (!button) return { ok: false, error: 'Tombol pindah bulan di kalender KipApp tidak ditemukan.' };
      fireClick(button);
      await sleep(120);
    }
    return { ok: false, error: `Bulan untuk tanggal ${label} tidak berhasil dibuka di kalender.` };
  }

  async function pickSingleDate(scope, iso) {
    const target = parseIsoDate(iso);
    if (!target) return { ok: false, error: `Format tanggal Excel tidak dikenali: “${iso || 'kosong'}”.` };
    if (!await openCalendar(scope, 'start')) return { ok: false, error: 'Kalender tanggal KipApp tidak terbuka.' };
    const result = await clickCalendarDate(target, displayDateLabel(iso));
    if (!result.ok) return result;
    await sleep(200);
    const value = scope.querySelector('.ant-calendar-picker-input')?.value || '';
    return value ? { ok: true } : { ok: false, error: `Tanggal ${displayDateLabel(iso)} diklik tetapi kolom tanggal tetap kosong.` };
  }

  async function pickDateRange(scope, startIso, endIso) {
    const start = parseIsoDate(startIso);
    const end = parseIsoDate(endIso);
    if (!start) return { ok: false, error: `Tanggal mulai tidak dikenali: “${startIso || 'kosong'}”.` };
    if (!end) return { ok: false, error: `Tanggal selesai tidak dikenali: “${endIso || 'kosong'}”.` };
    if (!await openCalendar(scope, 'start')) return { ok: false, error: 'Kalender periode tanggal KipApp tidak terbuka.' };
    const first = await clickCalendarDate(start, `mulai ${displayDateLabel(startIso)}`);
    if (!first.ok) return first;
    if (!visibleCalendarPopup()) await openCalendar(getDialog(), 'end');
    const second = await clickCalendarDate(end, `selesai ${displayDateLabel(endIso)}`);
    if (!second.ok) return second;
    await sleep(300);
    const values = [...getDialog().querySelectorAll('.ant-calendar-range-picker-input')].map((input) => input.value);
    if (values.length >= 2 && values[0] && values[1]) return { ok: true };
    return { ok: false, error: `Rentang tanggal sudah diklik tetapi kolom terbaca “${values.join(' ~ ')}”.` };
  }

  function displayDateLabel(iso) {
    const parsed = parseIsoDate(iso);
    return parsed ? `${String(parsed.d).padStart(2, '0')}/${String(parsed.m + 1).padStart(2, '0')}/${parsed.y}` : String(iso || '');
  }

  async function fillForm(row) {
    const warnings = [];
    const existingDialog = getDialog();
    const dialogOpen = existingDialog !== document;
    if (!dialogOpen) {
      if (!clickAddButton()) {
        return { ok: false, error: 'Tombol Add/Tambah tidak ditemukan. Buka tabel Pelaksanaan Kinerja di KipApp, lalu coba lagi.' };
      }
      await sleep(700);
    }

    let scope = getDialog();
    if (scope === document) {
      const hasForm = visibleInputs(document).some((input) => /deskripsi kegiatan/i.test(input.placeholder || ''));
      if (!hasForm) return { ok: false, error: 'Form kegiatan belum terbuka. Pastikan Anda berada di tabel Pelaksanaan Kinerja.' };
    }

    const hasRange = Boolean(row.tanggalMulai && row.tanggalSelesai && row.tanggalMulai !== row.tanggalSelesai);
    await setPeriodMode(scope, hasRange, warnings);
    await sleep(250);
    scope = getDialog();
    const datePicker = scope.querySelector('.ant-calendar-picker');
    if (datePicker) {
      const dateResult = hasRange
        ? await pickDateRange(scope, row.tanggalMulai, row.tanggalSelesai)
        : await pickSingleDate(scope, row.tanggalMulai);
      if (!dateResult.ok) warnings.push(dateResult.error);
    } else {
      const dateInputs = visibleInputs(scope).filter((input) => /tanggal|date/i.test(`${input.placeholder || ''} ${input.getAttribute('aria-label') || ''}`) || input.type === 'date');
      const startInput = dateInputs.find((input) => /mulai|start/i.test(input.placeholder || input.getAttribute('aria-label') || '')) || dateInputs[0];
      if (row.tanggalMulai && startInput) {
        if (!await fillDate(startInput, row.tanggalMulai, scope)) warnings.push('Tanggal mulai belum terisi di form KipApp.');
      } else warnings.push('Kolom tanggal tidak ditemukan atau tanggal mulai kosong.');
      if (hasRange && row.tanggalSelesai) {
        scope = getDialog();
        const refreshedDateInputs = visibleInputs(scope).filter((input) => /tanggal|date/i.test(`${input.placeholder || ''} ${input.getAttribute('aria-label') || ''}`) || input.type === 'date');
        const refreshedStart = refreshedDateInputs.find((input) => /mulai|start/i.test(input.placeholder || input.getAttribute('aria-label') || '')) || refreshedDateInputs[0];
        const endInput = refreshedDateInputs.find((input) => /selesai|akhir|end/i.test(input.placeholder || input.getAttribute('aria-label') || '') && input !== refreshedStart) || refreshedDateInputs.find((input) => input !== refreshedStart);
        if (endInput) {
          if (!await fillDate(endInput, row.tanggalSelesai, scope)) warnings.push('Tanggal selesai belum terisi di form KipApp.');
        }
        else warnings.push('KipApp tidak menampilkan kolom tanggal selesai setelah periode tanggal diaktifkan.');
      }

    }
    scope = getDialog();
    const progressInput = findFieldByLabel(scope, /^progres+s?$/i) || findByPlaceholder(scope, /progres|progress/i) || document.getElementById('form-add_progres') || visibleInputs(scope).filter((input) => input.type === 'number').at(-1);
    if (progressInput && row.progres !== '') {
      const progressResult = await enterValue(progressInput, row.progres);
      if (!progressResult.ok) warnings.push(`Progres belum cocok dengan data Excel di form KipApp (${progressResult.error}).`);
    } else warnings.push('Kolom progres tidak ditemukan atau kosong.');

    await fillTextField(scope, /deskripsi capaian|capaian/i, row.capaian, 'Deskripsi Capaian', warnings, /^capaian$/i);

    await fillTextField(scope, /link data dukung|bukti dukung|data dukung/i, row.dataDukung, 'Link Data Dukung', warnings, /^data dukung$/i);

    scope = getDialog();
    const label = [...scope.querySelectorAll('label, .ant-checkbox-wrapper, span')].filter(isVisible).filter((element) => /masukan ke capaian skp/i.test(element.textContent || '')).at(-1);
    if (label) {
      const checkbox = label.querySelector('input[type="checkbox"]') || label.closest('label, .ant-checkbox-wrapper')?.querySelector('input[type="checkbox"]');
      if (checkbox && !checkbox.checked) checkbox.click();
      else if (!checkbox && !label.classList.contains('ant-checkbox-wrapper-checked')) label.click();
    }

    // Fill the activity textarea last: KipApp may rerender the form when other
    // controlled fields or the SKP checkbox change.
    scope = getDialog();
    await fillTextField(scope, /deskripsi kegiatan|kegiatan/i, row.kegiatan, 'Deskripsi Kegiatan', warnings, /^kegiatan$/i);

    // Rencana Kinerja sengaja diisi PALING AKHIR: dropdown RK di KipApp kadang
    // butuh beberapa detik untuk memuat opsi. selectRencana() menunggu opsi.
    scope = getDialog();
    await selectRencana(scope, row.rencanaKinerja, warnings);
    await sleep(500);

    // Final pass: KipApp may re-render and wipe fields after we filled them.
    await sleep(300);
    scope = getDialog();
    const checks = [
      ['Deskripsi Kegiatan', findFieldByLabel(scope, /^kegiatan$/i) || document.getElementById('form-add_kegiatan') || findByPlaceholder(scope, /deskripsi kegiatan|kegiatan/i), row.kegiatan],
      ['Progres', findFieldByLabel(scope, /^progres+s?$/i) || findByPlaceholder(scope, /progres|progress/i), row.progres],
      ['Deskripsi Capaian', findFieldByLabel(scope, /^capaian$/i) || findByPlaceholder(scope, /deskripsi capaian|capaian/i), row.capaian],
      ['Link Data Dukung', findFieldByLabel(scope, /^data dukung$/i) || findByPlaceholder(scope, /link data dukung|bukti dukung|data dukung/i), row.dataDukung]
    ];
    for (const [name, input, expected] of checks) {
      if (!input || !expected) continue;
      if (!sameValue(input, expected)) {
        const retry = await enterValue(input, expected);
        if (!retry.ok) warnings.push(`${name} terhapus/tidak bertahan setelah form dirender ulang.`);
      }
    }

    const datePickerFinal = scope.querySelector('.ant-calendar-picker');
    if (datePickerFinal && !datePickerFinal.querySelector('.ant-calendar-picker-input')?.value) {
      warnings.push('Tanggal terhapus setelah memilih Rencana Kinerja. Periksa form KipApp.');
    }

    return { ok: true, warnings };
  }

  function visibleSuccessMessages() {
    const messages = [...document.querySelectorAll('.ant-message-notice-content, .ant-notification-notice, .ant-alert-success, .alert-success, [role="status"], [role="alert"]')].filter(isVisible);
    return messages.map((element) => (element.textContent || '').replace(/\s+/g, ' ').trim()).filter((text) => text && /berhasil|tersimpan|success|saved/i.test(text));
  }

  function getFormError(scope) {
    const errors = [...scope.querySelectorAll('.ant-form-item-explain-error, .ant-form-explain, [role="alert"], .ant-message-error')]
      .filter(isVisible)
      .map((element) => element.textContent.trim())
      .filter(Boolean);
    return errors[0] || '';
  }

  async function saveForm() {
    const scope = getDialog();
    if (scope === document) return { ok: false, error: 'Form kegiatan tidak terbuka untuk disimpan.' };
    const saveButton = [...scope.querySelectorAll('button, [role="button"], input[type="submit"]')]
      .filter(isVisible)
      .find((element) => /^(save|simpan)$/i.test((element.innerText || element.value || '').replace(/\s+/g, ' ').trim()));
    if (!saveButton) return { ok: false, error: 'Tombol Save/Simpan tidak ditemukan di form KipApp.' };

    const previousMessages = new Set(visibleSuccessMessages());
    saveButton.click();
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      await sleep(250);
      if (getDialog() === document) return { ok: true };
      if (visibleSuccessMessages().some((message) => !previousMessages.has(message))) return { ok: true };
      const error = getFormError(getDialog());
      if (error) return { ok: false, error: `KipApp menolak penyimpanan: ${error}` };
    }
    return { ok: false, error: 'Tombol simpan sudah diklik, tetapi form masih terbuka. Periksa pesan validasi KipApp sebelum melanjutkan.' };
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'CKP_FILL_ROW') {
      fillForm(message.row).then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message || 'Terjadi kendala saat mengisi form.' }));
      return true;
    }
    if (message?.type === 'CKP_SAVE_ROW') {
      saveForm().then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message || 'Terjadi kendala saat menyimpan kegiatan.' }));
      return true;
    }
    return false;
  });
})();
