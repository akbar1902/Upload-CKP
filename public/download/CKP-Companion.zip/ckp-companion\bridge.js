(() => {
  // CKP Companion bridge — content script untuk CKP-App web lokal.
  // Mode HANDOFF: web kirim records via window.postMessage, bridge forward
  // ke background untuk disimpan ke chrome.storage.local. User buka sidepanel
  // -> data sudah nongol -> klik "Isi & simpan" seperti biasa.
  // Kontrak dari web: window.postMessage({ type: 'CKP_SEND_RECORDS',
  //   fileName?, sheetName?, rows: [{ no?, tanggalMulai, tanggalSelesai,
  //   rencanaKinerja, kegiatan, progres, capaian, dataDukung }] }, '*')
  // Balasan ke web: window.postMessage({ source: 'CKP_COMPANION',
  //   type: 'CKP_HANDOFF_ACK', ok, saved, error }, '*')
  const SEND_TYPE = 'CKP_SEND_RECORDS';
  const HANDOFF_TYPE = 'CKP_HANDOFF_RECORDS';
  const ACK_TYPE = 'CKP_HANDOFF_ACK';

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const msg = event.data;
    if (!msg || msg.type !== SEND_TYPE) return;
    const rows = Array.isArray(msg.rows) ? msg.rows : [];
    try {
      chrome.runtime.sendMessage(
        {
          type: HANDOFF_TYPE,
          fileName: msg.fileName,
          sheetName: msg.sheetName,
          profileId: msg.profileId,
          profileName: msg.profileName,
          profileNip: msg.profileNip,
          rows,
        },
        (response) => {
          const error = chrome.runtime.lastError ? chrome.runtime.lastError.message : (response?.error || '');
          const ok = !chrome.runtime.lastError && response?.ok === true;
          window.postMessage(
            { source: 'CKP_COMPANION', type: ACK_TYPE, ok, saved: response?.saved ?? 0, profile: response?.profile || '', error: error || '' },
            '*'
          );
        }
      );
    } catch (error) {
      window.postMessage(
        { source: 'CKP_COMPANION', type: ACK_TYPE, ok: false, saved: 0, error: error?.message || 'Bridge gagal.' },
        '*'
      );
    }
  });
})();
