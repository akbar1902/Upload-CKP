// CKP Companion v0.5.0 — ambil CKP langsung dari SIKAP.
//
// Alur: Hubungkan SIKAP (pairing satu kali, sama seperti CKP App) → pilih bulan
// → Ambil kegiatan. Kegiatan dikirim ke background lewat jalur handoff yang
// sudah ada (CKP_HANDOFF_RECORDS), sehingga pengisian KipApp tidak berubah.
//
// Dimuat SETELAH sidepanel.js: memakai fungsi/variabel global di sana
// (profil, state, busy, render, gantiProfil, muatProfilRegistry, stateKey,
// escapeHtml, showActionMessage).

const SIKAP_BASE = 'https://sikap-ckp.vercel.app';
const SIKAP_KEY = 'ckp-companion-sikap-v1';
const SIKAP_PAIRING_KEY = 'ckp-companion-sikap-pairing-v1';
const SIKAP_BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
const SIKAP_STATUS = {
  submitted: 'Menunggu penilaian',
  scored: 'Sudah dinilai',
  approved: 'Disetujui',
  rejected: 'Ditolak',
  revision_required: 'Perlu revisi',
  reopened: 'Dibuka kembali',
  draft: 'Draft',
};

const sikapEls = {
  disconnected: document.querySelector('#sikapDisconnected'),
  pairing: document.querySelector('#sikapPairing'),
  connected: document.querySelector('#sikapConnected'),
  connect: document.querySelector('#sikapConnectButton'),
  cancel: document.querySelector('#sikapCancelButton'),
  userName: document.querySelector('#sikapUserName'),
  periodSelect: document.querySelector('#sikapPeriodSelect'),
  fetch: document.querySelector('#sikapFetchButton'),
  refresh: document.querySelector('#sikapRefreshButton'),
  disconnect: document.querySelector('#sikapDisconnectButton'),
  error: document.querySelector('#sikapError'),
};

let sikapConn = { token: '', user: null };
let sikapDaftar = [];
let sikapPollTimer = null;

function sikapTampil(mode) {
  sikapEls.disconnected.classList.toggle('hidden', mode !== 'disconnected');
  sikapEls.pairing.classList.toggle('hidden', mode !== 'pairing');
  sikapEls.connected.classList.toggle('hidden', mode !== 'connected');
}

function sikapError(pesan) {
  sikapEls.error.textContent = pesan || '';
  sikapEls.error.classList.toggle('hidden', !pesan);
}

function sikapSibuk(tombol, sibuk, label) {
  tombol.disabled = sibuk;
  const span = tombol.querySelector('span');
  if (span && label) span.textContent = label;
}

async function sikapApi(path, { auth = true, method = 'GET' } = {}) {
  const headers = {};
  if (auth) headers.Authorization = `Bearer ${sikapConn.token}`;
  let res;
  try {
    res = await fetch(`${SIKAP_BASE}${path}`, { method, headers, cache: 'no-store' });
  } catch {
    throw new Error('Tidak bisa terhubung ke SIKAP. Periksa koneksi internet.');
  }
  let body = {};
  try { body = await res.json(); } catch { /* bukan JSON */ }
  if (res.status === 401 && auth) {
    await sikapPutuskan({ diam: true });
    throw new Error('Sambungan ke SIKAP sudah tidak berlaku (token dicabut). Klik Hubungkan SIKAP lagi.');
  }
  return { status: res.status, body };
}

// ── Pairing ──────────────────────────────────────────────────────
async function sikapMulaiPairing() {
  sikapError('');
  sikapSibuk(sikapEls.connect, true, 'Menyiapkan…');
  try {
    const { status, body } = await sikapApi('/api/integrations/ckp-app/pair', { auth: false, method: 'POST' });
    if (status !== 200 || !body.success) throw new Error(body.error || 'Gagal memulai sambungan ke SIKAP.');
    const pairing = { id: body.pairingId, secret: body.secret, expiresAt: body.expiresAt };
    await chrome.storage.local.set({ [SIKAP_PAIRING_KEY]: pairing });
    await chrome.tabs.create({ url: body.pairUrl });
    sikapTampil('pairing');
    sikapPantauPairing(pairing);
  } catch (error) {
    sikapError(error.message);
  } finally {
    sikapSibuk(sikapEls.connect, false, 'Hubungkan SIKAP');
  }
}

function sikapHentikanPantau() {
  if (sikapPollTimer) clearTimeout(sikapPollTimer);
  sikapPollTimer = null;
}

function sikapPantauPairing(pairing) {
  sikapHentikanPantau();
  const cek = async () => {
    try {
      if (new Date(pairing.expiresAt).getTime() < Date.now()) throw new Error('Waktu persetujuan habis (10 menit). Klik Hubungkan SIKAP lagi.');
      const { body } = await sikapApi(`/api/integrations/ckp-app/pair/${encodeURIComponent(pairing.id)}?secret=${encodeURIComponent(pairing.secret)}`, { auth: false });
      if (body.status === 'approved' && body.token) {
        await chrome.storage.local.remove(SIKAP_PAIRING_KEY);
        sikapConn = { token: body.token, user: null };
        await chrome.storage.local.set({ [SIKAP_KEY]: sikapConn });
        await sikapMuatDaftar();
        showActionMessage('SIKAP terhubung. Pilih bulan lalu klik Ambil kegiatan.');
        return;
      }
      if (body.status === 'pending') {
        sikapPollTimer = setTimeout(cek, 2000);
        return;
      }
      throw new Error(body.error || 'Sambungan ke SIKAP gagal.');
    } catch (error) {
      await chrome.storage.local.remove(SIKAP_PAIRING_KEY);
      sikapTampil('disconnected');
      sikapError(error.message);
    }
  };
  sikapPollTimer = setTimeout(cek, 1500);
}

async function sikapBatalPairing() {
  sikapHentikanPantau();
  await chrome.storage.local.remove(SIKAP_PAIRING_KEY);
  sikapTampil('disconnected');
}

async function sikapPutuskan({ diam = false } = {}) {
  sikapHentikanPantau();
  sikapConn = { token: '', user: null };
  sikapDaftar = [];
  await chrome.storage.local.remove([SIKAP_KEY, SIKAP_PAIRING_KEY]);
  sikapTampil('disconnected');
  if (!diam) showActionMessage('Sambungan SIKAP diputus. Token bisa dicabut di SIKAP → All in CKP App.');
}

// ── Daftar & isi CKP ─────────────────────────────────────────────
async function sikapMuatDaftar() {
  sikapError('');
  sikapTampil('connected');
  sikapEls.periodSelect.innerHTML = '<option>Memuat…</option>';
  sikapEls.fetch.disabled = true;
  try {
    const { status, body } = await sikapApi('/api/integrations/ckp-app/ckp');
    if (status !== 200 || !body.success) throw new Error(body.error || 'Gagal memuat daftar CKP.');
    sikapConn.user = body.user;
    await chrome.storage.local.set({ [SIKAP_KEY]: sikapConn });
    sikapEls.userName.textContent = body.user?.full_name || '—';
    sikapDaftar = Array.isArray(body.ckp) ? body.ckp : [];
    if (!sikapDaftar.length) {
      sikapEls.periodSelect.innerHTML = '<option value="">Belum ada CKP di SIKAP</option>';
      return;
    }
    sikapEls.periodSelect.innerHTML = sikapDaftar.map((c, i) => {
      const label = `${SIKAP_BULAN[c.bulan - 1]} ${c.tahun} · ${c.totalEntries ?? '?'} kegiatan · ${SIKAP_STATUS[c.status] || c.status}`;
      return `<option value="${i}">${escapeHtml(label)}</option>`;
    }).join('');
    sikapEls.fetch.disabled = false;
  } catch (error) {
    if (sikapConn.token) sikapError(error.message);
    sikapEls.periodSelect.innerHTML = '<option value="">—</option>';
  }
}

async function sikapAmbil() {
  if (busy) return showActionMessage('Selesaikan proses pengisian yang sedang berjalan dulu.', true);
  const pilihan = sikapDaftar[Number(sikapEls.periodSelect.value)];
  if (!pilihan) return;
  sikapError('');
  sikapSibuk(sikapEls.fetch, true, 'Mengambil…');
  try {
    const { status, body } = await sikapApi(`/api/integrations/ckp-app/ckp?bulan=${pilihan.bulan}&tahun=${pilihan.tahun}`);
    if (status !== 200 || !body.success) throw new Error(body.error || 'Gagal mengambil kegiatan dari SIKAP.');

    const user = body.user || sikapConn.user || {};
    const namaPeriode = `${SIKAP_BULAN[body.upload.bulan - 1]} ${body.upload.tahun}`;
    // Sama dengan pencocokan di background.js: id SIKAP, lalu NIP/nama, agar
    // pegawai yang sudah punya profil (mis. dari CKP App) tidak dibuat ganda.
    await muatProfilRegistry();
    const nama = String(user.full_name || '').trim().toLowerCase();
    const cocok = profil.profiles.find((p) => p.id === `sikap-${user.id}`)
      || profil.profiles.find((p) => (user.nip && String(p.nip || '').trim() === user.nip) || (nama && String(p.nama || '').trim().toLowerCase() === nama));
    const profileId = cocok ? cocok.id : `sikap-${user.id}`;

    // CKP yang sama sudah pernah diambil dan sebagian sudah tersimpan di KipApp:
    // tawarkan melanjutkan agar kegiatan yang sudah tersimpan tidak dikirim dua kali.
    const tersimpan = (await chrome.storage.local.get(stateKey(profileId)))[stateKey(profileId)];
    const sudahSelesai = (tersimpan?.records || []).filter((r) => r.status === 'done').length;
    if (tersimpan?.sikapUploadId === body.upload.id && sudahSelesai > 0) {
      const lanjut = confirm(`CKP ${namaPeriode} ini sudah pernah diambil dan ${sudahSelesai} kegiatan sudah tersimpan di KipApp.\n\nOK = lanjutkan progres sebelumnya\nBatal = ambil ulang dari awal (semua kegiatan dianggap belum tersimpan)`);
      if (lanjut) {
        await gantiProfil(profileId, { pesan: false });
        showActionMessage(`Melanjutkan CKP ${namaPeriode}: ${sudahSelesai} kegiatan sudah tersimpan.`);
        return;
      }
    }

    const response = await chrome.runtime.sendMessage({
      type: 'CKP_HANDOFF_RECORDS',
      source: 'sikap',
      sikapUploadId: body.upload.id,
      fileName: `SIKAP · CKP ${namaPeriode} (versi ${body.upload.version ?? 1})`,
      sheetName: `CKP ${namaPeriode}`,
      profileId,
      profileName: user.full_name || 'Pegawai SIKAP',
      profileNip: user.nip || '',
      rows: body.rows,
    });
    if (!response?.ok) throw new Error(response?.error || 'Kegiatan gagal dimuat ke panel.');
    // Background mengirim CKP_HANDOFF_LIVE; listener di sidepanel.js memuat & menampilkan.
  } catch (error) {
    sikapError(error.message);
  } finally {
    sikapSibuk(sikapEls.fetch, false, 'Ambil kegiatan');
  }
}

sikapEls.connect.addEventListener('click', sikapMulaiPairing);
sikapEls.cancel.addEventListener('click', sikapBatalPairing);
sikapEls.fetch.addEventListener('click', sikapAmbil);
sikapEls.refresh.addEventListener('click', sikapMuatDaftar);
sikapEls.disconnect.addEventListener('click', () => {
  if (confirm('Putuskan sambungan ke SIKAP di Chrome ini?')) sikapPutuskan();
});

(async () => {
  const saved = await chrome.storage.local.get([SIKAP_KEY, SIKAP_PAIRING_KEY]);
  if (saved[SIKAP_KEY]?.token) {
    sikapConn = saved[SIKAP_KEY];
    sikapEls.userName.textContent = sikapConn.user?.full_name || '—';
    await sikapMuatDaftar();
  } else if (saved[SIKAP_PAIRING_KEY]?.id) {
    // Panel sempat ditutup saat menunggu persetujuan: lanjutkan memantau.
    sikapTampil('pairing');
    sikapPantauPairing(saved[SIKAP_PAIRING_KEY]);
  } else {
    sikapTampil('disconnected');
  }
})().catch((error) => sikapError(error.message));
