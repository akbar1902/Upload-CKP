import { useEffect, useMemo, useRef, useState } from 'react';
import { motion } from 'motion/react';
import { CloudUpload, FileArchive, FolderSearch, Image as ImageIcon, Search, FileText, RefreshCcw, Rocket } from 'lucide-react';
import { useApp } from '../store.jsx';
import { api } from '../lib/api.js';
import { fmtBytes, fotoUrl } from '../lib/format.js';
import { Button, Card, Empty, Field, inputCls, Pill, SectionHead, Segmented } from '../components/ui.jsx';
import FolderPicker from '../components/FolderPicker.jsx';
import Lightbox from '../components/Lightbox.jsx';

const KECEPATAN = [
  { value: 2, label: 'Santai 2×' },
  { value: 4, label: 'Standar 4×' },
  { value: 6, label: 'Cepat 6×' },
  { value: 8, label: 'Turbo 8×' },
];

export default function UploadPage() {
  const { s, dispatch, toast, mulaiUpload } = useApp();
  const [drag, setDrag] = useState(false);
  const [busy, setBusy] = useState(false);
  const [folder, setFolder] = useState('');
  const [speed, setSpeed] = useState(6);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [mulai, setMulai] = useState(false);
  const inputRef = useRef(null);
  const zip = s.zip;
  const bulan = s.header.bulanPeriode || '';
  const ada = zip.total > 0;

  // Folder Drive default per profil (diatur di halaman Profil).
  useEffect(() => {
    if (!folder && s.header.driveFolder) setFolder(s.header.driveFolder);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [s.header.driveFolder]);

  const unggah = async (file) => {
    if (!/\.zip$/i.test(file.name)) return toast('Hanya file .zip yang diterima.', 'warn');
    const fd = new FormData();
    fd.append('zip', file);
    setBusy(true);
    try {
      const j = await api('/api/zip/upload', { method: 'POST', body: fd });
      if (!j.valid) return toast(j.message || 'ZIP tidak berisi foto/dokumen yang didukung.', 'err');
      dispatch({
        type: 'zip',
        zip: {
          path: j.zipPath, name: j.zipName, files: j.files, photos: j.photosCount,
          docs: j.docsCount, bytes: j.totalBytes, total: j.totalFiles, folder: j.suggestedFolder || '',
        },
      });
      setFolder((f) => f || j.suggestedFolder || '');
      toast(`${j.totalFiles} berkas terbaca. Atur folder Drive lalu mulai upload.`);
    } catch (e) {
      toast('Gagal membaca ZIP: ' + e.message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDrag(false);
    const f = [...(e.dataTransfer?.files || [])].find((x) => /\.zip$/i.test(x.name));
    if (f) unggah(f);
    else toast('Hanya file .zip yang diterima.', 'warn');
  };

  const mulaiKlik = async () => {
    if (!folder.trim()) return toast('Isi folder Google Drive dulu.', 'warn');
    setMulai(true);
    try {
      await mulaiUpload({ zipPath: zip.path, folder: folder.trim(), parallel: speed });
    } catch (e) {
      toast(e.message, 'err');
    } finally {
      setMulai(false);
    }
  };

  return (
    <>
      <SectionHead
        eyebrow="Tahap 1 dari 4"
        title={
          <>Bulan <span className="text-accent-text">{bulan || 'baru'}</span>, {bulan ? 'arsip beres' : 'arsip baru'}.</>
        }
        desc="Tarik file .zip berisi foto & dokumen. Sisanya otomatis: naik ke Drive, jadi link, jadi draft. Nama file dibaca dari pola 1 September_kegiatan… atau 20-27 September_kegiatan…"
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <div className="flex flex-col gap-5">
          <Card className="overflow-hidden">
            {!ada ? (
              <motion.div
                role="button" tabIndex={0}
                onClick={() => inputRef.current?.click()}
                onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); inputRef.current?.click(); } }}
                onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
                onDragLeave={(e) => { e.preventDefault(); setDrag(false); }}
                onDrop={onDrop}
                animate={{ scale: drag ? 1.01 : 1 }}
                className={`group m-1.5 flex cursor-pointer flex-col items-center justify-center rounded-[14px] border-2 border-dashed px-6 py-16 text-center transition duration-300 ${drag ? 'border-glow bg-accent-soft' : 'border-line-strong hover:border-accent/50 hover:bg-surface-2/60'}`}
              >
                <div className={`mb-5 grid size-16 place-items-center rounded-2xl transition duration-300 ${drag ? 'bg-glow text-white' : 'bg-accent-soft text-accent-text group-hover:scale-105'}`}>
                  {busy ? <RefreshCcw className="size-7 animate-spin" /> : <CloudUpload className="size-7" strokeWidth={1.8} />}
                </div>
                <h3 className="text-[17px] font-bold text-ink">{busy ? 'Membaca ZIP…' : 'Tarik & letakkan ZIP di sini'}</h3>
                <p className="mt-1.5 text-[13px] text-muted">
                  {busy ? 'mohon tunggu, isi ZIP sedang dibaca' : <>atau <span className="font-semibold text-accent-text">klik untuk memilih file</span> · maks {s.rclone.maxMB} MB</>}
                </p>
              </motion.div>
            ) : (
              <div className="flex flex-col gap-5 p-6">
                <div className="flex items-start gap-4">
                  <div className="grid size-12 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent-text">
                    <FileArchive className="size-6" strokeWidth={1.8} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-mono text-[14px] font-semibold text-ink">{zip.name}.zip</p>
                    <p className="tnum mt-1 text-[12.5px] text-muted">{zip.total} berkas · {fmtBytes(zip.bytes)}</p>
                  </div>
                  <Button variant="secondary" size="sm" onClick={() => inputRef.current?.click()} disabled={busy}>Ganti ZIP</Button>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <Stat label="Berkas" value={zip.total} />
                  <Stat label="Foto" value={zip.photos} />
                  <Stat label="Dokumen" value={zip.docs} />
                </div>
              </div>
            )}
            <input ref={inputRef} type="file" accept=".zip" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) unggah(f); e.target.value = ''; }} />
          </Card>

          {ada && <PratinjauZip />}
        </div>

        <Card className="flex flex-col gap-6 p-6">
          <div>
            <h3 className="text-[15px] font-bold text-ink">Tujuan &amp; kecepatan</h3>
            <p className="mt-1 text-[12.5px] text-muted">Folder Drive tempat berkas diunggah.</p>
          </div>

          <Field label="Folder Google Drive">
            <div className="flex gap-2">
              <input className={inputCls} placeholder="cth: CKP September" value={folder} onChange={(e) => setFolder(e.target.value)} />
              <Button variant="secondary" icon={FolderSearch} onClick={() => setPickerOpen(true)} aria-label="Jelajahi folder Drive">Jelajah</Button>
            </div>
          </Field>

          <div className="flex flex-col gap-2">
            <span className="text-[12px] font-semibold text-muted">Kecepatan upload</span>
            <Segmented name="speed" value={speed} onChange={setSpeed} options={KECEPATAN} />
            <p className="text-[12px] text-faint">Makin tinggi, makin banyak berkas diunggah bersamaan. Turunkan bila Drive sering membatasi.</p>
          </div>

          <div className="mt-auto flex flex-col gap-3 border-t border-line pt-6">
            <Button variant="primary" size="lg" icon={Rocket} disabled={!ada || !folder.trim() || mulai || s.up.running} onClick={mulaiKlik} className="w-full">
              {s.up.running ? 'Sedang mengunggah…' : 'Mulai upload ke Drive'}
            </Button>
            <p className="text-center text-[12.5px] text-muted">
              {!ada ? 'Pilih file ZIP dulu untuk memulai.' : !folder.trim() ? 'Isi folder tujuan di Drive.' : 'Siap. Klik untuk mulai.'}
            </p>
            {s.up.running && (
              <Pill tone="run">Upload berjalan — lihat tahap 2</Pill>
            )}
          </div>
        </Card>
      </div>

      <FolderPicker open={pickerOpen} onClose={() => setPickerOpen(false)} onPick={setFolder} />
    </>
  );
}

function Stat({ label, value }) {
  return (
    <div className="rounded-xl bg-surface-2 px-4 py-3 ring-1 ring-inset ring-line">
      <p className="tnum text-[22px] font-extrabold tracking-[-0.02em] text-ink">{value}</p>
      <p className="text-[11.5px] font-medium text-muted">{label}</p>
    </div>
  );
}

function PratinjauZip() {
  const { s } = useApp();
  const [q, setQ] = useState('');
  const [buka, setBuka] = useState(null);
  const foto = useMemo(() => s.zip.files.filter((f) => f.isPhoto), [s.zip.files]);
  const daftar = useMemo(() => {
    const k = q.trim().toLowerCase();
    return s.zip.files.filter((f) => !k || f.originalName.toLowerCase().includes(k) || (f.relativePath || '').toLowerCase().includes(k)).slice(0, 300);
  }, [q, s.zip.files]);

  return (
    <Card className="flex flex-col">
      <div className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-4">
        <div className="min-w-0 flex-1">
          <h3 className="text-[14.5px] font-bold text-ink">Isi ZIP</h3>
          <p className="text-[12px] text-muted">{s.zip.total} berkas · klik miniatur foto untuk memperbesar</p>
        </div>
        <div className="relative w-full sm:w-64">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
          <input className={`${inputCls} pl-10`} placeholder="Cari nama berkas…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
      </div>
      <div className="scroll-thin max-h-[380px] overflow-y-auto">
        {daftar.length === 0 ? (
          <Empty icon={Search} title="Tidak ada yang cocok" desc="Coba kata kunci lain." />
        ) : (
          <ul className="divide-y divide-line">
            {daftar.map((f) => (
              <li key={f.id} className="flex items-center gap-3 px-5 py-2.5">
                {f.isPhoto ? (
                  <button type="button" onClick={() => setBuka(foto.findIndex((x) => x.id === f.id))} className="group relative size-11 shrink-0 overflow-hidden rounded-lg bg-surface-3 ring-1 ring-inset ring-line">
                    <img loading="lazy" src={fotoUrl(s.zip.path, f.entryName)} alt="" className="size-full object-cover transition duration-300 group-hover:scale-110" />
                  </button>
                ) : (
                  <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-surface-3 text-muted">
                    <FileText className="size-4.5" />
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate font-mono text-[12.5px] text-ink">{f.originalName}</p>
                  <p className="truncate text-[11.5px] text-muted">{f.relativePath !== f.originalName ? f.relativePath : fmtBytes(f.size)}</p>
                </div>
                <span className="tnum hidden font-mono text-[11.5px] text-muted sm:block">{fmtBytes(f.size)}</span>
                {f.isPhoto && <ImageIcon className="size-4 text-faint" />}
              </li>
            ))}
          </ul>
        )}
      </div>
      <Lightbox
        open={buka !== null}
        items={foto}
        idx={Math.max(0, buka ?? 0)}
        zipPath={s.zip.path}
        onIdx={setBuka}
        onClose={() => setBuka(null)}
      />
    </Card>
  );
}
