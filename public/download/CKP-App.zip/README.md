# CKP App

Satu website gabungan: **upload ZIP bukti dukung → sinkron Google Drive (rclone) → draft otomatis → export Excel CKP format SIKAP.**

Menggantikan 2 program lama (`Bukti Dukung` + `CKP-Excel-Generator`). Logic inti dipakai ulang tanpa diubah
(`parser.js`, `rk-matcher.js`, `excel-builder.js`); yang digabung adalah server + GUI menjadi satu.

## Menjalankan

Double-click **`Jalankan CKP.bat`**, atau manual:

```bash
npm install   # sekali saja
node src/server.js
```

Buka http://localhost:3230 (port bisa diubah via env `PORT`).

### Dipakai beberapa pegawai (satu kantor)

Aplikasi ini mendukung **profil pegawai**. Setiap profil punya daftar RK, kata
kunci RK, kamus singkatan, header Excel, folder upload, dan riwayat ekspor
sendiri — jadi **RK yang berbeda antar-pegawai tidak saling menimpa**.

- Buka **Profil & rekan** di sidebar → **Tambah pegawai**.
- Profil baru mulai dengan daftar RK kosong. Isi lewat **Daftar RK → Impor daftar RK**
  (tempel satu RK per baris atau unggah Excel/CSV yang punya kolom “Rencana Kinerja”).
- Ganti profil kapan saja lewat pemilih profil di kanan atas.
- Tombol **Ekspor** di kartu profil menghasilkan `ckp-profil-*.json`; rekan lain bisa
  mengimpornya lewat **Impor profil dari rekan** (RK + kata kunci + kamus ikut).

### Dataset RK kantor

Kalau punya daftar RK semua pegawai, buka **Profil & rekan** → kartu **Dataset RK kantor**:

- **Impor semua pegawai** — membuat/memperbarui profil tiap pegawai beserta RK miliknya.
- **Pilih pegawai** — impor satu orang saja.
- **Impor dataset dari file ZIP/Excel** — untuk dataset baru (satu file per tim atau satu file Matriks).

Dataset bawaan ada di `src/config/rk-dataset.json` (39 pegawai, 14 tim, 380 RK unik).
Satu pegawai = satu profil; nama tim hanya info tambahan. Daftar RK profil yang cocok
ditambahkan ke RK lokal yang sudah ada (tidak menghapus tambahan RK tahun ini), sedangkan
kata kunci yang sudah ada dipertahankan. Pegawai yang pindah satker dilewati.

Dua cara berbagi:

1. **Satu server kantor** — jalankan di satu komputer, rekan membuka alamat LAN
   yang tercetak di terminal / halaman Profil (`http://<IP>:3230`). Server listen
   di `0.0.0.0` secara default (ubah dengan env `HOST=127.0.0.1` bila ingin lokal saja).
2. **Tiap pegawai punya salinan sendiri** — jalankan `Buat Paket Untuk Rekan.bat`.
   Script membuat `CKP-App-Untuk-Rekan.zip` berisi CKP App, extension
   `chrome-extension/ckp-companion`, rclone portable (bila ada), dan
   `BACA-DULU.txt`. Folder `data/` tidak ikut, jadi rekan mulai dari profil
   kosong dengan RK sendiri. Bagikan ZIP-nya, rekan ekstrak lalu jalankan
   `Jalankan CKP.bat`.

Belum ada login: gunakan hanya di jaringan kantor yang tepercaya. Remote rclone
bisa diatur per profil (tombol **Ubah** di kartu profil) bila beberapa pegawai
berbagi satu server tetapi akun Google Drive-nya berbeda.

### Integrasi SIKAP (kirim langsung)

CKP App bisa mengirim Excel CKP langsung ke SIKAP tanpa download-upload manual.

**Cara termudah — satu klik:**
1. Di CKP App: **Profil & rekan** → kartu **Integrasi SIKAP**.
2. Isi **Alamat SIKAP** (sekali saja), lalu klik **Hubungkan SIKAP**.
3. Tab SIKAP terbuka → login jika diminta → klik **Setujui & hubungkan CKP App**.
4. CKP App tersambung otomatis, daftar RK langsung disamakan dengan SIKAP.
5. Buka **Export** → **Kirim ke SIKAP**.

Token manual (buat di SIKAP → **Integrasi CKP App** → opsi lanjutan) tetap
tersedia bila Anda perlu menghubungkan tanpa pairing.

Token disimpan per profil di `data/profiles/<id>/sikap-integration.json` dan
tidak ikut diekspor saat profil dibagikan. Endpoint SIKAP yang dipakai:
`POST/GET /api/integrations/ckp-app`, ditambah `/pair` untuk pairing.
Foto/ZIP tetap di Google Drive; yang dikirim ke SIKAP hanya file Excel (kecil).

### Mengubah tampilan (UI)

UI dibangun dengan **React + Vite + Tailwind CSS** (source di `web/`). Hasil build ada di `public/`
yang dilayani server, jadi pengguna cukup menjalankan server seperti biasa.

```bash
npm run dev     # development: http://localhost:5173 (API diproxy ke 3230)
npm run build   # build ulang ke public/ setelah mengubah web/ — wajib sebelum dipakai
```

**Butuh:** Node.js + rclone terinstall dan remote `gdrive` sudah login
(`rclone listremotes` harus memunculkan `gdrive:`).
rclone dicari otomatis di `tools/rclone/`, folder Bukti Dukung lama, lalu PATH sistem.

## Alur pakai

1. **Upload** — tarik file `.zip` ke dropzone. Isi ZIP langsung diinspeksi
   (jumlah foto/dokumen, ukuran, pratinjau + thumbnail). Isi folder Drive + kecepatan.
2. **Drive** — klik mulai, progress realtime per berkas (bar global + status pill).
   File gagal bisa diulang khusus via *Ulangi yang gagal* — yang sukses tidak diulang.
   Habis selesai, draft otomatis disusun (zero-click).
3. **Draft** — koreksi tanggal (angka + bulan), kegiatan (textarea auto-grow),
   RK (klik → command-palette ketik-cari + rekomendasi, `Enter` pilih).
   RK yang belum ada di daftar bisa langsung ditambah dari kotak cari
   (**Tambah RK baru: “…”**) — tersimpan permanen ke `src/config/rk-list.json`
   dan langsung terpasang di baris itu.
   Checkbox + bulk bar: terapkan 1 RK ke banyak baris, tanggal kosong ikut baris atas.
   Cari + filter (perlu review / RK kosong / tanggal kosong). Header pegawai auto-save.
   Tombol **Isi tanggal** membaca ulang tanggal dari nama file untuk baris yang
   masih kosong (memperbaiki draft lama tanpa upload ulang; tanggal yang sudah
   diisi manual tidak ditimpa).
   Tombol **Hitung ulang RK** menyusun ulang saran memakai aturan kata kunci terbaru
   (baris yang sudah dikoreksi manual tidak ditimpa).
   Tombol export terkunci sampai semua baris lengkap.
4. **Export** — menghasilkan `data/Hasil CKP/CKP_<Bulan>.xlsx` siap SIKAP/Auto-Input.
   Riwayat 50 file terakhir (CKP + laporan link) bisa diunduh / dibuka foldernya.

Menu sidebar: **Daftar RK** (tambah RK baru kapan saja — tanpa perlu punya draft;
langsung dipakai picker, rekomendasi, validasi export, dan Sheet3 Excel),
**Kamus singkatan** (berlaku untuk draft berikutnya),
**Kata kunci RK** (petakan kata kunci di nama file → langsung direkomendasikan
ke RK tertentu; menimpa tebakan otomatis, hanya untuk RK yang perlu).
Kata kunci dicocokkan sebagai **kata utuh**: `SE` cocok pada `SE 2026`/`SE2026`
tetapi tidak pada `Susenas` atau `Kesejahteraan`; `apel` tidak cocok pada `rapel`.
Bila tidak ada aturan yang cocok dan kemiripan kata lemah, RK dibiarkan kosong
(muncul status “RK tidak yakin — pilih manual”) daripada menebak asal-asalan,
**Buka hasil lama** (baca `hasil_*.xlsx` dari `data/Hasil Link/` maupun folder
`Bukti Dukung/Hasil Link` peninggalan program lama).

Format nama file yang diparse otomatis: `1 September_kegiatan…`,
`20-27 September_kegiatan…`. Varian umum juga dikenali: `1. Oktober_kegiatan`,
`1 Oktober 2026_kegiatan`, `1 Okt 2026 - kegiatan`, `01-10-2026_kegiatan`,
`2026-10-01_kegiatan`, `Dokumentasi 5 Oktober_kegiatan`, dan nama kamera
`IMG_20261021_103000_kegiatan`. Tahun di nama file (bila ada) dipakai untuk
tanggal di Excel. Di luar pola itu → flag kuning, isi manual (tanggal yang
berhasil terbaca tetap dipertahankan).

Test parser: `npm test`.

## Struktur

```
CKP-App/
├── src/
│   ├── server.js        # 1 server Express (port 3230) + engine upload rclone
│   ├── parser.js        # nama file → tanggal + kegiatan (dari Generator)
│   ├── rk-matcher.js    # usulan RK (dari Generator)
│   ├── excel-builder.js # Excel format SIKAP (dari Generator)
│   └── config/          # benih awal (migrasi profil pertama): rk-list.json, kamus-singkatan.json, rk-keywords.json, config.json
├── web/                 # source UI (React): src/pages, src/components, src/lib, src/store.jsx
├── public/              # hasil build UI (jangan diedit manual)
├── data/                # profiles/ (per pegawai) | uploads/ | Hasil Link/ | Hasil CKP/ (gitignored)
├── data/profiles.json   # daftar profil pegawai (dibuat otomatis saat pertama jalan)
├── tools/rclone/       # (opsional) taruh rclone.exe di sini agar portable
├── Jalankan CKP.bat
└── test-e2e.js          # node test-e2e.js (butuh server jalan)
```

## Catatan multi-profil

- Struktur data: `data/profiles/<id-profil>/` berisi `config.json`, `rk-list.json`,
  `rk-keywords.json`, `kamus-singkatan.json`, `uploads/`, `Hasil Link/`, `Hasil CKP/`.
- Instalasi lama otomatis dimigrasikan menjadi profil pertama saat server pertama
  kali dijalankan; file lama di `data/Hasil CKP` tetap terbaca sebagai riwayat.
- Header profil disimpan otomatis per profil. Mengubah kolom **Pegawai** di kartu
  “Kepala arsip” ikut memperbarui nama/NIP profil.
- Draft browser memakai kunci `ckp_draft:<id-profil>`, jadi draft rekan tidak
  muncul di profil lain.
- Hapus profil lewat halaman Profil; minimal satu profil harus tersisa.

## Publish-ready

Tanpa dialog PowerShell / path hardcode. Yang env-overridable:
`PORT`, `DATA_DIR`, `RCLONE_EXE`, `MAX_ZIP_MB` (default 1500).

## Catatan migrasi

- Program lama tidak dihapus/diubah — aman sebagai cadangan.
- `config.json` (header pegawai) disalin dari Generator; bulan depan cukup ubah
  periode + bulan, sisanya tetap.
- Draft tersimpan otomatis di `localStorage` browser (ditawarkan saat dibuka lagi).
