chrome.runtime.onInstalled.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

async function typeTextAsUser(tabId, { text, targetHint }) {
  const target = { tabId };
  const tab = await chrome.tabs.get(tabId);
  if (!tab.url?.startsWith('https://kipapp.bps.go.id/')) {
    throw new Error('Input langsung hanya diizinkan pada tab KipApp.');
  }
  if (typeof text !== 'string' || !text) {
    throw new Error('Teks input tidak valid.');
  }

  let attached = false;
  try {
    await chrome.debugger.attach(target, '1.3');
    attached = true;
    const send = (method, params) => chrome.debugger.sendCommand(target, method, params);

    const focusResult = await send('Runtime.evaluate', {
      expression: `(() => {
        const element = document.activeElement;
        if (!element) return null;
        return {
          tag: element.tagName,
          type: element.type || '',
          placeholder: element.getAttribute('placeholder') || '',
          ariaLabel: element.getAttribute('aria-label') || '',
          name: element.getAttribute('name') || '',
          editable: element.isContentEditable || /^(INPUT|TEXTAREA)$/.test(element.tagName)
        };
      })()`,
      returnByValue: true
    });
    const focused = focusResult.result?.value;
    if (!focused?.editable) {
      throw new Error(`Tidak ada kolom teks KipApp yang fokus (elemen: ${focused?.tag || 'tidak ada'}).`);
    }
    const focusedHint = focused.placeholder || focused.ariaLabel || focused.name || '';
    if (targetHint && focusedHint !== targetHint) {
      throw new Error(`Fokus berada di kolom “${focusedHint || focused.tag}”, bukan kolom “${targetHint}”.`);
    }

    await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Control', code: 'ControlLeft', modifiers: 2, windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17 });
    await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'a', code: 'KeyA', modifiers: 2, windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65 });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'a', code: 'KeyA', modifiers: 2, windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65 });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Control', code: 'ControlLeft', modifiers: 0, windowsVirtualKeyCode: 17, nativeVirtualKeyCode: 17 });
    await send('Input.insertText', { text });
    await send('Input.dispatchKeyEvent', { type: 'keyDown', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, nativeVirtualKeyCode: 9 });
    await send('Input.dispatchKeyEvent', { type: 'keyUp', key: 'Tab', code: 'Tab', windowsVirtualKeyCode: 9, nativeVirtualKeyCode: 9 });
    return { ok: true, focusedHint };
  } finally {
    if (attached) {
      try { await chrome.debugger.detach(target); } catch { /* The target may have closed while input was being sent. */ }
    }
  }
}

const PROFILE_STORAGE_KEY = 'ckp-companion-profiles-v1';
const STATE_KEY_PREFIX = 'ckp-companion-state-v2:';
// Kolom matriks sintetis — header HARUS cocok alias FIELD_DEFS di sidepanel.js
// agar guessHeaders/buildRecords (dan renderMapping) jalan tanpa perubahan.
const HANDOFF_HEADERS = ['No', 'Tanggal mulai', 'Tanggal selesai', 'Rencana kinerja', 'Kegiatan', 'Progres', 'Capaian', 'Bukti dukung'];
const HANDOFF_MAPPING = { tanggalMulai: 1, tanggalSelesai: 2, rencanaKinerja: 3, kegiatan: 4, progres: 5, capaian: 6, dataDukung: 7 };
const HANDOFF_MAX_ROWS = 500;

function stateKey(profileId) {
  return `${STATE_KEY_PREFIX}${profileId || 'utama'}`;
}

function handoffCell(text, url = '') {
  const normalizedText = String(text ?? '').trim();
  const normalizedUrl = String(url || '').trim();
  return { text: normalizedUrl || normalizedText, url: normalizedUrl, raw: normalizedText, format: '' };
}

function handoffIsoDate(value) {
  const text = String(value ?? '').trim();
  if (!text) return '';
  const iso = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (iso) return `${iso[1]}-${iso[2].padStart(2, '0')}-${iso[3].padStart(2, '0')}`;
  const numeric = text.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})$/);
  if (numeric) return `${numeric[3]}-${numeric[2].padStart(2, '0')}-${numeric[1].padStart(2, '0')}`;
  return text;
}

// Bangun state YANG SAMA bentuknya dengan hasil parseFile() di sidepanel.js
// (sheets+matrix+mapping, bukan records saja) supaya render()/renderMapping()/
// buildRecords() sidepanel bisa konsumsi langsung. Record dirakit dengan logika
// yang mirror buildRecords(): baris kosong dilewat, warnings per field kosong.
function buildHandoffState({ fileName, sheetName, rows, profileId, profileName, profileNip }) {
  const cleanRows = (Array.isArray(rows) ? rows : []).slice(0, HANDOFF_MAX_ROWS).map((row) => ({
    no: String(row?.no ?? '').trim(),
    tanggalMulai: handoffIsoDate(row?.tanggalMulai),
    tanggalSelesai: handoffIsoDate(row?.tanggalSelesai),
    rencanaKinerja: String(row?.rencanaKinerja ?? '').trim(),
    kegiatan: String(row?.kegiatan ?? '').trim(),
    progres: String(row?.progres ?? '').trim().replace(/\s*%\s*$/, '').replace(',', '.'),
    capaian: String(row?.capaian ?? '').trim(),
    dataDukung: String(row?.dataDukung ?? '').trim()
  })).filter((row) => [row.tanggalMulai, row.rencanaKinerja, row.kegiatan, row.progres, row.capaian, row.dataDukung].some(Boolean));
  if (!cleanRows.length) throw new Error('Tidak ada baris kegiatan valid dari CKP-App.');

  const name = String(sheetName || 'CKP-App').trim() || 'CKP-App';
  const matrix = [HANDOFF_HEADERS.map((header) => handoffCell(header))];
  cleanRows.forEach((row, index) => {
    matrix.push([
      handoffCell(row.no || String(index + 1)),
      handoffCell(row.tanggalMulai),
      handoffCell(row.tanggalSelesai),
      handoffCell(row.rencanaKinerja),
      handoffCell(row.kegiatan),
      handoffCell(row.progres),
      handoffCell(row.capaian),
      handoffCell(row.dataDukung, /^https?:\/\//i.test(row.dataDukung) ? row.dataDukung : '')
    ]);
  });
  const records = cleanRows.map((row, index) => {
    const record = {
      rowNumber: index + 2, // +1 header, +1 basis-1
      no: row.no || String(index + 1),
      tanggalMulai: row.tanggalMulai,
      tanggalSelesai: row.tanggalSelesai,
      rencanaKinerja: row.rencanaKinerja,
      kegiatan: row.kegiatan,
      progres: row.progres,
      capaian: row.capaian,
      dataDukung: row.dataDukung,
      status: 'pending',
      warnings: []
    };
    if (!record.tanggalMulai) record.warnings.push('Tanggal mulai belum diisi.');
    if (!record.rencanaKinerja) record.warnings.push('Rencana kinerja belum diisi.');
    if (!record.kegiatan) record.warnings.push('Uraian kegiatan belum diisi.');
    if (!record.progres) record.warnings.push('Progres belum diisi.');
    if (!record.capaian) record.warnings.push('Capaian belum diisi.');
    if (!record.dataDukung) record.warnings.push('Tautan bukti dukung belum diisi.');
    return record;
  });
  return {
    fileName: String(fileName || 'CKP-App handoff').trim() || 'CKP-App handoff',
    sheetNames: [name],
    sheets: [{ name, matrix, headerRow: 0, guessedMapping: { ...HANDOFF_MAPPING } }],
    selectedSheet: name,
    mapping: { ...HANDOFF_MAPPING },
    records,
    statusesBySheet: {},
    currentIndex: 0,
    handoffSource: 'ckp-app-web',
    handoffAt: Date.now(),
    profileId: String(profileId || '').trim(),
    profileName: String(profileName || '').trim(),
    profileNip: String(profileNip || '').trim(),
  };
}

function isLoopbackSender(sender) {
  const url = sender.url || sender.tab?.url || sender.origin || '';
  return /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//.test(url);
}

async function handleHandoff(message, sender) {
  if (!isLoopbackSender(sender)) throw new Error('Handoff hanya diterima dari CKP-App lokal (localhost).');

  // Profil dari CKP-App: id, nama, NIP. Sesi ekstensi disimpan per profil
  // supaya RK/kegiatan rekan sekantor tidak tercampur.
  const dimintaId = String(message.profileId || '').trim();
  const namaMasuk = String(message.profileName || '').trim();
  const nipMasuk = String(message.profileNip || '').trim();
  const tersimpan = await chrome.storage.local.get(PROFILE_STORAGE_KEY);
  let reg = tersimpan[PROFILE_STORAGE_KEY];
  if (!reg || !Array.isArray(reg.profiles) || !reg.profiles.length) {
    reg = { profiles: [], activeId: '' };
  }

  let profile = dimintaId ? reg.profiles.find((p) => p.id === dimintaId) : null;
  // Bila id beda (mis. profil dibuat manual di ekstensi), cocokkan lewat NIP/nama
  // agar tidak membuat profil ganda untuk pegawai yang sama.
  if (!profile && (nipMasuk || namaMasuk)) {
    profile = reg.profiles.find((p) =>
      (nipMasuk && String(p.nip || '').trim() === nipMasuk)
      || (namaMasuk && String(p.nama || '').trim().toLowerCase() === namaMasuk.toLowerCase())
    ) || null;
  }
  if (!profile) {
    profile = {
      id: dimintaId || (reg.profiles.find((p) => p.id === reg.activeId) ? reg.activeId : `ext-${Date.now().toString(36)}`),
      nama: namaMasuk || (reg.profiles[0] && reg.profiles[0].nama) || 'Pegawai CKP-App',
      nip: nipMasuk || '',
    };
    const sudahAda = reg.profiles.find((p) => p.id === profile.id);
    if (sudahAda) profile = sudahAda;
    else reg.profiles.push(profile);
  }
  if (namaMasuk) profile.nama = namaMasuk;
  if (nipMasuk) profile.nip = nipMasuk;
  reg.activeId = profile.id;

  const state = buildHandoffState({
    ...message,
    profileId: profile.id,
    profileName: profile.nama,
    profileNip: profile.nip,
  });
  await chrome.storage.local.set({ [PROFILE_STORAGE_KEY]: reg, [stateKey(profile.id)]: state });
  // Ping sidepanel bila sedang terbuka → langsung tampil tanpa buka-tutup.
  // Gagal diam = panel tertutup; user tetap melihat banner saat membukanya.
  try {
    await chrome.runtime.sendMessage({
      type: 'CKP_HANDOFF_LIVE',
      saved: state.records.length,
      fileName: state.fileName,
      profileId: profile.id,
      profileName: profile.nama,
    });
  } catch { /* panel tertutup, abaikan */ }
  return { ok: true, saved: state.records.length, profile: profile.nama };
}

// GAP 1-KLIK AUTOSTART PENUH (sengaja TIDAK diimplementasikan — autostart dinilai NOT low-risk):
// runBatch() hidup di sidepanel.js, terikat DOM sidepanel (render/busy/batchProgress)
// dan hanya jalan saat side panel terbuka. Service worker background tidak bisa
// mengambil alih dengan aman karena: (1) fill butuh tab KipApp aktif + user sudah
// login di tabel Pelaksanaan Kinerja; (2) save berurutan butuh jeda 450 ms dan
// konfirmasi visual per baris — tanpa sidepanel terbuka tidak ada yang melihat
// status filled/warnings, risiko simpan duplikat; (3) debugger input (typeTextAsUser)
// terikat gesture/konteks tab user. Memindah eksekutor ke background = duplikasi
// seluruh runBatch + channel progress sidepanel<->background + guard login —
// perubahan besar, bukan patch low-risk. Syarat autostart penuh: (a) pindahkan
// runBatch + pendingOrder + sendFillMessage ke background, (b) sidepanel jadi
// thin client progress via chrome.runtime.onMessage, (c) guard "tab KipApp
// terlihat + user login" sebelum baris pertama. Sampai itu ada: mode handoff
// (buka sidepanel -> data nongol -> klik Isi seperti biasa).

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'CKP_HANDOFF_RECORDS') {
    handleHandoff(message, sender).then(sendResponse).catch((error) => {
      sendResponse({ ok: false, error: error.message || 'Handoff gagal disimpan.' });
    });
    return true;
  }
  if (message?.type !== 'CKP_NATIVE_TEXT_INPUT') return false;
  const tabId = sender.tab?.id;
  const senderUrl = sender.url || sender.tab?.url || '';
  if (tabId === undefined || !senderUrl.startsWith('https://kipapp.bps.go.id/')) {
    sendResponse({ ok: false, error: 'Permintaan input bukan berasal dari halaman KipApp.' });
    return false;
  }

    typeTextAsUser(tabId, message).then(sendResponse).catch((error) => {
    sendResponse({ ok: false, error: error.message || 'Input keyboard Chrome gagal.' });
  });
  return true;
});
