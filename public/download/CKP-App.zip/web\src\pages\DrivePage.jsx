import { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { CircleCheck, CircleX, Copy, Download, FileText, Radio, RotateCcw, Search, Square, Upload, Wand2 } from 'lucide-react';
import { useApp } from '../store.jsx';
import { fmtBytes } from '../lib/format.js';
import { Button, Card, Empty, inputCls, Pill, SectionHead } from '../components/ui.jsx';
import { turunkan } from '../lib/derive.js';

const STATUS = {
  pending: { tone: 'wait', label: 'Menunggu' },
  uploading: { tone: 'run', label: 'Mengunggah' },
  success: { tone: 'ok', label: 'Sukses' },
  failed: { tone: 'bad', label: 'Gagal' },
};

async function salin(teks, toast, pesanOk) {
  try {
    await navigator.clipboard.writeText(teks);
    toast(pesanOk);
  } catch (e) {
    toast('Gagal menyalin otomatis.', 'err');
  }
}

export default function DrivePage() {
  const { s, go, toast, ulangiGagal, batalkanUpload, buatDraft } = useApp();
  const up = s.up;
  const d = turunkan(s);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');

  const daftar = useMemo(() => {
    const k = q.trim().toLowerCase();
    return up.items.filter((x) =>
      (!k || x.originalName.toLowerCase().includes(k) || (x.relativePath || '').toLowerCase().includes(k)) &&
      (!status || x.status === status));
  }, [up.items, q, status]);

  if (!up.items.length && !up.running) {
    return (
      <>
        <SectionHead eyebrow="Tahap 2 dari 4" title="Sinkron Drive" desc="Progres per berkas tampil di sini begitu upload dimulai." />
        <Card>
          <Empty
            icon={Radio}
            title="Belum ada upload yang berjalan"
            desc="Pilih file ZIP dan folder Drive di tahap pertama, lalu mulai upload. Progresnya akan muncul di sini secara langsung."
            action={<Button variant="primary" icon={Upload} onClick={() => go('upload')}>Ke tahap upload</Button>}
          />
        </Card>
      </>
    );
  }

  const persen = Math.round(up.percent || 0);
  const gagalN = up.items.filter((x) => x.status === 'failed').length;
  const suksesLinks = up.items.filter((x) => x.status === 'success' && x.link).map((x) => x.link);

  return (
    <>
      <SectionHead
        eyebrow="Tahap 2 dari 4"
        title="Sinkron Drive"
        desc={up.running ? 'Berkas diunggah bersamaan. Kamu bisa pindah tab, progres tetap berjalan.' : 'Upload selesai. Berkas yang gagal bisa diulang tanpa mengulang yang sudah sukses.'}
        right={
          up.running ? (
            <Button variant="danger" icon={Square} onClick={batalkanUpload}>Batalkan</Button>
          ) : gagalN > 0 ? (
            <Button variant="danger" icon={RotateCcw} onClick={ulangiGagal}>Ulangi {gagalN} yang gagal</Button>
          ) : null
        }
      />

      <Card className="mb-5 p-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="tnum text-[34px] leading-none font-extrabold tracking-[-0.03em] text-ink">
              {up.completed}<span className="text-muted">/{up.total || up.items.length}</span>
            </p>
            <p className="mt-2 text-[13px] text-muted">{up.meta}</p>
          </div>
          <div className="flex items-center gap-2">
            {up.running && <Pill tone="run">Live</Pill>}
            <span className="tnum text-[26px] font-extrabold text-accent-text">{persen}%</span>
          </div>
        </div>
        <div className="mt-5 h-2.5 overflow-hidden rounded-full bg-surface-3">
          <motion.div
            className={`relative h-full rounded-full ${up.running ? 'bg-glow shadow-[0_0_14px_var(--glow)]' : 'bg-accent-solid'}`}
            initial={false}
            animate={{ width: `${persen}%` }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            {up.running && <span className="absolute inset-0 animate-pulse rounded-full bg-white/15" />}
          </motion.div>
        </div>
        {up.eta && up.running && <p className="mt-2 text-[12px] text-faint">Perkiraan selesai: {up.eta}</p>}
        <p className="mt-2 text-[12px] text-faint">Folder: <span className="font-mono text-muted">{up.folder}</span></p>
      </Card>

      {up.done && up.summary && !up.summary.cancelled && (
        <ResultCard
          gagal={gagalN}
          ok={up.summary.ok}
          links={suksesLinks}
          xlsxPath={up.summary.xlsxPath}
          onUlang={ulangiGagal}
          onDraft={() => buatDraft(up.results.filter((r) => r.status === 'success' && r.link).map((r) => ({ namaFile: r.originalName, link: r.link })))}
          toast={toast}
          sudahDraft={s.draft.length > 0}
          onKeDraft={() => go('draft')}
          perluCek={d.perluCek}
        />
      )}

      <Card className="mt-5 overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-4">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
            <input className={`${inputCls} pl-10`} placeholder="Cari berkas…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <select className={`${inputCls} w-auto min-w-[160px]`} value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Semua status</option>
            <option value="success">Sukses</option>
            <option value="failed">Gagal</option>
            <option value="pending">Menunggu</option>
            <option value="uploading">Mengunggah</option>
          </select>
        </div>

        <div className="scroll-thin max-h-[480px] overflow-auto">
          <table className="w-full min-w-[640px] text-left text-[13px]">
            <thead className="sticky top-0 z-10 bg-surface text-[11px] font-bold tracking-[0.08em] text-faint uppercase">
              <tr className="border-b border-line">
                <th className="px-5 py-3 font-bold">Berkas</th>
                <th className="w-[170px] px-3 py-3 font-bold">Progres</th>
                <th className="w-[130px] px-3 py-3 font-bold">Status</th>
                <th className="w-[130px] px-5 py-3 text-right font-bold">Tautan</th>
              </tr>
            </thead>
            <tbody>
              {daftar.map((it) => {
                const st = STATUS[it.status] || STATUS.pending;
                const pct = it.status === 'success' || it.status === 'failed' ? 100 : it.status === 'uploading' ? 55 : 0;
                return (
                  <tr key={it.id} className="border-b border-line/70 transition hover:bg-surface-2/60">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-surface-3 text-muted"><FileText className="size-4" /></span>
                        <div className="min-w-0">
                          <p className="truncate font-mono text-[12.5px] text-ink">{it.originalName}</p>
                          <p className="truncate text-[11.5px] text-muted">{it.relativePath} · {fmtBytes(it.sizeBytes)}</p>
                          {it.status === 'failed' && it.error && <p className="mt-0.5 text-[11.5px] text-bad">{it.error}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-3">
                        <motion.div
                          className={`h-full rounded-full ${it.status === 'failed' ? 'bg-bad' : it.status === 'success' ? 'bg-ok' : 'bg-glow'} ${it.status === 'uploading' ? 'animate-pulse' : ''}`}
                          initial={false} animate={{ width: `${pct}%` }} transition={{ duration: 0.4 }}
                        />
                      </div>
                    </td>
                    <td className="px-3 py-3"><Pill tone={st.tone}>{st.label}</Pill></td>
                    <td className="px-5 py-3 text-right">
                      {it.status === 'success' && it.link ? (
                        <Button size="sm" variant="soft" icon={Copy} onClick={() => salin(it.link, toast, 'Link tersalin.')}>Salin</Button>
                      ) : it.status === 'success' ? <Ikon ok /> : it.status === 'failed' ? <Ikon /> : <span className="text-faint">–</span>}
                    </td>
                  </tr>
                );
              })}
              {daftar.length === 0 && (
                <tr><td colSpan={4} className="px-5 py-10 text-center text-muted">Tidak ada baris yang cocok.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </>
  );
}

function Ikon({ ok }) {
  return ok ? <CircleCheck className="ml-auto size-4 text-ok" /> : <CircleX className="ml-auto size-4 text-bad" />;
}

function ResultCard({ gagal, ok, links, xlsxPath, onUlang, onDraft, toast, sudahDraft, onKeDraft, perluCek }) {
  if (gagal > 0) {
    return (
      <Card className="flex flex-wrap items-center gap-4 border-bad/25 bg-bad-soft p-5">
        <div className="min-w-0 flex-1">
          <p className="text-[14.5px] font-bold text-ink">{gagal} berkas gagal</p>
          <p className="text-[13px] text-muted">Yang sukses tidak perlu diulang. Susun draft dari yang sudah berhasil lebih dulu.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="danger" icon={RotateCcw} onClick={onUlang}>Ulangi {gagal} yang gagal</Button>
          {ok > 0 && <Button variant="soft" icon={Wand2} onClick={onDraft}>Susun draft dari yang sukses</Button>}
          <Button variant="secondary" icon={Copy} onClick={() => salin(links.join('\n'), toast, `${links.length} link tersalin.`)} disabled={!links.length}>Salin {links.length} link</Button>
        </div>
      </Card>
    );
  }
  return (
    <Card className="flex flex-wrap items-center gap-4 border-ok/25 bg-ok-soft p-5">
      <div className="min-w-0 flex-1">
        <p className="text-[14.5px] font-bold text-ink">Semua {ok} berkas terunggah</p>
        <p className="text-[13px] text-muted">
          {sudahDraft
            ? (perluCek ? `Draft sudah tersusun — ${perluCek} baris perlu dicek.` : 'Draft sudah tersusun dan siap dikoreksi.')
            : 'Draft disusun otomatis dari berkas ini.'}
        </p>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button variant="primary" icon={Wand2} onClick={onKeDraft}>Buka draft</Button>
        <Button variant="secondary" icon={Copy} onClick={() => salin(links.join('\n'), toast, `${links.length} link tersalin.`)}>Salin semua link</Button>
        {xlsxPath && (
          <Button variant="secondary" icon={Download} onClick={() => window.open('/api/download?path=' + encodeURIComponent(xlsxPath), '_blank')}>Unduh laporan link</Button>
        )}
      </div>
    </Card>
  );
}
