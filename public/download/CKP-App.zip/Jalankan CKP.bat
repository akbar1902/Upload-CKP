@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CKP App

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ======================================================
    echo ERROR: Node.js tidak ditemukan di komputer ini.
    echo Silakan install Node.js dari https://nodejs.org/
    echo ======================================================
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo Install dependency pertama kali...
    call npm install
)

rem Cek hasilnya (bukan exit code npm, yang bisa bernilai aneh), supaya
rem kalau instalasi gagal kita berhenti dengan pesan yang jelas.
if not exist "node_modules" (
    echo ======================================================
    echo ERROR: instalasi dependency gagal ^(folder node_modules
    echo tidak terbentuk^). Periksa koneksi internet lalu jalankan
    echo file ini lagi.
    echo ======================================================
    pause
    exit /b 1
)

netstat -ano | findstr ":3230 " | findstr "LISTENING" >nul 2>nul
if %errorlevel% neq 0 (
    echo Memulai CKP App Engine di background...
    start "CKP App Engine" /min node src/server.js %*
) else (
    echo CKP App Engine sudah aktif di background.
)

rem Jangan buka browser sebelum server benar-benar siap.
rem Tunggu sampai http://localhost:3230 menjawab (maksimal 60 detik).
echo Menunggu CKP App siap...
set "SIAP=0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$batas=(Get-Date).AddSeconds(60); while((Get-Date) -lt $batas){ try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:3230/api/config'; if($r.StatusCode -eq 200){ exit 0 } } catch { }; Start-Sleep -Milliseconds 400 }; exit 1"
if not errorlevel 1 set "SIAP=1"
if "%SIAP%"=="0" goto belum_siap

rem Chrome lebih diutamakan karena extension CKP Companion biasanya dipasang di Chrome.
rem Kalau hanya ada Edge, extension tetap bisa dipasang di Edge.
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --app="http://localhost:3230" --window-size=1320,900
) else if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    start "" "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --app="http://localhost:3230" --window-size=1320,900
) else if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" (
    start "" "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" --app="http://localhost:3230" --window-size=1320,900
) else if exist "C:\Program Files\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files\Microsoft\Edge\Application\msedge.exe" --app="http://localhost:3230" --window-size=1320,900
) else if exist "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" (
    start "" "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe" --app="http://localhost:3230" --window-size=1320,900
) else (
    start "" "http://localhost:3230"
)

exit /b 0

:belum_siap
echo.
echo ======================================================
echo GAGAL: CKP App Engine tidak merespons di alamat
echo http://localhost:3230 setelah ditunggu 60 detik.
echo.
echo Untuk melihat pesan error-nya, jalankan manual di folder ini:
echo     node src/server.js
echo.
echo Kemungkinan penyebab: port 3230 dipakai aplikasi lain,
echo Node.js lambat start, atau dependency belum lengkap.
echo ======================================================
pause
exit /b 1
