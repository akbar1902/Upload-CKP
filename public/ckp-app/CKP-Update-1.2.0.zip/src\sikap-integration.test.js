'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  normalizeBaseUrl,
  periodeKeBulanTahun,
  normalizeNamaRk,
  cocokkanRkSikap,
  cariRkBelumCocok,
  buatClientUploadId,
} = require('./sikap-integration');

test('normalizeBaseUrl merapikan slash dan hanya menerima http/https', () => {
  assert.equal(normalizeBaseUrl('https://sikap.example.com/').url, 'https://sikap.example.com');
  assert.equal(normalizeBaseUrl(' http://localhost:3000/ ').url, 'http://localhost:3000');
  assert.equal(normalizeBaseUrl('https://contoh.id/sikap/').url, 'https://contoh.id/sikap');
  assert.equal(normalizeBaseUrl('ftp://contoh.id').ok, false);
  assert.equal(normalizeBaseUrl('').ok, false);
  assert.equal(normalizeBaseUrl('bukan-url').ok, false);
});

test('periodeKeBulanTahun membaca bulan Indonesia dan tahun data', () => {
  assert.deepEqual(periodeKeBulanTahun({ bulanPeriode: 'Oktober', tahunData: '2026' }), {
    ok: true,
    bulan: 10,
    tahun: 2026,
  });
  assert.equal(periodeKeBulanTahun({ bulanPeriode: '', tahunData: '2026' }).ok, false);
  assert.equal(periodeKeBulanTahun({ bulanPeriode: 'Oktober', tahunData: 'abc' }).ok, false);
});

test('normalizeNamaRk menyamakan tahun, tanda baca, dan spasi', () => {
  assert.equal(
    normalizeNamaRk('Terlaksananya Survei Harga Tahun 2026'),
    normalizeNamaRk('terlaksananya survei harga')
  );
  assert.equal(
    normalizeNamaRk('Terlaksananya Kegiatan (PST) 2026'),
    'terlaksananyakegiatanpst'
  );
});

test('cocokkanRkSikap menemukan RK walau penulisan tahun berbeda', () => {
  const rks = [
    { id: 'rk-1', rencana_kinerja: 'Terlaksananya Survei Harga Tahun 2026' },
    { id: 'rk-2', rencana_kinerja: 'Terlaksananya Pelayanan Statistik Terpadu (PST)' },
  ];
  assert.equal(cocokkanRkSikap(rks, 'Terlaksananya Survei Harga 2026').id, 'rk-1');
  assert.equal(cocokkanRkSikap(rks, 'terlaksananya pelayanan statistik terpadu').id, 'rk-2');
  assert.equal(cocokkanRkSikap(rks, 'RK tidak ada'), null);
});

test('cariRkBelumCocok mengembalikan RK lokal yang tidak ada di SIKAP', () => {
  const rks = [{ id: 'rk-1', rencana_kinerja: 'Terlaksananya Survei Harga Tahun 2026' }];
  const rows = [
    { rk: 'Terlaksananya Survei Harga 2026' },
    { rk: 'Terlaksananya Kegiatan Lain' },
    { rk: '' },
  ];
  assert.deepEqual(cariRkBelumCocok(rks, rows), ['Terlaksananya Kegiatan Lain']);
});

test('buatClientUploadId stabil untuk draft yang sama dan berubah saat isi berubah', () => {
  const header = { bulanPeriode: 'Oktober', tahunData: 2026, sheetName: 'CKP Oktober' };
  const rows = [{ kegiatan: 'Rapat', rk: 'RK A', tglAwal: 1, link: 'https://x' }];
  const a = buatClientUploadId(rows, header);
  const b = buatClientUploadId(rows, header);
  const c = buatClientUploadId([{ ...rows[0], kegiatan: 'Rapat lain' }], header);
  assert.equal(a, b);
  assert.notEqual(a, c);
  assert.match(a, /^[a-f0-9]{64}$/);
});
