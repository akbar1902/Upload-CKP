'use strict';

/**
 * Test pencocokan kata kunci RK. Jalankan: npm test
 * Fokus: kata kunci pendek seperti "SE" tidak boleh menyerobot "Susenas".
 */

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { suggestRK, cariKunciKustom } = require('./rk-matcher');

const rkList = JSON.parse(fs.readFileSync(path.join(__dirname, 'config', 'rk-list.json'), 'utf8'));
const SENSUS = 'Terlaksananya Kegiatan Sensus Ekonomi 2026';
const SUSENAS = 'Terlaksananya Kegiatan Survei Sosial Ekonomi Nasional (Susenas) Tahun 2026';
const aturanSE = [{ rk: SENSUS, kunci: ['SE'] }];

// kegiatan wajib diisi karena aturan bawaan membaca kegiatan (bukan nama file),
// sama seperti susunDraft() di server.
function top(namaFile, aturanKustom = aturanSE, kegiatan = '') {
  const hasil = suggestRK(kegiatan, rkList, 1, { namaFile, aturanKustom });
  return hasil[0] ? hasil[0].rk : '';
}

test('kata kunci SE menangkap singkatan SE / SE2026', () => {
  assert.equal(top('13 Oktober_Melakukan Pendataan ASN SE2026 di Membalong.jpeg', aturanSE, 'Melakukan Pendataan ASN SE2026 di Membalong'), SENSUS);
  assert.equal(top('2 Oktober_Ganti wilayah dan koordinat SE 2026.png', aturanSE, 'Ganti wilayah dan koordinat SE 2026'), SENSUS);
  assert.equal(top('1 Oktober_Penugasan SE.jpeg', aturanSE, 'Penugasan SE'), SENSUS);
});

test('kata kunci SE tidak menyerobot Susenas / Kesejahteraan', () => {
  assert.equal(
    top('5 Oktober_Melakukan Validasi Susenas.png', aturanSE, 'Melakukan Validasi Susenas'),
    SUSENAS
  );
  assert.notEqual(
    top('2 Oktober_Mengisi Survei Kesejahteraan Pegawai.png', aturanSE, 'Mengisi Survei Kesejahteraan Pegawai'),
    SENSUS
  );
});

test('aturan bawaan Susenas tetap jalan tanpa aturan kustom', () => {
  assert.equal(
    top('5 Oktober_Melakukan Validasi Susenas.png', [], 'Melakukan Validasi Susenas'),
    SUSENAS
  );
});

test('kata kunci frasa tetap dicocokkan', () => {
  const aturan = [{ rk: 'Terlaksananya Pelayanan Statistik Terpadu (PST)', kunci: ['pelayanan statistik'] }];
  assert.equal(
    top('3 Oktober_Melakukan Pelayanan Statistik untuk mahasiswa.png', aturan, 'Melakukan Pelayanan Statistik untuk mahasiswa'),
    'Terlaksananya Pelayanan Statistik Terpadu (PST)'
  );
});

test('kata kunci pendek tidak menangkap potongan kata lain', () => {
  const aturan = [{ rk: 'Terlaksananya Penerapan Budaya Organisasi (Apel Mingguan/Bulanan dan Apel/Upacara Hari Besar)', kunci: ['apel'] }];
  assert.equal(cariKunciKustom('4 oktober_menerima rapel gaji', aturan, rkList), null);
  assert.equal(cariKunciKustom('4 oktober_menerima rapel gaji', aturanSE, rkList), null);
  assert.equal(cariKunciKustom('1 oktober_apel pagi bersama', aturan, rkList), aturan[0].rk);
});

test('kegiatan tanpa kecocokan kuat tidak diberi RK asal-asalan', () => {
  const hasil = suggestRK('Mengisi Survei Kesejahteraan Pegawai', rkList, 3, {
    namaFile: '2 Oktober_Mengisi Survei Kesejahteraan Pegawai.png',
    aturanKustom: aturanSE,
  });
  assert.deepEqual(hasil, []);
});

// Daftar RK bisa berubah setelah ditarik dari SIKAP. Nama RK di aturan kustom
// lama mungkin tidak ada lagi, tetapi kata kuncinya harus tetap berguna dengan
// memilih RK terdekat yang tersedia.
const RK_SINKRON = [
  'Terlaksananya Penyusunan Publikasi/Laporan Sensus Ekonomi',
  'Terlaksananya Survei Sosial Ekonomi Nasional (Susenas) Tahun 2026',
  'Terlaksananya Konferensi Pers dan Pengacaraan Kehumasan Lainnya',
];

test('kata kunci SE tetap menemukan RK Sensus Ekonomi setelah daftar RK berubah', () => {
  const aturanLama = [{ rk: 'Terlaksananya Kegiatan Sensus Ekonomi 2026', kunci: ['SE'] }];
  const hasil = suggestRK('Ganti wilayah dan koordinat SE 2026', RK_SINKRON, 1, {
    namaFile: '2 Oktober_Ganti wilayah dan koordinat SE 2026.png',
    aturanKustom: aturanLama,
  });
  assert.equal(hasil[0]?.rk, 'Terlaksananya Penyusunan Publikasi/Laporan Sensus Ekonomi');
});

test('aturan bawaan SE tetap menemukan RK pengganti di daftar SIKAP', () => {
  const hasil = suggestRK('Mengisi keterangan pendapatan Usaha Besar (UB)', RK_SINKRON, 1, {
    namaFile: '2 Oktober_Mengisi keterangan pendapatan Usaha Besar (UB).png',
    aturanKustom: [],
  });
  assert.equal(hasil[0]?.rk, 'Terlaksananya Penyusunan Publikasi/Laporan Sensus Ekonomi');
});
