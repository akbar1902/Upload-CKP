import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import { Users } from 'lucide-react';
import { AppProvider, useApp } from './store.jsx';
import Sidebar from './components/Sidebar.jsx';
import { Toasts } from './components/ui.jsx';
import HasilLamaModal from './components/HasilLamaModal.jsx';
import UploadPage from './pages/UploadPage.jsx';
import DrivePage from './pages/DrivePage.jsx';
import DraftPage from './pages/DraftPage.jsx';
import ExportPage from './pages/ExportPage.jsx';
import KamusPage from './pages/KamusPage.jsx';
import KataKunciPage from './pages/KataKunciPage.jsx';
import RkPage from './pages/RkPage.jsx';
import ProfilPage from './pages/ProfilPage.jsx';

const HALAMAN = {
  upload: UploadPage,
  drive: DrivePage,
  draft: DraftPage,
  export: ExportPage,
  kamus: KamusPage,
  kunci: KataKunciPage,
  rk: RkPage,
  profil: ProfilPage,
};

export default function App() {
  return (
    <AppProvider>
      <MotionConfig reducedMotion="user">
        <Shell />
        <Toasts />
      </MotionConfig>
    </AppProvider>
  );
}

function Shell() {
  const { s } = useApp();
  const Page = HALAMAN[s.page] || UploadPage;
  return (
    <div className="min-h-screen lg:flex">
      <Sidebar />
      <main className="min-w-0 flex-1">
        <Topbar />
        <div className="mx-auto w-full max-w-[1500px] px-5 pt-2 pb-24 lg:px-10">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={s.page}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            >
              <Page />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      <HasilLamaModal />
    </div>
  );
}

function Topbar() {
  const { s, go, gantiProfil } = useApp();
  const h = s.header;
  const profil = s.profile;
  const nama = (profil && profil.nama) || (h.pegawai || '').replace(/^\[\d+\]\s*/, '').trim();
  const bulan = h.bulanPeriode || '';
  return (
    <header className="sticky top-0 z-30 flex items-center justify-end gap-3 px-5 py-4 lg:px-10">
      <div className="hidden items-center gap-2 rounded-full border border-line bg-surface/80 px-3 py-1.5 text-[12px] font-semibold text-muted backdrop-blur md:flex">
        <span className="tnum">CKP · {bulan || 'belum pilih bulan'}</span>
      </div>
      <div className="flex min-w-0 items-center gap-2 rounded-full border border-line bg-surface/80 py-1 pr-2 pl-1 backdrop-blur">
        <span className="grid size-8 shrink-0 place-items-center rounded-full bg-accent-solid text-[12px] font-extrabold text-white">
          {(nama[0] || '?').toUpperCase()}
        </span>
        <label className="sr-only" htmlFor="pilih-profil">Profil pegawai</label>
        <select
          id="pilih-profil"
          value={(profil && profil.id) || ''}
          onChange={(e) => gantiProfil(e.target.value)}
          className="max-w-[170px] cursor-pointer truncate bg-transparent text-[12.5px] font-semibold text-ink outline-none sm:max-w-[240px]"
          title="Ganti profil pegawai"
        >
          {s.profiles.length === 0 && <option value="">{nama || 'Memuat profil…'}</option>}
          {s.profiles.map((p) => <option key={p.id} value={p.id}>{p.nama}</option>)}
        </select>
        <button
          type="button"
          onClick={() => go('profil')}
          className="grid size-7 shrink-0 place-items-center rounded-full text-muted transition hover:bg-surface-2 hover:text-ink"
          title="Kelola profil pegawai"
          aria-label="Kelola profil pegawai"
        >
          <Users className="size-4" />
        </button>
      </div>
    </header>
  );
}
