import { useEffect, useMemo, useRef, useState } from 'react';
import { Check, Plus, Search, Sparkles } from 'lucide-react';
import { Modal, inputCls } from './ui.jsx';

function sorot(teks, k) {
  if (!k) return teks;
  const i = teks.toLowerCase().indexOf(k);
  if (i < 0) return teks;
  return (
    <>
      {teks.slice(0, i)}
      <mark className="rounded bg-accent/25 px-0.5 text-inherit">{teks.slice(i, i + k.length)}</mark>
      {teks.slice(i + k.length)}
    </>
  );
}

// Picker RK bergaya command palette: cari, ↑↓ navigasi, Enter pilih.
// usulan   → saran dari sistem (tampil di atas saat kotak cari kosong)
// used     → Set RK yang sudah punya aturan (diberi label, tetap bisa dipilih)
// onAddRk  → bila diisi, user bisa menambahkan RK baru yang belum ada di daftar
export default function RkPicker({ open, onClose, onPick, rkList, usulan = [], terpilih = '', title = 'Pilih Rencana Kinerja', desc, used = null, onAddRk = null }) {
  const [q, setQ] = useState('');
  const [hot, setHot] = useState(0);
  const [menambah, setMenambah] = useState(false);
  const listRef = useRef(null);

  useEffect(() => { if (open) { setQ(''); setHot(0); setMenambah(false); } }, [open]);
  useEffect(() => { setHot(0); }, [q]);

  const k = q.trim().toLowerCase();
  const rekom = useMemo(() => (k ? [] : usulan.filter((u) => rkList.includes(u))), [k, usulan, rkList]);
  const semua = useMemo(() => {
    const sisa = rkList.filter((x) => !rekom.includes(x) && (!k || x.toLowerCase().includes(k)));
    return sisa.slice(0, k ? 120 : 400);
  }, [rkList, rekom, k]);
  const flat = [...rekom, ...semua];

  // RK boleh ditambah bila teks pencarian belum persis sama dengan RK mana pun.
  const sudahAda = useMemo(() => rkList.some((x) => String(x).toLowerCase() === k), [rkList, k]);
  const bisaTambah = !!onAddRk && q.trim().length >= 3 && !sudahAda;
  // Baris "Tambah RK baru" hanya masuk navigasi keyboard bila tidak ada hasil
  // lain, supaya Enter tidak salah menambah RK saat user mau memilih hasil.
  const offset = bisaTambah && flat.length === 0 ? 1 : 0;
  const total = flat.length + offset;
  const addHot = offset === 1 && hot === 0;

  useEffect(() => {
    listRef.current?.querySelector('[data-hot="true"]')?.scrollIntoView({ block: 'nearest' });
  }, [hot]);

  const pilih = (v) => { onPick(v); onClose(); };
  const tambah = async () => {
    if (!bisaTambah || menambah) return;
    setMenambah(true);
    try {
      const nama = await onAddRk(q.trim());
      if (nama) pilih(nama);
    } catch (e) { /* toast sudah ditampilkan store */ } finally {
      setMenambah(false);
    }
  };
  const baris = (rk, idx, saran) => {
    const aktif = rk === terpilih;
    const hot_ = idx === hot;
    return (
      <button
        key={`${saran ? 's' : 'a'}-${rk}`}
        type="button"
        data-hot={hot_}
        onMouseEnter={() => setHot(idx)}
        onClick={() => pilih(rk)}
        className={`flex w-full items-start gap-3 rounded-xl px-3.5 py-2.5 text-left text-[13.5px] leading-snug transition ${hot_ ? 'bg-surface-3' : ''} ${aktif ? 'font-semibold text-accent-text' : 'text-ink'}`}
      >
        <span className={`mt-0.5 grid size-4 shrink-0 place-items-center rounded-full ${aktif ? 'bg-accent-solid text-white' : 'ring-1 ring-inset ring-line'}`}>
          {aktif && <Check className="size-3" strokeWidth={3} />}
        </span>
        <span className="min-w-0 flex-1">
          {sorot(rk, k)}
          {used && used.has(rk) && <span className="ml-2 rounded-md bg-accent-soft px-1.5 py-0.5 text-[10.5px] font-bold text-accent-text">sudah ada</span>}
        </span>
      </button>
    );
  };

  return (
    <Modal open={open} onClose={onClose} title={title} desc={desc} width="max-w-2xl">
      <div className="relative mb-4">
        <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
        <input
          autoFocus
          className={`${inputCls} py-3 pl-10`}
          placeholder="Ketik untuk mencari RK… (boleh RK baru)"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') { e.preventDefault(); setHot((h) => Math.min(total - 1, h + 1)); }
            else if (e.key === 'ArrowUp') { e.preventDefault(); setHot((h) => Math.max(0, h - 1)); }
            else if (e.key === 'Enter') {
              e.preventDefault();
              if (addHot) tambah();
              else if (flat[hot - offset]) pilih(flat[hot - offset]);
            }
          }}
        />
      </div>
      <div ref={listRef} className="scroll-thin -mx-1 max-h-[52vh] overflow-y-auto px-1">
        {bisaTambah && (
          <button
            type="button"
            data-hot={addHot}
            onMouseEnter={() => { if (offset === 1) setHot(0); }}
            onClick={tambah}
            disabled={menambah}
            className={`mb-2 flex w-full items-start gap-3 rounded-xl border border-dashed px-3.5 py-2.5 text-left text-[13.5px] leading-snug transition disabled:opacity-60 ${addHot ? 'border-accent/60 bg-accent-soft text-accent-text' : 'border-line-strong text-muted hover:border-accent/50 hover:text-ink'}`}
          >
            <span className="mt-0.5 grid size-4 shrink-0 place-items-center rounded-full ring-1 ring-inset ring-current">
              <Plus className="size-2.5" strokeWidth={3} />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-semibold">
                {menambah ? 'Menyimpan RK…' : <>Tambah RK baru: <span className="text-ink">“{q.trim()}”</span></>}
              </span>
              <span className="mt-0.5 block text-[11.5px] font-normal opacity-80">Belum ada di daftar. Setelah disimpan, RK ini bisa dipakai lagi kapan saja.</span>
            </span>
          </button>
        )}
        {rekom.length > 0 && (
          <>
            <p className="mb-1 flex items-center gap-1.5 px-2 pt-1 text-[10.5px] font-bold tracking-[0.12em] text-faint uppercase">
              <Sparkles className="size-3" /> Rekomendasi untuk baris ini
            </p>
            {rekom.map((rk, i) => baris(rk, offset + i, true))}
            <p className="mt-3 mb-1 px-2 text-[10.5px] font-bold tracking-[0.12em] text-faint uppercase">Semua Rencana Kinerja</p>
          </>
        )}
        {rekom.length === 0 && (
          <p className="mb-1 px-2 pt-1 text-[10.5px] font-bold tracking-[0.12em] text-faint uppercase">
            {k ? `Hasil (${semua.length})` : 'Semua Rencana Kinerja'}
          </p>
        )}
        {semua.map((rk, i) => baris(rk, offset + rekom.length + i, false))}
        {total === 0 && <p className="px-3 py-8 text-center text-[13px] text-muted">Tidak ketemu — coba kata lain.</p>}
      </div>
      <p className="mt-3 border-t border-line pt-3 text-[11.5px] text-faint">↑ ↓ untuk pindah · Enter untuk pilih · Esc untuk batal</p>
    </Modal>
  );
}
