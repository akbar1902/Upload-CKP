import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ChevronRight, Folder, FolderPlus, Home } from 'lucide-react';
import { api, kirimJson } from '../lib/api.js';
import { Button, Modal, inputCls } from './ui.jsx';
import { useApp } from '../store.jsx';

export default function FolderPicker({ open, onClose, onPick }) {
  const { s, toast } = useApp();
  const [path, setPath] = useState('');
  const [folders, setFolders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');
  const [baru, setBaru] = useState('');

  const muat = async (p) => {
    setPath(p);
    setLoading(true);
    setErr('');
    try {
      const r = await api(`/api/drive/folders?remote=${encodeURIComponent(s.rclone.remote)}&path=${encodeURIComponent(p)}`);
      setFolders(r.folders || []);
    } catch (e) {
      setFolders([]);
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { if (open) muat(''); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [open]);

  const segmen = path ? path.split('/') : [];
  const buatFolder = async () => {
    const nama = baru.trim();
    if (!nama) return toast('Isi nama folder dulu.', 'warn');
    try {
      await api('/api/drive/create-folder', kirimJson({ remote: s.rclone.remote, parentPath: path, folderName: nama }));
      setBaru('');
      toast(`Folder “${nama}” dibuat.`);
      muat(path);
    } catch (e) { toast(e.message, 'err'); }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Pilih folder Google Drive"
      desc="Masuk ke folder tujuan, lalu pakai folder itu."
      width="max-w-lg"
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>Batal</Button>
          <Button variant="primary" disabled={!path} onClick={() => { onPick(path); onClose(); }}>Pakai folder ini</Button>
        </>
      }
    >
      <div className="mb-3 flex flex-wrap items-center gap-1 text-[13px]">
        <button type="button" onClick={() => muat('')} className="inline-flex items-center gap-1 rounded-lg px-2 py-1 font-semibold text-accent-text hover:bg-accent-soft">
          <Home className="size-3.5" /> Drive saya
        </button>
        {segmen.map((c, i) => (
          <span key={i} className="flex items-center gap-1">
            <ChevronRight className="size-3.5 text-faint" />
            <button type="button" onClick={() => muat(segmen.slice(0, i + 1).join('/'))} className="rounded-lg px-2 py-1 font-semibold text-accent-text hover:bg-accent-soft">{c}</button>
          </span>
        ))}
      </div>

      <div className="scroll-thin min-h-[200px] max-h-[300px] overflow-y-auto rounded-xl border border-line bg-surface-2 p-1.5">
        {loading && <p className="px-3 py-6 text-center text-[13px] text-muted">Memuat folder…</p>}
        {!loading && err && <p className="px-3 py-6 text-center text-[13px] text-bad">{err}</p>}
        {!loading && !err && folders.length === 0 && <p className="px-3 py-6 text-center text-[13px] text-muted">Folder kosong. Buat folder baru di bawah.</p>}
        {!loading && !err && folders.map((f, i) => (
          <motion.button
            key={f}
            type="button"
            initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: Math.min(i * 0.015, 0.2) }}
            onClick={() => muat(path ? `${path}/${f}` : f)}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-[13.5px] font-medium text-ink transition hover:bg-surface-3"
          >
            <Folder className="size-4 text-accent-text" />
            <span className="flex-1 truncate">{f}</span>
            <ChevronRight className="size-4 text-faint" />
          </motion.button>
        ))}
      </div>

      <div className="mt-4 flex gap-2">
        <input className={inputCls} placeholder="Nama folder baru di lokasi ini" value={baru} onChange={(e) => setBaru(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') buatFolder(); }} />
        <Button variant="secondary" icon={FolderPlus} onClick={buatFolder}>Buat</Button>
      </div>
    </Modal>
  );
}
