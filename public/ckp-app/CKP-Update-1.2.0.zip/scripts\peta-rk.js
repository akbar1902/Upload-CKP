'use strict';
// Generator "Peta RK per pegawai".
// Sumber: Dataset RK (14 xlsx) + ckp_entries SIKAP + master_kegiatan_anggota.
// Output:
//   CKP-App/src/config/rk-pegawai.json
//   <Project CKP>/../Default Project/Peta RK Pegawai.xlsx
//
// Jalankan: node scripts/peta-rk.js
const fs = require('fs');
const os = require('os');
const path = require('path');
const ExcelJS = require('exceljs');

const ROOT = path.resolve(__dirname, '..', '..');
const DATASET_DIR = path.join(ROOT, 'SIKAP', 'Dataset RK');
const CKP_APP = path.join(ROOT, 'CKP-App');

const norm = (s) => String(s || '')
  .toLowerCase()
  .replace(/\btahun\s*20\d{2}\b/g, '')
  .replace(/\b20\d{2}\b/g, '')
  .replace(/[^a-z0-9]/g, '');
const rapikan = (s) => String(s || '').replace(/\s+/g, ' ').trim();

function decodeEntities(v) {
  let s = String(v ?? '');
  for (let i = 0; i < 3; i++) {
    s = s.replace(/&amp;/gi, '&').replace(/&quot;/gi, '"').replace(/&#39;/gi, "'")
      .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&nbsp;/gi, ' ');
  }
  return s;
}

function splitPoints(raw) {
  const out = [];
  const seen = new Set();
  for (const line of decodeEntities(raw).replace(/\r\n?/g, '\n').split('\n')) {
    const t = line.trim();
    if (!t) continue;
    if (/^[\u2022\u2023\u25AA\u25E6\u00B7\u25CF\u25CB\-\*]$/.test(t)) continue;
    const text = rapikan(t.replace(/^[\u2022\u2023\u25AA\u25E6\u00B7\u25CF\u25CB\-\*]\s*/, ''));
    const key = text.toLowerCase();
    if (!text || seen.has(key)) continue;
    seen.add(key);
    out.push(text);
  }
  return out;
}

const extractNip = (v) => { const m = String(v ?? '').match(/\[([^\]]+)\]/); return m ? m[1].trim() : ''; };
const extractNama = (v) => rapikan(String(v ?? '').replace(/^\s*\[[^\]]+\]\s*/, ''));
const isKetua = (v) => /ketua/i.test(String(v ?? '').trim());

async function parseDataset() {
  const files = fs.readdirSync(DATASET_DIR).filter((f) => /\.xlsx?$/i.test(f));
  const employees = new Map();
  const teams = [];

  for (const file of files) {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.readFile(path.join(DATASET_DIR, file));
    const ws = wb.worksheets.find((w) => w.name === 'Matriks') || wb.worksheets[0];
    const rows = [];
    for (let r = 1; r <= ws.rowCount; r++) {
      const row = ws.getRow(r);
      const vals = [];
      for (let c = 1; c <= ws.columnCount; c++) vals.push(row.getCell(c).value);
      rows.push(vals);
    }
    const header = rows[0] || [];
    let pegawaiIdx = header.findIndex((h) => /pegawai/i.test(String(h ?? '')));
    if (pegawaiIdx < 0) pegawaiIdx = 0;
    let statusIdx = header.findIndex((h) => /status/i.test(String(h ?? '')));
    if (statusIdx < 0) statusIdx = 2;
    const rkCols = [];
    header.forEach((h, i) => { if (/rencana\s*kinerja/i.test(String(h ?? ''))) rkCols.push(i); });
    if (!rkCols.length) for (let i = statusIdx + 1; i < header.length; i++) rkCols.push(i);

    const teamName = file.replace(/\.xlsx?$/i, '').trim();
    const dataRows = rows.slice(1);
    const ketuaRow = dataRows.find((r) => isKetua(r?.[statusIdx]));
    if (!ketuaRow) { console.warn('Tanpa baris ketua:', file); continue; }

    const ketua = { nip: extractNip(ketuaRow[pegawaiIdx]), nama: extractNama(ketuaRow[pegawaiIdx]) };
    const parentByCol = new Map();
    for (const c of rkCols) {
      const rk = rapikan(ketuaRow[c]);
      if (rk) parentByCol.set(c, rk);
    }

    function rec(nip, nama, jabatan) {
      const key = nip ? `nip:${nip}` : `nama:${nama.toLowerCase()}`;
      if (!employees.has(key)) {
        employees.set(key, {
          nip, nama, jabatan: '', teams: [], ketuaTeams: [], entries: [],
          _seen: new Set(),
        });
      }
      const e = employees.get(key);
      if (nama && nama.length >= e.nama.length) e.nama = nama;
      if (jabatan && jabatan.length >= e.jabatan.length) e.jabatan = jabatan;
      if (!e.teams.includes(teamName)) e.teams.push(teamName);
      return e;
    }

    const ketuaRec = rec(ketua.nip, ketua.nama, ketuaRow[1]);
    if (!ketuaRec.ketuaTeams.includes(teamName)) ketuaRec.ketuaTeams.push(teamName);
    for (const parent of parentByCol.values()) {
      const k = `rk-utama|${norm(parent)}|${teamName}`;
      if (ketuaRec._seen.has(k)) continue;
      ketuaRec._seen.add(k);
      ketuaRec.entries.push({ nama: parent, parent, jenis: 'rk-utama', team: teamName });
    }

    for (const row of dataRows) {
      if (!row || row === ketuaRow) continue;
      if (isKetua(row[statusIdx])) continue;
      const nama = extractNama(row[pegawaiIdx]);
      if (!nama) continue;
      const nip = extractNip(row[pegawaiIdx]);
      const e = rec(nip, nama, row[1]);
      for (const c of rkCols) {
        const parent = parentByCol.get(c);
        if (!parent) continue;
        for (const text of splitPoints(row[c])) {
          const k = `sub-rk|${norm(text)}|${norm(parent)}|${teamName}`;
          if (e._seen.has(k)) continue;
          e._seen.add(k);
          e.entries.push({ nama: text, parent, jenis: 'sub-rk', team: teamName });
        }
      }
    }

    teams.push({ team: teamName, ketua, parents: [...parentByCol.values()] });
  }

  for (const e of employees.values()) delete e._seen;
  return { employees: [...employees.values()], teams };
}

const env = fs.readFileSync(path.join(ROOT, 'SIKAP', '.env.local'), 'utf8');
const getEnv = (k) => (env.match(new RegExp('^' + k + '=(.*)$', 'm')) || [])[1].trim();
const SUPABASE = getEnv('NEXT_PUBLIC_SUPABASE_URL');
const KEY = getEnv('SUPABASE_SERVICE_ROLE_KEY');

async function apiSemua(pathname) {
  const out = [];
  for (let offset = 0; ; offset += 1000) {
    const res = await fetch(`${SUPABASE}/rest/v1/${pathname}&limit=1000&offset=${offset}`, {
      headers: { apikey: KEY, Authorization: `Bearer ${KEY}` },
    });
    if (!res.ok) throw new Error(pathname + ' → ' + res.status + ' ' + (await res.text()).slice(0, 200));
    const rows = await res.json();
    out.push(...rows);
    if (rows.length < 1000) break;
  }
  return out;
}

const namaBersih = (s) => String(s || '')
  .toLowerCase()
  .replace(/\[[^\]]*\]/g, ' ')
  .replace(/[.,]/g, ' ')
  .replace(/\b(s\.?tr\.?stat|s\.?tr|sst|s\.?si|ssi|m\.?m|m\.?si|m\.?e\.?k\.?k|m\.?se|mssc|a\.?md\.?stat|a\.?md|s\.?a\.?p|se|s\.?kom|m\.?ak|m\.?t)\b/g, ' ')
  .replace(/\s+/g, ' ')
  .trim();
const tokensNama = (s) => namaBersih(s).split(' ').filter((w) => w.length >= 3);
function skorNama(a, b) {
  const ta = new Set(tokensNama(a)), tb = new Set(tokensNama(b));
  if (!ta.size || !tb.size) return 0;
  let same = 0; for (const t of ta) if (tb.has(t)) same++;
  return same / Math.max(ta.size, tb.size);
}

(async () => {
  const dataset = await parseDataset();

  // Pegawai yang sudah pindah — tidak dipakai lagi di peta.
  const DIKELUARKAN = new Set([
    '340061956', // Nadiyah Hanifah
    '340062630', // Nurzikri Saputra
    '340057703', // Ghaida Nasria Azzahra
    '340059212', // Tira Makhmurian
  ]);
  // NIP lama → NIP profil yang dipakai (orang yang sama, gelar berubah).
  const ALIAS_NIP = new Map([
    ['340058503', '340019162'], // Susanti SST → Susanti SST, M.M.
  ]);

  const byNip = new Map(dataset.employees.map((e) => [e.nip, e]));
  for (const [dari, ke] of ALIAS_NIP) {
    const a = byNip.get(dari);
    const b = byNip.get(ke);
    if (!a || !b) continue;
    const seen = new Set(b.entries.map((x) => `${norm(x.nama)}|${norm(x.parent)}|${x.team}`));
    for (const en of a.entries) {
      const k = `${norm(en.nama)}|${norm(en.parent)}|${en.team}`;
      if (seen.has(k)) continue;
      seen.add(k);
      b.entries.push(en);
    }
    for (const t of a.teams) if (!b.teams.includes(t)) b.teams.push(t);
    for (const t of a.ketuaTeams) if (!b.ketuaTeams.includes(t)) b.ketuaTeams.push(t);
    if (!b.jabatan && a.jabatan) b.jabatan = a.jabatan;
  }
  dataset.employees = dataset.employees.filter(
    (e) => !DIKELUARKAN.has(e.nip) && !ALIAS_NIP.has(e.nip),
  );

  const [users, parents, subs, uploads, entries] = await Promise.all([
    apiSemua('users?select=id,nip,full_name,role&order=id'),
    apiSemua('rk_ketua_tim_mapping?select=id,rencana_kinerja,tim_kerja,tahun,is_active&order=id'),
    apiSemua('master_kegiatan_anggota?select=user_id,kegiatan_nama,rk_id&order=user_id'),
    apiSemua('ckp_uploads?select=id,user_id&order=id'),
    apiSemua('ckp_entries?select=upload_id,rencana_kinerja,rk_ketua_tim_id&order=upload_id'),
  ]);

  const parentById = new Map(parents.map((p) => [String(p.id), p]));
  const aktif = parents.filter((p) => p.is_active && (p.tahun == null || p.tahun === 2026));
  const aktifIndex = new Map();
  for (const p of aktif) { const k = norm(p.rencana_kinerja); if (k && !aktifIndex.has(k)) aktifIndex.set(k, p); }

  const uploadUser = new Map(uploads.map((u) => [String(u.id), String(u.user_id)]));
  const uploadPerUser = new Map();
  for (const e of entries) {
    const userId = uploadUser.get(String(e.upload_id));
    if (!userId) continue;
    const nama = rapikan(e.rencana_kinerja);
    if (!nama) continue;
    if (!uploadPerUser.has(userId)) uploadPerUser.set(userId, new Map());
    const map = uploadPerUser.get(userId);
    const k = norm(nama);
    if (!map.has(k)) map.set(k, { nama, parents: new Map() });
    const parent = parentById.get(String(e.rk_ketua_tim_id || ''));
    if (parent) {
      const rec = map.get(k);
      rec.parents.set(parent.rencana_kinerja, (rec.parents.get(parent.rencana_kinerja) || 0) + 1);
    }
  }

  const subPerUser = new Map();
  const subGlobal = new Map(); // norm(sub-rk) -> Set(parentName)
  for (const s of subs) {
    const userId = String(s.user_id);
    const k = norm(s.kegiatan_nama);
    if (!k) continue;
    const parent = parentById.get(String(s.rk_id || ''));
    const parentName = parent?.rencana_kinerja || '';
    if (!subGlobal.has(k)) subGlobal.set(k, new Set());
    if (parentName) subGlobal.get(k).add(parentName);
    if (!userId) continue;
    if (!subPerUser.has(userId)) subPerUser.set(userId, new Map());
    const map = subPerUser.get(userId);
    if (!map.has(k)) map.set(k, new Set());
    if (parentName) map.get(k).add(parentName);
  }

  const profiles = JSON.parse(fs.readFileSync(path.join(CKP_APP, 'data', 'profiles.json'), 'utf8')).profiles || [];
  const profileByNip = new Map(profiles.map((p) => [String(p.nip), p]));

  // Greedy matching nama → akun SIKAP (satu akun dipakai sekali).
  const kandidat = [];
  for (const emp of dataset.employees) {
    for (const u of users) {
      const s = skorNama(emp.nama, u.full_name);
      if (s >= 0.5) kandidat.push({ emp, user: u, skor: s });
    }
  }
  kandidat.sort((a, b) => b.skor - a.skor);
  const empUser = new Map();
  const userDipakai = new Set();
  for (const k of kandidat) {
    const empKey = k.emp.nip || k.emp.nama;
    if (empUser.has(empKey) || userDipakai.has(k.user.id)) continue;
    empUser.set(empKey, { user: k.user, skor: k.skor });
    userDipakai.add(k.user.id);
  }

  const hasil = [];
  for (const emp of dataset.employees) {
    const empKey = emp.nip || emp.nama;
    const match = empUser.get(empKey);
    const user = match?.user || null;

    const entriesOut = [];
    const seenNama = new Set();

    for (const e of emp.entries) {
      const k = norm(e.nama);
      const subMap = user ? subPerUser.get(String(user.id)) : null;
      const parentSendiri = subMap && subMap.get(k) ? [...subMap.get(k)] : [];
      const parentGlobal = subGlobal.get(k) ? [...subGlobal.get(k)] : [];
      let terdaftarSendiri;
      let terdaftarGlobal;
      if (e.jenis === 'rk-utama') {
        terdaftarSendiri = aktifIndex.has(k);
        terdaftarGlobal = aktifIndex.has(k);
      } else {
        terdaftarSendiri = Boolean(user && subMap && subMap.has(k));
        terdaftarGlobal = subGlobal.has(k);
      }
      let catatan = '';
      if (parentSendiri.length === 1 && norm(parentSendiri[0]) !== norm(e.parent)) {
        catatan = `Parent di SIKAP: ${parentSendiri[0]}`;
      }
      if (parentSendiri.length > 1) catatan = `Parent ganda di SIKAP: ${parentSendiri.join(' | ')}`;
      entriesOut.push({
        nama: e.nama, parent: e.parent, jenis: e.jenis, sumber: ['dataset'], tim: [e.team],
        baru: false,
        terdaftarSendiri, terdaftarGlobal,
        parentAktif: aktifIndex.has(norm(e.parent)),
        catatan,
      });
      seenNama.add(k);
    }

    if (user) {
      const up = uploadPerUser.get(String(user.id)) || new Map();
      for (const [k, rec] of up) {
        if (seenNama.has(k)) {
          const row = entriesOut.find((x) => norm(x.nama) === k);
          if (row && !row.sumber.includes('upload')) row.sumber.push('upload');
          continue;
        }
        const parentNames = [...rec.parents.entries()].sort((a, b) => b[1] - a[1]).map(([n]) => n);
        const parent = parentNames[0] || '';
        const parentMaster = aktifIndex.get(k);
        const jenis = parentMaster ? 'rk-utama' : 'sub-rk';
        const terdaftarSendiri = jenis === 'rk-utama'
          ? true
          : Boolean(subPerUser.get(String(user.id))?.has(k));
        entriesOut.push({
          nama: rec.nama, parent, jenis, sumber: ['upload'], tim: [],
          baru: jenis !== 'rk-utama',
          terdaftarSendiri,
          terdaftarGlobal: jenis === 'rk-utama' ? true : subGlobal.has(k),
          parentAktif: Boolean(parent && aktifIndex.has(norm(parent))),
          catatan: jenis === 'rk-utama'
            ? 'Diupload memakai nama RK Ketua Tim (bukan Sub-RK)'
            : (parentNames.length > 1 ? `Parent ganda: ${parentNames.join(' | ')}` : ''),
        });
      }
    }

    const dedup = new Map();
    for (const x of entriesOut) {
      const k = norm(x.nama) + '|' + norm(x.parent);
      if (!dedup.has(k)) dedup.set(k, x);
      else {
        const prev = dedup.get(k);
        for (const s of x.sumber) if (!prev.sumber.includes(s)) prev.sumber.push(s);
        for (const t of x.tim) if (!prev.tim.includes(t)) prev.tim.push(t);
        if (x.catatan && !prev.catatan) prev.catatan = x.catatan;
      }
    }
    const rks = [...dedup.values()].sort((a, b) => a.nama.localeCompare(b.nama, 'id'));

    hasil.push({
      nip: emp.nip,
      nama: emp.nama,
      jabatan: emp.jabatan,
      profileId: profileByNip.get(emp.nip)?.id || null,
      nipSikap: user?.nip || null,
      userIdSikap: user?.id || null,
      skorNama: +(match?.skor || 0).toFixed(2),
      tim: emp.teams,
      ketuaTim: emp.ketuaTeams,
      jumlahRk: rks.length,
      rks,
    });
  }

  const ringkas = {
    generatedAt: new Date().toISOString(),
    tahun: 2026,
    sumber: 'Dataset RK (14 file xlsx) + ckp_entries SIKAP (RK yang pernah diupload)',
    jumlahPegawai: hasil.length,
    jumlahRkUnik: new Set(hasil.flatMap((e) => e.rks.map((r) => norm(r.nama)))).size,
    pegawai: hasil,
  };

  fs.writeFileSync(path.join(os.tmpdir(), 'peta-rk.json'), JSON.stringify(hasil, null, 1));
  fs.writeFileSync(path.join(CKP_APP, 'src', 'config', 'rk-pegawai.json'), JSON.stringify(ringkas));

  // ── Excel ────────────────────────────────────────────────────────────────
  const wb = new ExcelJS.Workbook();
  wb.creator = 'Peta RK Pegawai — Dataset RK + SIKAP';

  const s1 = wb.addWorksheet('Ringkasan');
  s1.columns = [
    { header: 'NIP (dataset)', key: 'nip', width: 13 },
    { header: 'Nama', key: 'nama', width: 34 },
    { header: 'Profil CKP App', key: 'profileId', width: 15 },
    { header: 'Akun SIKAP (NIP)', key: 'nipSikap', width: 20 },
    { header: 'Jabatan', key: 'jabatan', width: 26 },
    { header: 'Tim', key: 'tim', width: 60 },
    { header: 'Ketua tim di', key: 'ketuaTim', width: 30 },
    { header: 'RK dataset', key: 'jmlDataset', width: 11 },
    { header: 'RK baru (upload)', key: 'jmlBaru', width: 15 },
    { header: 'Total RK', key: 'jmlTotal', width: 10 },
    { header: 'Belum terdaftar di SIKAP', key: 'jmlBelum', width: 20 },
  ];
  for (const e of hasil) {
    s1.addRow({
      nip: e.nip, nama: e.nama, profileId: e.profileId || '-', nipSikap: e.nipSikap || '-',
      jabatan: e.jabatan, tim: e.tim.join(', '), ketuaTim: e.ketuaTim.join(', '),
      jmlDataset: e.rks.filter((r) => r.sumber.includes('dataset')).length,
      jmlBaru: e.rks.filter((r) => r.baru).length,
      jmlTotal: e.rks.length,
      jmlBelum: e.rks.filter((r) => !r.terdaftarSendiri && !r.terdaftarGlobal).length,
    });
  }
  s1.getRow(1).font = { bold: true };
  s1.views = [{ state: 'frozen', ySplit: 1 }];
  s1.autoFilter = 'A1:K1';

  const s2 = wb.addWorksheet('Peta RK');
  s2.columns = [
    { header: 'NIP (dataset)', key: 'nip', width: 13 },
    { header: 'Nama', key: 'nama', width: 32 },
    { header: 'Jenis', key: 'jenis', width: 10 },
    { header: 'RK', key: 'rk', width: 78 },
    { header: 'RK Ketua Tim (parent)', key: 'parent', width: 78 },
    { header: 'Sumber', key: 'sumber', width: 16 },
    { header: 'Baru?', key: 'baru', width: 8 },
    { header: 'Terdaftar di SIKAP (milik sendiri)', key: 'sendiri', width: 18 },
    { header: 'Bisa dicocokkan global', key: 'global', width: 16 },
    { header: 'Catatan', key: 'catatan', width: 40 },
  ];
  for (const e of hasil) for (const r of e.rks) {
    s2.addRow({
      nip: e.nip, nama: e.nama, jenis: r.jenis, rk: r.nama, parent: r.parent,
      sumber: r.sumber.join('+'), baru: r.baru ? 'ya' : '',
      sendiri: r.terdaftarSendiri ? 'ya' : 'tidak',
      global: r.terdaftarGlobal ? 'ya' : 'tidak',
      catatan: r.catatan,
    });
  }
  s2.getRow(1).font = { bold: true };
  s2.views = [{ state: 'frozen', ySplit: 1 }];
  s2.autoFilter = 'A1:J1';
  s2.eachRow((row, n) => { if (n > 1) row.alignment = { vertical: 'top', wrapText: true }; });

  const s3 = wb.addWorksheet('RK Baru (Upload)');
  s3.columns = [
    { header: 'NIP', key: 'nip', width: 13 },
    { header: 'Nama', key: 'nama', width: 34 },
    { header: 'RK', key: 'rk', width: 85 },
    { header: 'Parent', key: 'parent', width: 85 },
    { header: 'Sumber', key: 'sumber', width: 12 },
  ];
  for (const e of hasil) for (const r of e.rks) if (r.baru) {
    s3.addRow({ nip: e.nip, nama: e.nama, rk: r.nama, parent: r.parent, sumber: r.sumber.join('+') });
  }
  s3.getRow(1).font = { bold: true };
  s3.views = [{ state: 'frozen', ySplit: 1 }];
  s3.autoFilter = 'A1:E1';

  const s4 = wb.addWorksheet('Perlu Dicek');
  s4.columns = [
    { header: 'NIP', key: 'nip', width: 13 },
    { header: 'Nama', key: 'nama', width: 34 },
    { header: 'Masalah', key: 'masalah', width: 60 },
    { header: 'RK', key: 'rk', width: 85 },
  ];
  const dicek = new Set();
  const tambahDicek = (nip, nama, masalah, rk) => {
    const k = `${nip}|${masalah}|${rk}`;
    if (dicek.has(k)) return;
    dicek.add(k);
    s4.addRow({ nip, nama, masalah, rk });
  };
  for (const e of hasil) {
    if (!e.nipSikap) tambahDicek(e.nip, e.nama, 'Belum punya akun SIKAP', '');
    for (const r of e.rks) {
      if (!r.terdaftarSendiri && !r.terdaftarGlobal) {
        tambahDicek(e.nip, e.nama, 'RK belum terdaftar sebagai Sub-RK di SIKAP', r.nama);
      } else if (!r.parentAktif) {
        tambahDicek(e.nip, e.nama, 'Parent RK tidak aktif di SIKAP', r.nama);
      } else if (r.catatan) {
        tambahDicek(e.nip, e.nama, r.catatan, r.nama);
      }
    }
  }
  s4.getRow(1).font = { bold: true };
  s4.views = [{ state: 'frozen', ySplit: 1 }];
  s4.autoFilter = 'A1:D1';

  const out = path.resolve(ROOT, '..', 'Default Project', 'Peta RK Pegawai.xlsx');
  await wb.xlsx.writeFile(out);

  const totalBaru = hasil.reduce((n, e) => n + e.rks.filter((r) => r.baru).length, 0);
  console.log('OK. Pegawai:', hasil.length, '| total entri RK:', hasil.reduce((n, e) => n + e.rks.length, 0), '| entri baru:', totalBaru);
  console.log('JSON:', CKP_APP + '/src/config/rk-pegawai.json');
  console.log('XLSX:', out);
  console.log('Akbar:', hasil.find((e) => e.nip === '340066364')?.rks.length, 'RK; baru:',
    hasil.find((e) => e.nip === '340066364')?.rks.filter((r) => r.baru).map((r) => r.nama));
})().catch((e) => { console.error(e.stack); process.exit(1); });
