import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { BookOpen, Plus, Save, Search, Trash2 } from 'lucide-react';
import { useApp } from '../store.jsx';
import { Button, Card, Empty, inputCls, SectionHead } from '../components/ui.jsx';

export default function KamusPage() {
  const { s, simpanKamus, toast } = useApp();
  const [rows, setRows] = useState(s.kamus);
  const [q, setQ] = useState('');
  const [baruS, setBaruS] = useState('');
  const [baruE, setBaruE] = useState('');
  const [simpan, setSimpan] = useState(false);

  useEffect(() => { setRows(s.kamus); }, [s.kamus]);

  const kotor = JSON.stringify(rows) !== JSON.stringify(s.kamus);
  const terlihat = useMemo(() => {
    const k = q.trim().toLowerCase();
    return rows.map((r, i) => ({ r, i })).filter(({ r }) => !k || r.singkatan.toLowerCase().includes(k) || r.ekspansi.toLowerCase().includes(k));
  }, [rows, q]);

  const ubah = (i, field, v) => setRows((rs) => rs.map((r, k) => (k === i ? { ...r, [field]: v } : r)));
  const hapus = (i) => setRows((rs) => rs.filter((_, k) => k !== i));
  const tambah = () => {
    const a = baruS.trim(), b = baruE.trim();
    if (!a || !b) return toast('Isi singkatan dan ekspansinya.', 'warn');
    setRows((rs) => [{ singkatan: a, ekspansi: b }, ...rs]);
    setBaruS('');
    setBaruE('');
  };
  const doSimpan = async () => {
    setSimpan(true);
    try { await simpanKamus(rows.filter((r) => r.singkatan && r.ekspansi)); } catch (e) { toast(e.message, 'err'); }
    finally { setSimpan(false); }
  };

  return (
    <>
      <SectionHead
        eyebrow="Data induk"
        title="Kamus singkatan"
        desc="Singkatan ditulis utuh secara otomatis di kolom kegiatan. Contoh: PST menjadi “Pelayanan Statistik Terpadu (PST)”. Berlaku untuk draft berikutnya di profil aktif."
        right={<Button variant="primary" icon={Save} disabled={!kotor || simpan} onClick={doSimpan}>{kotor ? 'Simpan perubahan' : 'Tersimpan'}</Button>}
      />

      <Card className="mb-5 flex flex-col gap-3 p-5 sm:flex-row sm:items-end">
        <label className="flex flex-col gap-1.5 sm:w-40">
          <span className="text-[12px] font-semibold text-muted">Singkatan</span>
          <input className={inputCls} placeholder="cth: SLS" value={baruS} onChange={(e) => setBaruS(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') tambah(); }} />
        </label>
        <label className="flex min-w-0 flex-1 flex-col gap-1.5">
          <span className="text-[12px] font-semibold text-muted">Ekspansi</span>
          <input className={inputCls} placeholder="cth: Satuan Lingkungan Setempat (SLS)" value={baruE} onChange={(e) => setBaruE(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') tambah(); }} />
        </label>
        <Button variant="soft" icon={Plus} onClick={tambah}>Tambah</Button>
      </Card>

      <Card className="overflow-hidden">
        <div className="flex items-center gap-3 border-b border-line px-5 py-4">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
            <input className={`${inputCls} pl-10`} placeholder="Cari singkatan atau ekspansi…" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <span className="tnum text-[12.5px] text-muted">{rows.length} entri</span>
        </div>
        {rows.length === 0 ? (
          <Empty icon={BookOpen} title="Kamus masih kosong" desc="Tambahkan singkatan yang sering muncul di nama file, misalnya nama survei atau aplikasi." />
        ) : (
          <ul className="scroll-thin max-h-[560px] divide-y divide-line overflow-y-auto">
            <AnimatePresence initial={false}>
              {terlihat.map(({ r, i }) => (
                <motion.li key={i} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: -10 }} className="grid items-center gap-3 px-5 py-2.5 sm:grid-cols-[200px_minmax(0,1fr)_auto]">
                  <input aria-label="Singkatan" className={`${inputCls} py-2 font-mono text-[12.5px]`} value={r.singkatan} onChange={(e) => ubah(i, 'singkatan', e.target.value)} />
                  <input aria-label="Ekspansi" className={`${inputCls} py-2`} value={r.ekspansi} onChange={(e) => ubah(i, 'ekspansi', e.target.value)} />
                  <button type="button" onClick={() => hapus(i)} aria-label="Hapus entri" className="grid size-9 place-items-center justify-self-end rounded-lg text-muted transition hover:bg-bad-soft hover:text-bad">
                    <Trash2 className="size-4" />
                  </button>
                </motion.li>
              ))}
            </AnimatePresence>
          </ul>
        )}
      </Card>
    </>
  );
}
