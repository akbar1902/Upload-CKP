import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useRef } from 'react';
import { api, kirimJson, profilAktif, setProfilAktif } from './lib/api.js';
import { HEADER_KOSONG, sheetCocokBulan, sheetStandar } from './lib/header.js';

const Ctx = createContext(null);

// Halaman bisa dibuka langsung lewat #profil, #rk, #draft, dst.
const HALAMAN_VALID = new Set(['upload', 'drive', 'draft', 'export', 'kamus', 'kunci', 'rk', 'profil']);
function halamanDariHash() {
  try {
    const h = String(window.location.hash || '').replace(/^#/, '').trim();
    return HALAMAN_VALID.has(h) ? h : 'upload';
  } catch (e) { return 'upload'; }
}

// Draft lokal dipisah per profil supaya rekan sekantor tidak saling menimpa.
const LOCAL_PREFIX = 'ckp_draft:';
function kunciDraft(profileId) {
  return `${LOCAL_PREFIX}${profileId || 'utama'}`;
}

const awal = {
  boot: false,
  page: halamanDariHash(),
  modal: null,
  theme: 'gelap',
  profile: null,
  profiles: [],
  network: { urls: [], port: 3230 },
  dataset: { loaded: false, source: '', ringkasan: null, employees: [], teams: [], pegawaiPindah: [] },
  sikap: { configured: false, baseUrl: '', defaultBaseUrl: '', hasToken: false, user: null, rkCount: 0, source: '', verifiedAt: '', lastSyncAt: '', lastUpload: null, pairing: null },
  rclone: { ready: false, remote: 'gdrive', version: '', maxMB: 1500 },
  update: { versi: '', terbaru: '', ada: false, catatan: '', sumber: '', error: '' },
  header: { ...HEADER_KOSONG },
  rk: [],
  kamus: [],
  kunci: [],
  history: [],
  zip: { path: '', name: '', files: [], photos: 0, docs: 0, bytes: 0, total: 0, folder: '' },
  up: { items: [], running: false, done: false, completed: 0, total: 0, percent: 0, eta: '', meta: '', folder: '', parallel: 8, results: [], summary: null },
  draft: [],
  sel: [],
  exp: { busy: false, result: null, error: '' },
  toasts: [],
};

function reducer(s, a) {
  switch (a.type) {
    case 'boot':
      return { ...s, ...a.patch, boot: true };
    case 'profiles':
      return { ...s, profiles: a.profiles || s.profiles };
    case 'dataset':
      return { ...s, dataset: { ...s.dataset, ...a.patch, loaded: true } };
    case 'profile':
      return { ...s, profile: a.profile || null };
    case 'sesiBaru':
      return {
        ...s,
        profile: a.profile || s.profile,
        header: { ...HEADER_KOSONG },
        rk: [],
        kamus: [],
        kunci: [],
        history: [],
        sikap: { ...awal.sikap },
        zip: { ...awal.zip },
        up: { ...awal.up },
        draft: [],
        sel: [],
        exp: { ...awal.exp },
      };
    case 'page':
      return { ...s, page: a.page };
    case 'modal':
      return { ...s, modal: a.modal };
    case 'theme':
      return { ...s, theme: a.theme };
    case 'header':
      return { ...s, header: { ...s.header, ...a.patch } };
    case 'zip':
      return { ...s, zip: a.zip };
    case 'zipClear':
      return { ...s, zip: awal.zip };
    case 'upStart':
      return {
        ...s,
        up: {
          ...s.up,
          running: true, done: false, summary: null, percent: a.isRetry ? s.up.percent : 0,
          folder: a.folder, parallel: a.parallel, eta: '',
          meta: a.isRetry ? `mengulang ${a.ids.length} berkas…` : 'menghubungi rclone…',
          items: a.isRetry ? s.up.items : [], completed: a.isRetry ? s.up.completed : 0,
          total: a.isRetry ? s.up.total : 0, results: a.isRetry ? s.up.results : [],
        },
      };
    case 'upInit': {
      const items = a.isRetry
        ? s.up.items.map((it) => (a.ids.includes(it.id) ? { ...it, status: 'pending', link: '', error: '' } : it))
        : a.items.map((it) => ({ ...it, status: 'pending', link: '', error: '' }));
      return { ...s, up: { ...s.up, items, total: a.total, meta: `mengunggah ke ${a.folder} · ${a.parallel}x paralel` } };
    }
    case 'upFileStart':
      return {
        ...s,
        up: { ...s.up, items: s.up.items.map((it) => (it.id === a.id && it.status === 'pending' ? { ...it, status: 'uploading' } : it)) },
      };
    case 'upFileComplete':
      return {
        ...s,
        up: {
          ...s.up,
          items: s.up.items.map((it) => (it.id === a.d.id ? { ...it, status: a.d.status, error: a.d.error || '' } : it)),
          completed: a.d.completedCount,
          total: a.d.totalFiles,
          percent: a.d.percent || 0,
          meta: `mengunggah…${a.d.eta ? ' · ETA ' + a.d.eta : ''}`,
        },
      };
    case 'upProgress':
      return {
        ...s,
        up: {
          ...s.up,
          percent: Math.max(s.up.percent, a.percent),
          eta: a.eta || s.up.eta,
          meta: a.eta ? `mengunggah… ETA ${a.eta}` : s.up.meta,
        },
      };
    // Sinkronisasi penuh dari /api/upload/status — dipakai saat SSE terlambat
    // tersambung, halaman di-reload, atau koneksi sempat terputus.
    case 'upStatus': {
      const st = a.state || {};
      const adaState = Array.isArray(st.items) && st.items.length > 0;
      const items = adaState ? st.items.map((it) => ({ ...it })) : s.up.items;
      const total = st.total || s.up.total || items.length;
      const completed = Number.isFinite(st.completed) ? st.completed : s.up.completed;
      const done = !!st.done;
      return {
        ...s,
        up: {
          ...s.up,
          items,
          running: a.running === undefined ? s.up.running : !!a.running,
          done: done || s.up.done,
          total,
          completed,
          percent: done ? 100 : (Number.isFinite(st.percent) ? Math.max(s.up.percent, st.percent) : s.up.percent),
          folder: st.folder || s.up.folder,
          parallel: st.parallel || s.up.parallel,
          meta: done
            ? `selesai · ${(st.result && st.result.successCount) || 0} sukses, ${(st.result && st.result.failedCount) || 0} gagal`
            : `mengunggah… ${completed}/${total}`,
          results: (st.result && st.result.results) || s.up.results,
          summary: done
            ? {
              ok: (st.result && st.result.successCount) || 0,
              fail: (st.result && st.result.failedCount) || 0,
              cancelled: !!(st.result && st.result.cancelled),
              xlsxPath: (st.result && st.result.xlsxPath) || '',
            }
            : s.up.summary,
        },
      };
    }
    case 'upDone': {
      const byId = new Map(a.d.results.map((r) => [r.id, r]));
      const items = s.up.items.map((it) => {
        const r = byId.get(it.id);
        return r ? { ...it, status: r.status, link: r.link || '', error: r.error || '' } : it;
      });
      return {
        ...s,
        up: {
          ...s.up,
          items,
          running: false,
          done: true,
          percent: a.d.cancelled ? s.up.percent : 100,
          results: a.d.results || [],
          completed: items.filter((x) => x.status === 'success').length,
          total: items.length,
          meta: a.d.cancelled
            ? 'dibatalkan.'
            : `selesai dalam ${a.d.elapsedSec ?? '?'} dtk · ${a.d.successCount || 0} sukses, ${a.d.failedCount || 0} gagal`,
          summary: { ok: a.d.successCount || 0, fail: a.d.failedCount || 0, cancelled: !!a.d.cancelled, xlsxPath: a.d.xlsxPath || '' },
        },
      };
    }
    case 'upStopped':
      return { ...s, up: { ...s.up, running: false, meta: 'berhenti.' } };
    case 'draft':
      return { ...s, draft: a.rows, sel: [] };
    case 'draftPatch':
      return {
        ...s,
        draft: s.draft.map((d, i) => (i === a.i ? { ...d, ...a.patch, _touched: true } : d)),
      };
    case 'draftBulk':
      return {
        ...s,
        draft: s.draft.map((d, i) => (s.sel.includes(i) ? { ...d, ...a.patch, _touched: true } : d)),
      };
    case 'draftResuggest': {
      const draft = [...s.draft];
      a.idx.forEach((i, k) => {
        const r = a.rows[k];
        if (draft[i] && r) draft[i] = { ...draft[i], rk: r.rk, usulan: r.usulan || [] };
      });
      return { ...s, draft };
    }
    case 'draftDates': {
      const draft = [...s.draft];
      a.idx.forEach((i, k) => {
        const r = a.rows[k];
        const d = draft[i];
        if (!d || !r) return;
        // Hanya isi yang masih kosong — tanggal yang sudah diisi manual tidak ditimpa.
        draft[i] = {
          ...d,
          tglAwal: d.tglAwal ?? r.tglAwal ?? null,
          tglAkhir: d.tglAkhir ?? r.tglAkhir ?? null,
          bulan: d.bulan || r.bulan || '',
          bulanIndex: d.bulan ? d.bulanIndex : (r.bulanIndex || 99),
          tahun: d.tahun ?? r.tahun ?? null,
        };
      });
      return { ...s, draft };
    }
    case 'draftTglAtas': {
      let atas = null;
      const draft = s.draft.map((d, i) => {
        if (!s.sel.includes(i)) return d;
        if (d.tglAwal && d.bulan) { atas = d; return d; }
        if (!atas) return d;
        return { ...d, tglAwal: atas.tglAwal, tglAkhir: d.tglAkhir || atas.tglAkhir || atas.tglAwal, bulan: atas.bulan, _touched: true };
      });
      return { ...s, draft };
    }
    case 'sel':
      return { ...s, sel: a.sel };
    case 'kamus':
      return { ...s, kamus: a.kamus };
    case 'rk':
      return { ...s, rk: a.rk };
    case 'kunci':
      return { ...s, kunci: a.kunci };
    case 'history':
      return { ...s, history: a.files };
    case 'exp':
      return { ...s, exp: { ...s.exp, ...a.patch } };
    case 'toast':
      return { ...s, toasts: [...s.toasts, a.toast] };
    case 'toastDismiss':
      return { ...s, toasts: s.toasts.filter((t) => t.id !== a.id) };
    default:
      return s;
  }
}

export function AppProvider({ children }) {
  const [s, dispatch] = useReducer(reducer, awal, (init) => {
    let theme = 'gelap';
    try { theme = localStorage.getItem('ckp_theme') === 'terang' ? 'terang' : 'gelap'; } catch (e) { /* abaikan */ }
    return { ...init, theme };
  });
  const sRef = useRef(s);
  sRef.current = s;
  const dirtyRef = useRef(false);
  const toastId = useRef(0);
  const es = useRef(null);

  const toast = useCallback((msg, kind = '', action = null) => {
    const id = ++toastId.current;
    dispatch({ type: 'toast', toast: { id, msg, kind, action } });
    setTimeout(() => dispatch({ type: 'toastDismiss', id }), action ? 8000 : 4500);
  }, []);
  const dismissToast = useCallback((id) => dispatch({ type: 'toastDismiss', id }), []);

  const go = useCallback((page) => {
    dispatch({ type: 'page', page });
    try {
      if (window.location.hash !== `#${page}`) window.history.replaceState(null, '', `#${page}`);
    } catch (e) { /* abaikan */ }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const setTheme = useCallback((theme) => {
    dispatch({ type: 'theme', theme });
    try { localStorage.setItem('ckp_theme', theme); } catch (e) { /* abaikan */ }
    document.documentElement.classList.toggle('dark', theme === 'gelap');
  }, []);

  const setHeader = useCallback((patch) => {
    const cur = sRef.current.header;
    let p = { ...patch };
    if (Object.prototype.hasOwnProperty.call(patch, 'bulanPeriode') && patch.bulanPeriode) {
      const sheet = String(cur.sheetName || '').trim();
      if (!sheet || sheetStandar(sheet)) p.sheetName = `CKP ${patch.bulanPeriode}`;
      else toast('Nama sheet kustom tidak ikut berubah.', 'warn');
    }
    dirtyRef.current = true;
    dispatch({ type: 'header', patch: p });
    // Kolom "Pegawai" ikut memperbarui identitas profil di pemilih profil.
    if (Object.prototype.hasOwnProperty.call(p, 'pegawai')) {
      const teks = String(p.pegawai || '').trim();
      const m = teks.match(/^\[([^\]]+)\]\s*(.*)$/);
      const nama = (m ? m[2] : teks).trim();
      const nip = m ? m[1].trim() : '';
      const cur = sRef.current.profile;
      if (cur && nama) {
        const update = { ...cur, nama, nip: nip || cur.nip };
        dispatch({ type: 'profile', profile: update });
        dispatch({ type: 'profiles', profiles: sRef.current.profiles.map((x) => (x.id === cur.id ? update : x)) });
      }
    }
  }, [toast]);

  // Simpan header otomatis (debounce), seperti versi lama.
  useEffect(() => {
    if (!dirtyRef.current) return undefined;
    const t = setTimeout(() => {
      dirtyRef.current = false;
      api('/api/config', kirimJson(sRef.current.header, 'PUT')).catch(() => {});
    }, 800);
    return () => clearTimeout(t);
  }, [s.header]);

  const simpanDraftLokal = useCallback((manual) => {
    const st = sRef.current;
    if (!st.draft.length) return;
    try {
      localStorage.setItem(kunciDraft(st.profile && st.profile.id), JSON.stringify({ header: st.header, draft: st.draft, savedAt: Date.now() }));
      if (manual) toast('Draft disimpan di browser ini (per profil).');
    } catch (e) { toast('Gagal menyimpan: ' + e.message, 'err'); }
  }, [toast]);

  // Job yang event "done"-nya sudah diproses, supaya event yang terkirim ulang
  // saat SSE menyambung kembali tidak memicu penyusunan draft dua kali.
  const doneJobRef = useRef('');
  const openStream = useCallback((isRetry, ids) => {
    if (es.current) es.current.close();
    // EventSource tidak bisa mengatur header, jadi profil aktif dikirim lewat
    // query string. Tanpa ini, progres hanya diterima profil default server.
    const pid = profilAktif();
    const src = new EventSource('/api/upload/stream' + (pid ? `?profile=${encodeURIComponent(pid)}` : ''));
    es.current = src;

    const selesaikan = (d) => {
      if (d.jobId && doneJobRef.current === d.jobId) return;
      if (d.jobId) doneJobRef.current = d.jobId;
      try { src.close(); } catch (e) { /* abaikan */ }
      dispatch({ type: 'upDone', d });
      if (d.cancelled) { toast('Upload dibatalkan.', 'warn'); return; }
      const fail = d.failedCount || 0, ok = d.successCount || 0;
      if (fail === 0) {
        toast(`Semua ${ok} berkas terunggah. Menyusun draft…`);
        const items = (d.results || []).filter((r) => r.status === 'success' && r.link).map((r) => ({ namaFile: r.originalName, link: r.link }));
        if (items.length) buatDraftRef.current(items);
      } else {
        toast(`${fail} berkas gagal. Yang sukses tidak perlu diulang.`, 'warn');
      }
    };

    src.addEventListener('init', (ev) => {
      const d = JSON.parse(ev.data);
      dispatch({ type: 'upInit', isRetry, ids: ids || [], items: d.items, total: d.totalFiles, folder: d.driveFolder, parallel: d.parallel });
    });
    src.addEventListener('snapshot', (ev) => {
      const d = JSON.parse(ev.data);
      if (!d.state) return;
      if (d.state.error) {
        try { src.close(); } catch (e) { /* abaikan */ }
        dispatch({ type: 'upStopped' });
        toast('Upload gagal: ' + d.state.error, 'err');
        return;
      }
      if (d.state.done && d.state.result && !d.state.result.cancelled) {
        selesaikan(d.state.result);
      } else {
        dispatch({ type: 'upStatus', state: d.state, running: d.running });
      }
    });
    src.addEventListener('file_start', (ev) => {
      dispatch({ type: 'upFileStart', id: JSON.parse(ev.data).id });
    });
    src.addEventListener('file_complete', (ev) => {
      dispatch({ type: 'upFileComplete', d: JSON.parse(ev.data) });
    });
    src.addEventListener('progress_stats', (ev) => {
      const d = JSON.parse(ev.data);
      if (typeof d.percent === 'number') dispatch({ type: 'upProgress', percent: d.percent, eta: d.eta });
    });
    src.addEventListener('done', (ev) => selesaikan(JSON.parse(ev.data)));
    src.addEventListener('fatal', (ev) => {
      const d = JSON.parse(ev.data);
      try { src.close(); } catch (e) { /* abaikan */ }
      dispatch({ type: 'upStopped' });
      toast('Upload berhenti: ' + (d.message || 'kesalahan tak terduga'), 'err');
    });
    src.onerror = () => { /* SSE terputus; browser menyambung ulang otomatis */ };

    // Jaring pengaman: bila SSE terhalang extension/proxy, progres tetap
    // tersinkron lewat polling status sampai upload selesai.
    const watch = setInterval(async () => {
      if (es.current !== src) { clearInterval(watch); return; }
      if (!sRef.current.up.running) { clearInterval(watch); return; }
      try {
        const j = await api('/api/upload/status');
        const st = j.state;
        const pesanError = j.error || (st && st.error) || '';
        if (pesanError) {
          clearInterval(watch);
          try { src.close(); } catch (e) { /* abaikan */ }
          dispatch({ type: 'upStopped' });
          toast('Upload gagal: ' + pesanError, 'err');
          return;
        }
        if (!st || !Array.isArray(st.items) || !st.items.length) return;
        if (st.done) {
          clearInterval(watch);
          if (j.jobId && doneJobRef.current === j.jobId) return;
          if (j.jobId) doneJobRef.current = j.jobId;
          dispatch({ type: 'upStatus', state: st, running: false });
          try { src.close(); } catch (e) { /* abaikan */ }
          const res = st.result || {};
          if (!res.cancelled && (res.successCount || 0) > 0) {
            const items = (res.results || []).filter((r) => r.status === 'success' && r.link).map((r) => ({ namaFile: r.originalName, link: r.link }));
            toast(`Semua ${res.successCount} berkas terunggah. Menyusun draft…`);
            if (items.length) buatDraftRef.current(items);
          } else if (!res.cancelled) {
            toast(`${res.failedCount || 0} berkas gagal. Yang sukses tidak perlu diulang.`, 'warn');
          }
        } else {
          dispatch({ type: 'upStatus', state: st, running: true });
        }
      } catch (e) { /* server sesaat tidak merespons; coba lagi */ }
    }, 3000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toast]);

  const buatDraftRef = useRef(null);
  const buatDraft = useCallback(async (items) => {
    if (!items.length) return toast('Belum ada berkas sukses untuk disusun.', 'warn');
    try {
      const j = await api('/api/draft/generate', kirimJson({ items }));
      dispatch({ type: 'draft', rows: j.rows });
      go('draft');
      const need = j.rows.filter((d) => d.perluReview).length;
      toast(`Draft tersusun: ${j.rows.length} baris${need ? `, ${need} perlu dicek` : ''}.`, need ? 'warn' : '');
    } catch (e) { toast('Gagal menyusun draft: ' + e.message, 'err'); }
  }, [go, toast]);
  buatDraftRef.current = buatDraft;

  const mulaiUpload = useCallback(async ({ zipPath, folder, parallel }) => {
    await api('/api/upload/start', kirimJson({ zipPath, remote: sRef.current.rclone.remote, driveFolder: folder, parallel }));
    dispatch({ type: 'upStart', isRetry: false, ids: [], folder, parallel });
    go('drive');
    openStream(false, []);
  }, [go, openStream]);

  const ulangiGagal = useCallback(async () => {
    const st = sRef.current;
    const ids = st.up.items.filter((x) => x.status === 'failed').map((x) => x.id);
    if (!ids.length) return;
    try {
      await api('/api/upload/start', kirimJson({
        zipPath: st.zip.path, remote: st.rclone.remote, driveFolder: st.up.folder, parallel: st.up.parallel, filterIds: ids,
      }));
      dispatch({ type: 'upStart', isRetry: true, ids, folder: st.up.folder, parallel: st.up.parallel });
      toast(`Mengulang ${ids.length} berkas gagal…`);
      openStream(true, ids);
    } catch (e) { toast(e.message, 'err'); }
  }, [openStream, toast]);

  const batalkanUpload = useCallback(async () => {
    try {
      await api('/api/upload/cancel', { method: 'POST' });
      toast('Membatalkan…', 'warn');
    } catch (e) { toast(e.message, 'err'); }
  }, [toast]);

  const muatRiwayat = useCallback(async () => {
    try {
      const j = await api('/api/history');
      dispatch({ type: 'history', files: j.files || [] });
    } catch (e) { /* abaikan */ }
  }, []);

  // Muat seluruh data milik satu profil (header, RK, kamus, kunci, rclone).
  const muatProfilData = useCallback(async (profil) => {
    const pid = profil && profil.id;
    setProfilAktif(pid || '');
    let patch = { profile: profil || null };
    try {
      const st = await api('/api/system/status');
      patch = {
        ...patch,
        rclone: {
          ready: !!st.rcloneReady,
          remote: st.defaultRemote || 'gdrive',
          version: (st.version || '').slice(0, 60),
          maxMB: st.maxZipMB || 1500,
          remotes: st.remotes || [],
        },
        header: { ...HEADER_KOSONG, ...(st.config || {}) },
        profiles: st.profiles || sRef.current.profiles,
        profile: st.profile || profil || null,
        network: { urls: st.networkUrls || [], port: st.port || 3230 },
      };
    } catch (e) {
      toast('Gagal menghubungi server: ' + e.message, 'err');
    }
    try { patch.rk = (await api('/api/rk-list')).rk || []; } catch (e) { patch.rk = []; }
    try { patch.kamus = (await api('/api/kamus')).kamus || []; } catch (e) { patch.kamus = []; }
    try { patch.kunci = (await api('/api/rk-keywords')).aturan || []; } catch (e) { patch.kunci = []; }
    try { patch.sikap = (await api('/api/sikap/status')).sikap || awal.sikap; } catch (e) { patch.sikap = awal.sikap; }
    try {
      const v = await api('/api/system/version');
      patch.update = {
        versi: v.versi || '',
        terbaru: v.terbaru || '',
        ada: Boolean(v.adaUpdate),
        catatan: v.catatan || '',
        sumber: v.sumber || '',
        error: v.error || '',
      };
    } catch (e) {
      patch.update = { ...awal.update, error: e.message };
    }
    dirtyRef.current = false;
    dispatch({ type: 'boot', patch });
    muatRiwayat();
    try {
      const raw = localStorage.getItem(kunciDraft(pid));
      const j = raw ? JSON.parse(raw) : null;
      if (j && Array.isArray(j.draft) && j.draft.length) {
        let draftRows = j.draft;
        // Draft lama bisa tersimpan sebelum tanggal terisi. Lengkapi otomatis
        // dari nama file (hanya yang kosong; isian manual tidak ditimpa).
        const perlu = draftRows.filter((d) => !d.tglAwal || !d.bulan);
        if (perlu.length) {
          try {
            const jr = await api('/api/draft/parse-dates', kirimJson({
              rows: perlu.map((d) => ({ namaFile: d.namaFile })),
            }));
            let k = 0;
            draftRows = draftRows.map((d) => {
              if (d.tglAwal && d.bulan) return d;
              const r = (jr.rows || [])[k++] || {};
              const tglAwal = d.tglAwal ?? r.tglAwal ?? null;
              return {
                ...d,
                tglAwal,
                tglAkhir: d.tglAkhir ?? r.tglAkhir ?? r.tglAwal ?? tglAwal ?? null,
                bulan: d.bulan || r.bulan || '',
                bulanIndex: d.bulan ? d.bulanIndex : (r.bulanIndex || 99),
                tahun: d.tahun ?? r.tahun ?? null,
              };
            });
            localStorage.setItem(kunciDraft(pid), JSON.stringify({ ...j, draft: draftRows, savedAt: Date.now() }));
          } catch (e) { /* biarkan draft apa adanya; user bisa klik Isi tanggal */ }
        }
        toast(`Ada draft ${profil?.nama || 'profil ini'} tersimpan di browser (${draftRows.length} baris).`, '', {
          label: 'Muat',
          fn: () => {
            dispatch({ type: 'draft', rows: draftRows });
            if (j.header) dispatch({ type: 'header', patch: j.header });
            go('draft');
          },
        });
      }
    } catch (e) { /* abaikan */ }
  }, [go, muatRiwayat, toast]);

  const segarkanProfil = useCallback(async () => {
    try {
      const j = await api('/api/profiles');
      dispatch({ type: 'profiles', profiles: j.profiles || [] });
      return j.profiles || [];
    } catch (e) {
      toast('Gagal memuat daftar profil: ' + e.message, 'err');
      return [];
    }
  }, [toast]);

  const gantiProfil = useCallback(async (id) => {
    const st = sRef.current;
    if (!id || id === (st.profile && st.profile.id)) return;
    if (st.up.running) return toast('Selesaikan upload yang sedang berjalan sebelum ganti profil.', 'warn');
    const tujuan = st.profiles.find((p) => p.id === id);
    if (!tujuan) return toast('Profil tidak ditemukan. Muat ulang halaman.', 'err');
    simpanDraftLokal(false);
    try { es.current?.close(); es.current = null; } catch (e) { /* abaikan */ }
    dispatch({ type: 'sesiBaru', profile: tujuan });
    await muatProfilData(tujuan);
    if (['draft', 'drive', 'export'].includes(st.page)) go('upload');
    toast(`Sekarang memakai profil ${tujuan.nama}.`);
  }, [go, muatProfilData, simpanDraftLokal, toast]);

  const buatProfil = useCallback(async (data) => {
    const j = await api('/api/profiles', kirimJson(data));
    await segarkanProfil();
    await muatProfilData(j.profile);
    toast(`Profil ${j.profile.nama} dibuat dan langsung dipakai.`);
    return j.profile;
  }, [muatProfilData, segarkanProfil, toast]);

  const ubahProfil = useCallback(async (id, data) => {
    const j = await api(`/api/profiles/${encodeURIComponent(id)}`, kirimJson(data, 'PUT'));
    await segarkanProfil();
    if (sRef.current.profile && sRef.current.profile.id === id) {
      await muatProfilData(j.profile);
    }
    toast('Data profil diperbarui.');
    return j.profile;
  }, [muatProfilData, segarkanProfil, toast]);

  const duplikatProfil = useCallback(async (id, nama) => {
    const j = await api(`/api/profiles/${encodeURIComponent(id)}/duplicate`, kirimJson({ nama }));
    await segarkanProfil();
    toast(`Profil salinan dibuat: ${j.profile.nama}.`);
    return j.profile;
  }, [segarkanProfil, toast]);

  const hapusProfil = useCallback(async (id) => {
    const st = sRef.current;
    const sisa = st.profiles.filter((p) => p.id !== id);
    if (!sisa.length) return toast('Minimal harus ada satu profil.', 'warn');
    await api(`/api/profiles/${encodeURIComponent(id)}`, { method: 'DELETE' });
    await segarkanProfil();
    if (st.profile && st.profile.id === id) {
      await muatProfilData(sisa[0]);
      toast(`Profil dihapus. Sekarang memakai ${sisa[0].nama}.`, 'warn');
    } else {
      toast('Profil dihapus.', 'warn');
    }
  }, [muatProfilData, segarkanProfil, toast]);

  const imporProfil = useCallback(async (bundle) => {
    const j = await api('/api/profiles/import', kirimJson({ bundle }));
    await segarkanProfil();
    await muatProfilData(j.profile);
    toast(`Profil ${j.profile.nama} diimpor dan langsung dipakai.`);
    return j.profile;
  }, [muatProfilData, segarkanProfil, toast]);

  const muatDatasetRk = useCallback(async () => {
    const j = await api('/api/rk-dataset');
    dispatch({
      type: 'dataset',
      patch: {
        source: j.source || '',
        ringkasan: j.ringkasan || null,
        employees: j.employees || [],
        teams: j.teams || [],
        pegawaiPindah: j.pegawaiPindah || [],
      },
    });
    return j;
  }, []);

  const terapkanHasilDataset = useCallback(async (j) => {
    dispatch({ type: 'profiles', profiles: j.profiles || [] });
    const aktifLama = sRef.current.profile;
    const aktifBaru = (j.profiles || []).find((p) => p.id === (aktifLama && aktifLama.id));
    if (aktifBaru) await muatProfilData(aktifBaru);
    const dibuat = (j.hasil || []).filter((x) => x.baru).length;
    const diperbarui = (j.hasil || []).length - dibuat;
    toast(`Dataset RK diterapkan: ${dibuat} profil baru, ${diperbarui} diperbarui.`);
    return j;
  }, [muatProfilData, toast]);

  const imporDatasetRk = useCallback(async ({ mode = 'ganti', nips = null } = {}) => {
    const j = await api('/api/rk-dataset/import', kirimJson({ mode, nips }));
    return terapkanHasilDataset(j);
  }, [terapkanHasilDataset]);

  const imporDatasetRkFile = useCallback(async (file, mode = 'ganti') => {
    if (!file) throw new Error('File dataset belum dipilih.');
    const fd = new FormData();
    fd.append('file', file);
    fd.append('mode', mode);
    const j = await api('/api/rk-dataset/import-file', { method: 'POST', body: fd });
    return terapkanHasilDataset(j);
  }, [terapkanHasilDataset]);

  // Impor RK massal: tempel teks dan/atau unggah .xlsx/.csv.
  const imporRk = useCallback(async ({ text = '', mode = 'append', file = null }) => {
    const fd = new FormData();
    fd.append('text', text);
    fd.append('mode', mode);
    if (file) fd.append('file', file);
    const j = await api('/api/rk-list/import', { method: 'POST', body: fd });
    dispatch({ type: 'rk', rk: j.rk || [] });
    try { dispatch({ type: 'kunci', kunci: (await api('/api/rk-keywords')).aturan || [] }); } catch (e) { /* abaikan */ }
    toast(`${j.jumlah} RK tersimpan${j.mode === 'replace' ? ' (mengganti daftar lama)' : ''}.`);
    return j;
  }, [toast]);

  const simpanDaftarRk = useCallback(async (list) => {
    const j = await api('/api/rk-list', kirimJson(list, 'PUT'));
    dispatch({ type: 'rk', rk: j.rk || list });
    try { dispatch({ type: 'kunci', kunci: (await api('/api/rk-keywords')).aturan || [] }); } catch (e) { /* abaikan */ }
    toast(`Daftar RK tersimpan (${j.jumlah} RK).`);
    return j;
  }, [toast]);

  const hapusRk = useCallback(async (nama) => {
    const st = sRef.current;
    return simpanDaftarRk(st.rk.filter((x) => x !== nama));
  }, [simpanDaftarRk]);

  const ubahRk = useCallback(async (lama, baru) => {
    const st = sRef.current;
    const nama = String(baru || '').replace(/\s+/g, ' ').trim();
    if (!nama) throw new Error('Nama RK tidak boleh kosong.');
    if (nama === lama) return null;
    if (st.rk.some((x) => x !== lama && x.toLowerCase() === nama.toLowerCase())) {
      throw new Error('RK dengan nama itu sudah ada.');
    }
    const daftar = st.rk.map((x) => (x === lama ? nama : x));
    const j = await api('/api/rk-list', kirimJson(daftar, 'PUT'));
    dispatch({ type: 'rk', rk: j.rk || daftar });
    // Ikutkan aturan kata kunci yang menunjuk RK lama.
    if (st.kunci.some((r) => r.rk === lama)) {
      const kunci = st.kunci.map((r) => (r.rk === lama ? { ...r, rk: nama } : r));
      await api('/api/rk-keywords', kirimJson(kunci, 'PUT'));
      dispatch({ type: 'kunci', kunci });
    }
    toast('Nama RK diperbarui.');
    return j;
  }, [toast]);

  const simpanKamus = useCallback(async (kamus) => {
    const j = await api('/api/kamus', kirimJson(kamus, 'PUT'));
    dispatch({ type: 'kamus', kamus });
    toast(`${j.jumlah} entri tersimpan. Berlaku untuk draft berikutnya.`);
  }, [toast]);

  // Tambah RK yang belum ada di daftar master (langsung tersimpan permanen).
  const tambahRk = useCallback(async (nama) => {
    const j = await api('/api/rk-list', kirimJson({ nama }, 'POST'));
    dispatch({ type: 'rk', rk: j.rk || [] });
    toast(j.ditambahkan ? `RK baru ditambahkan: ${j.nama}` : 'RK itu sudah ada di daftar.');
    return j.nama;
  }, [toast]);

  // Isi tanggal yang masih kosong langsung dari nama file (memperbaiki draft lama).
  const isiTanggalDariNama = useCallback(async () => {
    const st = sRef.current;
    const idx = [];
    const rows = [];
    st.draft.forEach((d, i) => {
      if (d.tglAwal && d.bulan) return;
      idx.push(i);
      rows.push({ namaFile: d.namaFile });
    });
    if (!rows.length) return toast('Semua baris sudah punya tanggal.');
    try {
      const j = await api('/api/draft/parse-dates', kirimJson({ rows }));
      dispatch({ type: 'draftDates', idx, rows: j.rows || [] });
      const terisi = (j.rows || []).filter((r) => r.tglAwal && r.bulan).length;
      if (terisi) toast(`${terisi} baris diisi tanggalnya dari nama file.`);
      else toast('Tanggal tidak terbaca dari nama file — isi manual.', 'warn');
    } catch (e) {
      toast('Gagal mengisi tanggal: ' + e.message, 'err');
    }
  }, [toast]);

  // Hitung ulang saran RK dengan aturan kata kunci terbaru. Baris yang sudah
  // dikoreksi manual (pernah diedit) tidak ditimpa.
  const susunUlangRk = useCallback(async () => {
    const st = sRef.current;
    const idx = [];
    const rows = [];
    st.draft.forEach((d, i) => {
      if (d._touched) return;
      idx.push(i);
      rows.push({ namaFile: d.namaFile, kegiatan: d.kegiatan });
    });
    if (!rows.length) return toast('Semua baris sudah dikoreksi manual — tidak ada yang diubah.', 'warn');
    try {
      const j = await api('/api/draft/resuggest', kirimJson({ rows }));
      dispatch({ type: 'draftResuggest', idx, rows: j.rows || [] });
      const ganti = j.rows.filter((r, i) => r.rk && r.rk !== st.draft[idx[i]].rk).length;
      toast(`Saran RK dihitung ulang untuk ${idx.length} baris${ganti ? `, ${ganti} berubah` : ''}.`);
    } catch (e) {
      toast('Gagal menghitung ulang RK: ' + e.message, 'err');
    }
  }, [toast]);

  const simpanKunci = useCallback(async (aturan) => {
    const j = await api('/api/rk-keywords', kirimJson(aturan, 'PUT'));
    dispatch({ type: 'kunci', kunci: aturan });
    toast(`${j.jumlah} aturan kata kunci tersimpan. Berlaku untuk draft berikutnya.`);
  }, [toast]);

  // ─── Integrasi SIKAP ──────────────────────────────────────────────────────
  const simpanSikap = useCallback(async ({ baseUrl, token }) => {
    const j = await api('/api/sikap/config', kirimJson({ baseUrl, token }, 'PUT'));
    dispatch({ type: 'boot', patch: { sikap: j.sikap || awal.sikap } });
    toast('Pengaturan integrasi SIKAP disimpan.');
    return j;
  }, [toast]);

  const ujiSikap = useCallback(async () => {
    const j = await api('/api/sikap/test', { method: 'POST' });
    dispatch({ type: 'boot', patch: { sikap: j.sikap || awal.sikap } });
    toast(`Terhubung ke SIKAP sebagai ${j.sikap?.user?.full_name || 'pengguna'}.`);
    return j;
  }, [toast]);

  const mulaiPairingSikap = useCallback(async (baseUrl) => {
    const j = await api('/api/sikap/pair/start', kirimJson({ baseUrl }));
    dispatch({ type: 'boot', patch: { sikap: j.sikap || awal.sikap } });
    return j;
  }, []);

  const cekPairingSikap = useCallback(async () => {
    try {
      const j = await api('/api/sikap/pair/status');
      if (j.sikap) dispatch({ type: 'boot', patch: { sikap: j.sikap } });
      if (j.status === 'connected') {
        try {
          const rk = await api('/api/rk-list');
          dispatch({ type: 'rk', rk: rk.rk || [] });
        } catch (e) { /* abaikan */ }
      }
      return j;
    } catch (e) {
      if (e.payload && e.payload.sikap) dispatch({ type: 'boot', patch: { sikap: e.payload.sikap } });
      throw e;
    }
  }, []);

  const batalPairingSikap = useCallback(async () => {
    const j = await api('/api/sikap/pair/cancel', { method: 'POST' });
    dispatch({ type: 'boot', patch: { sikap: j.sikap || awal.sikap } });
    return j;
  }, []);

  const lupakanSikap = useCallback(async () => {
    const j = await api('/api/sikap/disconnect', { method: 'POST' });
    dispatch({ type: 'boot', patch: { sikap: j.sikap || awal.sikap } });
    toast('Koneksi SIKAP dilupakan di perangkat ini.', 'warn');
  }, [toast]);

  const tarikRkSikap = useCallback(async (mode = 'append') => {
    const j = await api('/api/sikap/sync-rk', kirimJson({ mode }));
    dispatch({ type: 'rk', rk: j.rk || [] });
    dispatch({ type: 'boot', patch: { sikap: j.sikap || awal.sikap } });
    toast(`${j.jumlah} RK tersedia${mode === 'append' ? ' (RK lokal tetap dipertahankan)' : ''}.`);
    return j;
  }, [toast]);

  const kirimSikap = useCallback(async () => {
    const st = sRef.current;
    const rows = st.draft.map((d) => ({
      kegiatan: d.kegiatan, rk: d.rk, tglAwal: d.tglAwal, tglAkhir: d.tglAkhir,
      bulan: d.bulan, tahun: d.tahun, link: d.link,
    }));
    const j = await api('/api/sikap/kirim', kirimJson({ rows, header: st.header }));
    dispatch({ type: 'boot', patch: { sikap: j.sikap || st.sikap } });
    return j;
  }, []);

  const exportExcel = useCallback(async () => {
    const st = sRef.current;
    const rows = st.draft.map((d) => ({ kegiatan: d.kegiatan, rk: d.rk, tglAwal: d.tglAwal, tglAkhir: d.tglAkhir, bulan: d.bulan, tahun: d.tahun, link: d.link }));
    dispatch({ type: 'exp', patch: { busy: true, error: '', result: null } });
    try {
      const j = await api('/api/export', kirimJson({ rows, header: st.header }));
      dispatch({ type: 'exp', patch: { busy: false, result: j } });
      toast(`Excel CKP tersimpan (${j.jumlah} baris).`);
      muatRiwayat();
    } catch (e) {
      dispatch({ type: 'exp', patch: { busy: false, error: e.message } });
      toast('Export gagal — cek baris yang merah.', 'err');
    }
  }, [muatRiwayat, toast]);

  // Boot: pilih profil (per pegawai) lalu muat data miliknya. Draft lokal juga
  // dipisah per profil, jadi rekan sekantor tidak saling menimpa.
  useEffect(() => {
    (async () => {
      let daftar = [];
      let id = profilAktif();
      try {
        const j = await api('/api/profiles');
        daftar = j.profiles || [];
        if (!daftar.some((p) => p.id === id)) id = (daftar[0] && daftar[0].id) || '';
        setProfilAktif(id);
        dispatch({ type: 'profiles', profiles: daftar });
      } catch (e) {
        toast('Gagal memuat profil pegawai: ' + e.message, 'err');
      }
      const aktif = daftar.find((p) => p.id === id) || daftar[0] || null;
      // Migrasi draft browser versi lama (satu pengguna) ke profil pertama.
      try {
        const lama = localStorage.getItem('ckp_draft');
        if (aktif && lama && !localStorage.getItem(kunciDraft(aktif.id))) {
          localStorage.setItem(kunciDraft(aktif.id), lama);
        }
      } catch (e) { /* abaikan */ }
      await muatProfilData(aktif);
      // Pulihkan progres upload bila halaman di-reload saat proses berjalan.
      try {
        const j = await api('/api/upload/status');
        if (j.state && Array.isArray(j.state.items) && j.state.items.length) {
          if (j.error || j.state.error) {
            dispatch({ type: 'upStopped' });
            toast('Upload terakhir gagal: ' + (j.error || j.state.error), 'err');
          } else {
            dispatch({ type: 'upStatus', state: j.state, running: j.running });
            if (j.running) {
              toast('Upload masih berjalan — progres dipulihkan.', 'warn');
              openStream(false, []);
            }
          }
        }
      } catch (e) { /* belum ada job upload */ }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Pintasan global: Ctrl/⌘+S simpan draft lokal.
  useEffect(() => {
    const onKey = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && sRef.current.draft.length) {
        e.preventDefault();
        simpanDraftLokal(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [simpanDraftLokal]);

  // Dukung tombol Back/Forward browser untuk pindah halaman (#profil, #rk, …).
  useEffect(() => {
    const onHash = () => dispatch({ type: 'page', page: halamanDariHash() });
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  // Hentikan koneksi SSE saat provider dilepas.
  useEffect(() => () => {
    try { es.current?.close(); } catch (e) { /* abaikan */ }
    es.current = null;
  }, []);

  // Satu klik: minta server menjalankan updater, lalu tunggu server hidup
  // kembali dengan versi baru sebelum reload halaman.
  const perbaruiApp = useCallback(async () => {
    const v = sRef.current.update || {};
    try {
      const j = await api('/api/system/update', { method: 'POST' });
      if (j && j.sudahTerbaru) {
        toast(`Sudah versi terbaru (${j.versi}).`);
        return;
      }
      toast(`Memperbarui ke versi ${v.terbaru || 'baru'}. CKP App akan dibuka ulang…`);
      const mulai = Date.now();
      const versiLama = v.versi || '';
      const timer = setInterval(async () => {
        try {
          const r = await fetch('/api/health', { cache: 'no-store' });
          if (r.ok) {
            const h = await r.json().catch(() => null);
            if (h && h.versi && h.versi !== versiLama) {
              clearInterval(timer);
              window.location.reload();
              return;
            }
          }
        } catch (e) { /* server sedang berhenti */ }
        if (Date.now() - mulai > 180000) {
          clearInterval(timer);
          toast('Update memakan waktu. Tutup lalu jalankan CKP App manual.', 'err');
        }
      }, 2000);
    } catch (e) {
      toast(e.message, 'err');
    }
  }, [toast]);

  const value = useMemo(() => ({
    s, dispatch, toast, dismissToast, go, setTheme, setHeader,
    mulaiUpload, ulangiGagal, batalkanUpload, buatDraft, muatRiwayat,
    simpanKamus, tambahRk, susunUlangRk, isiTanggalDariNama, simpanKunci, exportExcel, simpanDraftLokal,
    muatProfilData, segarkanProfil, gantiProfil, buatProfil, ubahProfil, duplikatProfil,
    hapusProfil, imporProfil, imporRk, simpanDaftarRk, hapusRk, ubahRk,
    simpanSikap, ujiSikap, tarikRkSikap, kirimSikap,
    mulaiPairingSikap, cekPairingSikap, batalPairingSikap, lupakanSikap,
    muatDatasetRk, imporDatasetRk, imporDatasetRkFile, perbaruiApp,
  }), [s, toast, dismissToast, go, setTheme, setHeader, mulaiUpload, ulangiGagal, batalkanUpload, buatDraft, muatRiwayat, simpanKamus, tambahRk, susunUlangRk, isiTanggalDariNama, simpanKunci, exportExcel, simpanDraftLokal, muatProfilData, segarkanProfil, gantiProfil, buatProfil, ubahProfil, duplikatProfil, hapusProfil, imporProfil, imporRk, simpanDaftarRk, hapusRk, ubahRk, simpanSikap, ujiSikap, tarikRkSikap, kirimSikap, mulaiPairingSikap, cekPairingSikap, batalPairingSikap, lupakanSikap, muatDatasetRk, imporDatasetRk, imporDatasetRkFile, perbaruiApp]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useApp harus di dalam AppProvider');
  return v;
}
