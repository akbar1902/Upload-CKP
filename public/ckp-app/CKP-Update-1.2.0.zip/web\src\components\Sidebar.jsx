import { motion } from 'motion/react';
import { BookOpen, Check, ClipboardList, Download, FileSearch, History, KeyRound, Moon, Sun, Users } from 'lucide-react';
import { useApp } from '../store.jsx';
import { turunkan } from '../lib/derive.js';

export default function Sidebar() {
  const { s, go, setTheme, dispatch, perbaruiApp } = useApp();
  const d = turunkan(s);
  const exported = !!s.exp.result;

  const tahap = [
    { key: 'upload', label: 'Upload ZIP', sub: s.zip.total ? `${s.zip.total} berkas siap` : 'belum ada berkas', done: s.zip.total > 0, badge: 0 },
    {
      key: 'drive', label: 'Sinkron Drive',
      sub: s.up.running ? `mengunggah ${s.up.completed}/${s.up.total}` : s.up.done ? `${d.upOk} sukses${d.upGagal ? `, ${d.upGagal} gagal` : ''}` : 'menunggu upload',
      done: s.up.done && d.upGagal === 0, badge: d.upGagal,
    },
    {
      key: 'draft', label: 'Draft & Koreksi',
      sub: s.draft.length ? (d.perluCek ? `${d.perluCek} perlu dicek` : `${s.draft.length} baris beres`) : 'belum tersusun',
      done: s.draft.length > 0 && d.perluCek === 0, badge: d.perluCek,
    },
    { key: 'export', label: 'Export', sub: exported ? 'sudah diekspor' : d.canExport ? 'siap distempel' : 'terkunci', done: exported, badge: 0 },
  ];
  const selesai = tahap.filter((t) => t.done).length;
  const tinggi = Math.min(100, (selesai / (tahap.length - 1)) * 100);
  const dark = s.theme === 'gelap';

  return (
    <aside className="flex flex-col gap-6 border-b border-line bg-surface/70 p-5 backdrop-blur-xl lg:sticky lg:top-0 lg:h-screen lg:w-[268px] lg:shrink-0 lg:border-r lg:border-b-0 lg:overflow-y-auto">
      <div className="flex items-center gap-3">
        <div className="grid size-10 place-items-center rounded-xl bg-accent-solid text-white shadow-lg shadow-accent-solid/30">
          <FileSearch className="size-5" strokeWidth={2.2} />
        </div>
        <div className="min-w-0">
          <p className="text-[15px] font-extrabold tracking-[-0.02em] text-ink">CKP App</p>
          <p className="truncate text-[11.5px] text-muted">Bukti dukung → Excel SIKAP</p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => go('profil')}
        className={`flex items-center gap-2.5 rounded-xl border px-3 py-2.5 text-left transition ${s.page === 'profil' ? 'border-accent/30 bg-accent-soft' : 'border-line bg-surface-2 hover:bg-surface-3'}`}
        title="Ganti atau kelola profil pegawai"
      >
        <span className="grid size-7 shrink-0 place-items-center rounded-lg bg-accent-solid text-[11.5px] font-extrabold text-white">
          {((s.profile && s.profile.nama) || '?').trim()[0]?.toUpperCase() || '?'}
        </span>
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[12.5px] font-bold text-ink">{(s.profile && s.profile.nama) || 'Memuat profil…'}</span>
          <span className="block truncate text-[11px] text-muted">
            {s.profile && s.profile.nip ? `NIP ${s.profile.nip}` : 'Profil pegawai · atur di sini'}
          </span>
        </span>
        <Users className="size-3.5 shrink-0 text-muted" />
      </button>

      <nav aria-label="Tahapan" className="relative">
        <p className="mb-2.5 px-1 text-[10.5px] font-bold tracking-[0.14em] text-faint uppercase">Alur kerja</p>
        <div className="absolute top-6 bottom-6 left-6 w-px -translate-x-1/2 bg-line" aria-hidden>
          <motion.div
            className="absolute top-0 left-0 w-full bg-glow shadow-[0_0_12px_var(--glow)]"
            initial={false}
            animate={{ height: `${tinggi}%` }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          />
        </div>
        <ul className="relative flex flex-col gap-1">
          {tahap.map((t, i) => {
            const aktif = s.page === t.key;
            const terkunci = t.key === 'export' && !d.canExport && !exported;
            return (
              <li key={t.key}>
                <button
                  type="button"
                  onClick={() => go(t.key)}
                  aria-current={aktif ? 'page' : undefined}
                  className={`group flex w-full items-center gap-3 rounded-xl px-2.5 py-2.5 text-left transition duration-200 ${aktif ? 'bg-accent-soft ring-1 ring-inset ring-accent/25' : 'hover:bg-surface-2'}`}
                >
                  <span className={`relative grid size-7 shrink-0 place-items-center rounded-full text-[12px] font-extrabold transition duration-500 ${t.done ? 'bg-glow text-white shadow-[0_0_14px_var(--glow)]' : aktif ? 'bg-accent-solid text-white' : 'bg-surface-3 text-muted ring-1 ring-inset ring-line'}`}>
                    {t.done ? <Check className="size-3.5" strokeWidth={3} /> : i + 1}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className={`block text-[13.5px] font-semibold ${aktif ? 'text-ink' : 'text-ink/90'}`}>{t.label}</span>
                    <span className={`block truncate text-[11.5px] ${terkunci ? 'text-faint' : 'text-muted'}`}>{t.sub}</span>
                  </span>
                  {t.badge > 0 && (
                    <span className={`tnum rounded-full px-2 py-0.5 text-[11px] font-bold ${t.key === 'drive' ? 'bg-bad-soft text-bad' : 'bg-amber-soft text-amber'}`}>{t.badge}</span>
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div>
        <p className="mb-2.5 px-1 text-[10.5px] font-bold tracking-[0.14em] text-faint uppercase">Data induk</p>
        <ul className="flex flex-col gap-1">
          <MenuItem icon={ClipboardList} label="Daftar RK" aktif={s.page === 'rk'} onClick={() => go('rk')} />
          <MenuItem icon={BookOpen} label="Kamus singkatan" aktif={s.page === 'kamus'} onClick={() => go('kamus')} />
          <MenuItem icon={KeyRound} label="Kata kunci RK" aktif={s.page === 'kunci'} onClick={() => go('kunci')} />
          <MenuItem icon={Users} label="Profil & rekan" aktif={s.page === 'profil'} onClick={() => go('profil')} />
          <MenuItem icon={History} label="Buka hasil lama" onClick={() => dispatch({ type: 'modal', modal: 'hasil' })} />
        </ul>
      </div>

      <div className="mt-auto flex flex-col gap-3">
        {s.update?.ada && (
          <div className="rounded-xl border border-accent/30 bg-accent-soft p-3">
            <p className="text-[12px] font-bold text-accent-text">Versi {s.update.terbaru} tersedia</p>
            <p className="mt-0.5 text-[11px] leading-relaxed text-muted">
              {s.update.catatan || 'Perbarui CKP App untuk perbaikan terbaru.'}
            </p>
            <button
              type="button"
              onClick={() => {
                if (window.confirm(`Perbarui CKP App ke versi ${s.update.terbaru}? Aplikasi akan ditutup lalu dibuka ulang. Profil, token, dan hasil tidak dihapus.`)) {
                  perbaruiApp();
                }
              }}
              className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg bg-accent-solid px-2.5 py-2 text-[11.5px] font-bold text-white transition hover:opacity-90"
            >
              <Download className="size-3.5" /> Perbarui sekarang
            </button>
          </div>
        )}
        <div className="rounded-xl border border-line bg-surface-2 p-3">
          <div className="flex items-center gap-2">
            <span className={`size-2 rounded-full ${s.rclone.ready ? 'bg-ok shadow-[0_0_10px_var(--ok)]' : 'bg-bad'}`} />
            <span className="text-[12.5px] font-semibold text-ink">
              {s.boot ? (s.rclone.ready ? `rclone terhubung · ${s.rclone.remote}` : 'rclone tidak ditemukan') : 'mengecek rclone…'}
            </span>
          </div>
          {s.rclone.version && <p className="mt-1 truncate pl-4 text-[11px] text-muted">{s.rclone.version}</p>}
        </div>
        <button
          type="button"
          onClick={() => setTheme(dark ? 'terang' : 'gelap')}
          className="flex items-center justify-between rounded-xl border border-line bg-surface-2 px-3 py-2.5 text-[13px] font-semibold text-ink transition hover:bg-surface-3"
        >
          <span className="flex items-center gap-2">{dark ? <Moon className="size-4" /> : <Sun className="size-4" />}{dark ? 'Mode gelap' : 'Mode terang'}</span>
          <span className="relative flex h-5 w-9 items-center rounded-full bg-surface-3 ring-1 ring-inset ring-line">
            <motion.span layout transition={{ type: 'spring', stiffness: 500, damping: 35 }} className={`size-4 rounded-full bg-accent-solid ${dark ? 'ml-auto mr-0.5' : 'ml-0.5'}`} />
          </span>
        </button>
        {s.update?.versi && (
          <p className="text-center text-[10.5px] text-faint">CKP App v{s.update.versi}</p>
        )}
      </div>
    </aside>
  );
}

function MenuItem({ icon: Icon, label, aktif, onClick }) {
  return (
    <li>
      <button
        type="button"
        onClick={onClick}
        aria-current={aktif ? 'page' : undefined}
        className={`flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left text-[13.5px] font-semibold transition duration-200 ${aktif ? 'bg-accent-soft text-accent-text ring-1 ring-inset ring-accent/25' : 'text-ink/85 hover:bg-surface-2'}`}
      >
        <Icon className={`size-4 ${aktif ? 'text-accent-text' : 'text-muted'}`} />
        {label}
      </button>
    </li>
  );
}
