import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, LayoutGroup, motion } from 'motion/react';
import { CircleAlert, CircleCheck, Info, TriangleAlert, X } from 'lucide-react';
import { useApp } from '../store.jsx';

const BTN = {
  primary: 'bg-accent-solid text-white shadow-sm shadow-accent-solid/20 hover:brightness-110',
  soft: 'bg-accent-soft text-accent-text ring-1 ring-inset ring-accent/25 hover:bg-accent/15',
  secondary: 'bg-surface-2 text-ink ring-1 ring-inset ring-line hover:bg-surface-3',
  ghost: 'text-muted hover:bg-surface-2 hover:text-ink',
  danger: 'bg-bad-soft text-bad ring-1 ring-inset ring-bad/25 hover:bg-bad/15',
};
const SIZE = {
  sm: 'h-8 px-3 text-[12.5px] gap-1.5 rounded-lg',
  md: 'h-10 px-4 text-sm gap-2 rounded-xl',
  lg: 'h-12 px-6 text-[15px] gap-2.5 rounded-2xl',
};

export function Button({ variant = 'secondary', size = 'md', icon: Icon, className = '', children, ...rest }) {
  return (
    <motion.button
      whileTap={rest.disabled ? undefined : { scale: 0.97 }}
      type="button"
      className={`inline-flex items-center justify-center font-semibold whitespace-nowrap transition duration-200 disabled:pointer-events-none disabled:opacity-45 ${BTN[variant]} ${SIZE[size]} ${className}`}
      {...rest}
    >
      {Icon && <Icon className="size-[1.05em] shrink-0" strokeWidth={2.2} />}
      {children}
    </motion.button>
  );
}

export function Card({ className = '', children, ...rest }) {
  return (
    <div className={`rounded-2xl border border-line bg-surface shadow-[0_1px_0_rgb(255_255_255/0.03)_inset,0_10px_30px_-18px_rgb(0_0_0/0.35)] ${className}`} {...rest}>
      {children}
    </div>
  );
}

export function SectionHead({ eyebrow, title, desc, right }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div className="min-w-0">
        {eyebrow && <p className="mb-1 text-[11px] font-bold tracking-[0.14em] text-faint uppercase">{eyebrow}</p>}
        <h2 className="text-[22px] font-extrabold tracking-[-0.025em] text-ink">{title}</h2>
        {desc && <p className="mt-1 max-w-2xl text-[13.5px] leading-relaxed text-muted">{desc}</p>}
      </div>
      {right}
    </div>
  );
}

export function Empty({ icon: Icon, title, desc, action }) {
  return (
    <div className="flex flex-col items-center px-6 py-14 text-center">
      <div className="mb-4 grid size-14 place-items-center rounded-2xl bg-accent-soft text-accent-text">
        <Icon className="size-6" strokeWidth={1.8} />
      </div>
      <h3 className="text-[15px] font-bold text-ink">{title}</h3>
      <p className="mt-1.5 max-w-md text-[13px] leading-relaxed text-muted">{desc}</p>
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

const PILL = {
  ok: 'bg-ok-soft text-ok ring-ok/20',
  warn: 'bg-amber-soft text-amber ring-amber/25',
  bad: 'bg-bad-soft text-bad ring-bad/25',
  run: 'bg-run-soft text-run ring-run/25',
  wait: 'bg-surface-2 text-muted ring-line',
};
export function Pill({ tone = 'wait', children }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11.5px] font-semibold ring-1 ring-inset whitespace-nowrap ${PILL[tone]}`}>
      <span className={`size-1.5 rounded-full bg-current ${tone === 'run' ? 'animate-pulse' : ''}`} />
      {children}
    </span>
  );
}

export const inputCls =
  'w-full rounded-xl border border-line bg-surface-2 px-3.5 py-2.5 text-sm text-ink placeholder:text-faint outline-none transition duration-200 hover:border-line-strong focus:border-accent focus:ring-4 focus:ring-accent-ring/35';

export function Field({ label, hint, children, className = '' }) {
  return (
    <div className={`flex min-w-0 flex-col gap-1.5 ${className}`}>
      {label && <span className="text-[12px] font-semibold text-muted">{label}</span>}
      {children}
      {hint}
    </div>
  );
}

export function Segmented({ value, onChange, options, name }) {
  return (
    <LayoutGroup id={name}>
      <div role="radiogroup" className="inline-flex rounded-xl bg-surface-2 p-1 ring-1 ring-inset ring-line">
        {options.map((o) => {
          const on = o.value === value;
          return (
            <button
              key={o.value}
              role="radio"
              aria-checked={on}
              type="button"
              onClick={() => onChange(o.value)}
              className={`relative rounded-lg px-3.5 py-1.5 text-[13px] font-semibold transition duration-200 ${on ? 'text-white' : 'text-muted hover:text-ink'}`}
            >
              {on && <motion.span layoutId={`seg-${name}`} className="absolute inset-0 rounded-lg bg-accent-solid shadow-sm" transition={{ type: 'spring', stiffness: 420, damping: 34 }} />}
              <span className="relative">{o.label}</span>
            </button>
          );
        })}
      </div>
    </LayoutGroup>
  );
}

export function Modal({ open, onClose, title, desc, width = 'max-w-xl', children, footer }) {
  useEffect(() => {
    if (!open) return undefined;
    const k = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4 backdrop-blur-[3px]"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
        >
          <motion.div
            role="dialog" aria-modal="true" aria-label={title}
            className={`flex max-h-[86vh] w-full ${width} flex-col overflow-hidden rounded-2xl border border-line bg-surface shadow-2xl`}
            initial={{ opacity: 0, y: 14, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 360, damping: 32 }}
          >
            <div className="flex items-start gap-3 border-b border-line px-6 py-4">
              <div className="min-w-0 flex-1">
                <h3 className="text-[16px] font-extrabold tracking-[-0.02em] text-ink">{title}</h3>
                {desc && <p className="mt-0.5 text-[12.5px] leading-relaxed text-muted">{desc}</p>}
              </div>
              <button type="button" onClick={onClose} aria-label="Tutup" className="grid size-8 place-items-center rounded-lg text-muted transition hover:bg-surface-2 hover:text-ink">
                <X className="size-4" />
              </button>
            </div>
            <div className="scroll-thin min-h-0 flex-1 overflow-y-auto px-6 py-5">{children}</div>
            {footer && <div className="flex items-center justify-end gap-2 border-t border-line px-6 py-3.5">{footer}</div>}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export function TagInput({ value, onChange, placeholder }) {
  const [text, setText] = useState('');
  const ref = useRef(null);
  const tambah = (raw) => {
    const baru = String(raw || '').split(',').map((x) => x.trim()).filter(Boolean);
    if (!baru.length) return;
    onChange([...new Set([...value, ...baru])]);
    setText('');
  };
  return (
    <div
      onClick={() => ref.current?.focus()}
      className={`${inputCls} flex min-h-[42px] cursor-text flex-wrap items-center gap-1.5 py-1.5`}
    >
      <AnimatePresence initial={false}>
        {value.map((k) => (
          <motion.span
            key={k}
            layout
            initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}
            className="inline-flex items-center gap-1 rounded-lg bg-accent-soft py-1 pr-1 pl-2.5 text-[12.5px] font-semibold text-accent-text"
          >
            {k}
            <button type="button" aria-label={`Hapus ${k}`} onClick={(e) => { e.stopPropagation(); onChange(value.filter((x) => x !== k)); }} className="grid size-5 place-items-center rounded-md text-accent-text/70 hover:bg-accent/15 hover:text-accent-text">
              <X className="size-3" />
            </button>
          </motion.span>
        ))}
      </AnimatePresence>
      <input
        ref={ref}
        value={text}
        onChange={(e) => {
          const v = e.target.value;
          if (v.includes(',')) tambah(v);
          else setText(v);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Enter') { e.preventDefault(); tambah(text); }
          else if (e.key === 'Backspace' && !text && value.length) onChange(value.slice(0, -1));
        }}
        onBlur={() => tambah(text)}
        placeholder={value.length ? '' : placeholder}
        className="min-w-[120px] flex-1 bg-transparent px-1.5 py-1 text-sm text-ink placeholder:text-faint outline-none"
      />
    </div>
  );
}

const TOAST_ICON = { '': Info, ok: CircleCheck, warn: TriangleAlert, err: CircleAlert };
const TOAST_TONE = { '': 'text-accent-text', warn: 'text-amber', err: 'text-bad' };

export function Toasts() {
  const { s, dismissToast } = useApp();
  return (
    <div className="pointer-events-none fixed right-5 bottom-5 z-[60] flex w-[min(380px,calc(100vw-2rem))] flex-col gap-2.5">
      <AnimatePresence initial={false}>
        {s.toasts.map((t) => {
          const Icon = TOAST_ICON[t.kind] || Info;
          return (
            <motion.div
              key={t.id} layout
              initial={{ opacity: 0, x: 24, scale: 0.97 }} animate={{ opacity: 1, x: 0, scale: 1 }} exit={{ opacity: 0, x: 24 }}
              transition={{ type: 'spring', stiffness: 420, damping: 34 }}
              className="pointer-events-auto flex items-start gap-3 rounded-xl border border-line bg-surface p-3.5 pr-2.5 shadow-2xl"
            >
              <Icon className={`mt-0.5 size-4.5 shrink-0 ${TOAST_TONE[t.kind] || TOAST_TONE['']}`} />
              <p className="flex-1 text-[13px] leading-relaxed text-ink">{t.msg}</p>
              {t.action && (
                <button type="button" onClick={() => { t.action.fn(); dismissToast(t.id); }} className="rounded-lg px-2 py-1 text-[12.5px] font-bold text-accent-text hover:bg-accent-soft">
                  {t.action.label}
                </button>
              )}
              <button type="button" aria-label="Tutup" onClick={() => dismissToast(t.id)} className="grid size-7 shrink-0 place-items-center rounded-lg text-muted hover:bg-surface-2 hover:text-ink">
                <X className="size-3.5" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
