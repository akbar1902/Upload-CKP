'use strict';

/**
 * excel-builder.js
 * Menyusun file Excel CKP dengan struktur persis template
 * "Data Uji Coba SIKAP.xlsx" (pengukuran diambil langsung dari file itu):
 *
 * - Baris 1-6  : header metadata (merged A:B label, C:K nilai)
 * - Baris 7    : kosong (merged)
 * - Baris 8    : header kolom, hijau #C6E0B4, Calibri 11 bold, tinggi 40.5
 * - Baris 9+   : data, tinggi 47.25, wrap, tanggal berupa TEKS
 * - Sheet3     : daftar Rencana Kerja
 */

const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

const HIJAU = 'FFC6E0B4';
const LINK_BIRU = 'FF0000FF';
const BORDER_THIN = {
  top: { style: 'thin' },
  left: { style: 'thin' },
  bottom: { style: 'thin' },
  right: { style: 'thin' },
};

const LEBAR_KOLOM = {
  A: 4.53125,
  B: 15.3984375,
  C: 16.53125,
  D: 10.53125,
  E: 13.0,
  F: 36.53125,
  G: 35.3984375,
  H: 12.3984375,
  I: 39.73046875,
  J: 28.1328125,
  K: 13.86328125,
};

const HEADER_KOLOM = [
  'No',
  'Tanggal Mulai',
  'Tanggal Selesai',
  'Jam Mulai',
  'Jam Selesai',
  'Rencana Kinerja',
  'Kegiatan',
  'Progres (%)',
  'Capaian',
  'Data Dukung',
  'Capaian SKP',
];

function fontKalibri(bold) {
  return { name: 'Calibri', size: 11, bold: !!bold };
}

function sanitizeSheetName(nama) {
  const bersih = String(nama || 'CKP').replace(/[[\]:*?/\\]/g, ' ').trim() || 'CKP';
  return bersih.slice(0, 31);
}

async function tulisAman(workbook, filePath) {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const ext = path.extname(filePath);
  const stem = filePath.slice(0, -ext.length);
  let target = filePath;
  // Jangan menimpa diam-diam: jika file sudah ada, cari nama bebas dulu.
  if (fs.existsSync(target)) {
    let i = 1;
    while (fs.existsSync(`${stem}_${i}${ext}`) && i < 1000) i++;
    target = `${stem}_${i}${ext}`;
  }
  let n = 0;
  while (true) {
    try {
      await workbook.xlsx.writeFile(target);
      return target;
    } catch (e) {
      n++;
      if (n > 50) throw e;
      target = `${stem}_${n}${ext}`;
    }
  }
}

/**
 * @param {Object} opts
 * @param {Array}  opts.rows   [{ tanggalMulai, tanggalSelesai, rk, kegiatan, capaian, link }]
 * @param {Object} opts.header { pegawai, tahun, periode, wilayah, unitKerja, sheetName }
 * @param {Array}  opts.rkList daftar RK untuk Sheet3
 * @param {string} opts.outPath path file output yang diinginkan
 */
async function buildCKP({ rows, header, rkList, outPath }) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'CKP Excel Generator';
  wb.created = new Date();
  wb.modified = new Date();

  const ws = wb.addWorksheet(sanitizeSheetName(header.sheetName), {
    views: [{ showGridLines: true }],
  });

  for (const [kol, lebar] of Object.entries(LEBAR_KOLOM)) {
    ws.getColumn(kol).width = lebar;
  }

  // ── Baris 1: judul ──
  ws.mergeCells('A1:K1');
  const judul = ws.getCell('A1');
  judul.value = 'Capaian Kinerja Perhari (CKP)';
  judul.font = fontKalibri(true);
  judul.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HIJAU } };
  judul.alignment = { horizontal: 'center', vertical: 'middle' };
  ws.getRow(1).height = 14.25;

  // ── Baris 2-6: metadata ──
  const meta = [
    ['Pegawai', `: ${header.pegawai || ''}`],
    ['Tahun', `: ${header.tahun || ''}`],
    ['Periode SKP', `: ${header.periode || ''}`],
    ['Wilayah', `: ${header.wilayah || ''}`],
    ['Unit Kerja', `: ${header.unitKerja || ''}`],
  ];
  meta.forEach(([label, nilai], idx) => {
    const r = idx + 2;
    ws.mergeCells(`A${r}:B${r}`);
    ws.mergeCells(`C${r}:K${r}`);
    const cLabel = ws.getCell(`A${r}`);
    cLabel.value = label;
    cLabel.font = fontKalibri(true);
    cLabel.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HIJAU } };
    const cNilai = ws.getCell(`C${r}`);
    cNilai.value = nilai;
    cNilai.font = fontKalibri(false);
    cNilai.alignment = { horizontal: 'left', vertical: 'middle' };
    ws.getRow(r).height = 14.25;
  });

  // ── Baris 7: kosong ──
  ws.mergeCells('A7:K7');
  ws.getCell('A7').value = '';
  ws.getRow(7).height = 14.25;

  // ── Baris 8: header kolom ──
  const hr = ws.getRow(8);
  hr.height = 40.5;
  HEADER_KOLOM.forEach((teks, idx) => {
    const cell = hr.getCell(idx + 1);
    cell.value = teks;
    cell.font = fontKalibri(true);
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: HIJAU } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    cell.border = BORDER_THIN;
  });

  // ── Baris 9+: data (tanggal disimpan sebagai TEKS, anti bug timezone) ──
  rows.forEach((d, idx) => {
    const r = ws.getRow(9 + idx);
    r.height = 47.25;
    const vals = [
      idx + 1,
      d.tanggalMulai,
      d.tanggalSelesai,
      null,
      null,
      d.rk,
      d.kegiatan,
      100,
      d.capaian,
      { text: d.link, hyperlink: d.link },
      'Ya',
    ];
    vals.forEach((v, cIdx) => {
      const cell = r.getCell(cIdx + 1);
      cell.value = v;
      cell.font = fontKalibri(false);
      cell.alignment = { vertical: 'middle', wrapText: true };
      cell.border = BORDER_THIN;
      if (cIdx <= 2) cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      if (cIdx === 9) {
        cell.font = { name: 'Calibri', size: 11, color: { argb: LINK_BIRU }, underline: true };
      }
    });
  });

  // ── Sheet3: daftar RK ──
  const wsRK = wb.addWorksheet('Sheet3');
  wsRK.getColumn('A').width = 87.1328125;
  wsRK.getCell('A1').value = 'Rencana Kerja';
  wsRK.getCell('A1').font = fontKalibri(true);
  (rkList || []).forEach((rk, idx) => {
    const cell = wsRK.getCell(`A${idx + 2}`);
    cell.value = rk;
    cell.font = fontKalibri(false);
  });

  return tulisAman(wb, outPath);
}

module.exports = { buildCKP, HEADER_KOLOM, sanitizeSheetName };
