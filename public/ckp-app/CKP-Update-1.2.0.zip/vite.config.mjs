import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// Source UI ada di web/, hasil build masuk ke public/ (dilayani Express seperti biasa).
// Dev: `npm run dev` → http://localhost:5173 (API diproxy ke server di 3230).
export default defineConfig({
  root: 'web',
  plugins: [react(), tailwindcss()],
  build: {
    outDir: '../public',
    emptyOutDir: true,
  },
  server: {
    port: 5173,
    proxy: { '/api': 'http://localhost:3230' },
  },
});
