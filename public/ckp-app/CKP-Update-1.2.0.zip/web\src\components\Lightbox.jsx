import { useCallback, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { fmtBytes, fotoUrl } from '../lib/format.js';

// Pratinjau foto layar penuh. items: [{ entryName, originalName, size?, driveName? }]
export default function Lightbox({ open, items, idx, zipPath, onIdx, onClose }) {
  const n = items.length;
  const it = items[idx];
  const geser = useCallback((d) => { if (n) onIdx((idx + d + n) % n); }, [idx, n, onIdx]);

  useEffect(() => {
    if (!open) return undefined;
    const k = (e) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowLeft') geser(-1);
      else if (e.key === 'ArrowRight') geser(1);
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [open, geser, onClose]);

  return (
    <AnimatePresence>
      {open && it && (
        <motion.div
          className="fixed inset-0 z-[55] flex flex-col bg-black/85 backdrop-blur-sm"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}
        >
          <div className="flex items-center gap-3 px-5 py-4 text-white">
            <span className="tnum rounded-full bg-white/10 px-2.5 py-1 text-[12px] font-semibold">{idx + 1} / {n}</span>
            <div className="min-w-0 flex-1">
              <p className="truncate font-mono text-[13px]">{it.originalName || it.namaFile}</p>
              <p className="text-[11.5px] text-white/60">
                {fmtBytes(it.size ?? it.sizeBytes ?? 0)}{it.driveName ? ` · di Drive: ${it.driveName}` : ''}
              </p>
            </div>
            <button type="button" onClick={onClose} aria-label="Tutup" className="grid size-9 place-items-center rounded-full bg-white/10 transition hover:bg-white/20">
              <X className="size-4" />
            </button>
          </div>
          <div className="relative flex min-h-0 flex-1 items-center justify-center px-16">
            <motion.img
              key={it.entryName}
              src={fotoUrl(zipPath, it.entryName)}
              alt={it.originalName || ''}
              initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.2 }}
              className="max-h-full max-w-full rounded-lg object-contain shadow-2xl"
            />
            {n > 1 && (
              <>
                <button type="button" onClick={() => geser(-1)} aria-label="Sebelumnya" className="absolute top-1/2 left-4 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/20">
                  <ChevronLeft className="size-5" />
                </button>
                <button type="button" onClick={() => geser(1)} aria-label="Berikutnya" className="absolute top-1/2 right-4 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-white/10 text-white transition hover:bg-white/20">
                  <ChevronRight className="size-5" />
                </button>
              </>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
