# Lepas autostart CKP App.
$ErrorActionPreference = 'Stop'
$startup = [Environment]::GetFolderPath('Startup')
$vbs = Join-Path $startup 'CKP App.vbs'
if (Test-Path $vbs) {
  Remove-Item -Path $vbs -Force
  Write-Host "Autostart CKP App dilepas." -ForegroundColor Green
} else {
  Write-Host "Autostart CKP App memang belum dipasang."
}
exit 0
