'use strict';
// Samakan rk-list.json tiap profil dengan peta RK per pegawai.
// Dipakai setelah scripts/peta-rk.js dijalankan, atau untuk membersihkan
// daftar lama yang menumpuk (mis. 86 RK padahal seharusnya 44).
//
// Jalankan: node scripts/sinkron-rk-list.js
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const DATA = path.join(ROOT, 'data');
const peta = JSON.parse(fs.readFileSync(path.join(ROOT, 'src', 'config', 'rk-pegawai.json'), 'utf8'));
const reg = JSON.parse(fs.readFileSync(path.join(DATA, 'profiles.json'), 'utf8'));
const profiles = Array.isArray(reg.profiles) ? reg.profiles : [];

const petaByNip = new Map((peta.pegawai || []).map((p) => [String(p.nip || ''), p]));

let diubah = 0;
for (const profile of profiles) {
  const data = petaByNip.get(String(profile.nip || ''));
  if (!data || !Array.isArray(data.rks) || data.rks.length === 0) {
    console.log(`- ${profile.id}: tidak ada di peta, dilewati`);
    continue;
  }
  const daftar = [...new Set(data.rks.map((r) => String(r.nama || '').trim()).filter(Boolean))];
  const file = path.join(DATA, 'profiles', profile.id, 'rk-list.json');
  let lama = [];
  try { lama = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { lama = []; }
  if (Array.isArray(lama) && lama.length === daftar.length && lama.every((x, i) => x === daftar[i])) {
    console.log(`= ${profile.id}: sudah sama (${daftar.length} RK)`);
    continue;
  }
  const backup = file.replace(/\.json$/i, '.sebelum-peta.json');
  if (fs.existsSync(file) && !fs.existsSync(backup)) {
    fs.copyFileSync(file, backup);
  }
  fs.writeFileSync(file, JSON.stringify(daftar, null, 2) + '\n');
  diubah++;
  console.log(`✓ ${profile.id}: ${Array.isArray(lama) ? lama.length : 0} → ${daftar.length} RK`);
}

console.log(`\nSelesai. ${diubah} profil diperbarui dari ${profiles.length} profil.`);
