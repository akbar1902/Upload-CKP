'use strict';

/**
 * Parser dataset RK per pegawai (file Matriks per tim).
 * Satu sel "Rencana Kinerja" boleh berisi beberapa poin (dipisah • / baris baru);
 * setiap poin dihitung sebagai RK terpisah.
 */

function decodeEntities(value) {
  let s = String(value ?? '');
  // Data asli kadang berisi "&amp;amp;" (double-encoded).
  for (let i = 0; i < 3; i += 1) {
    s = s
      .replace(/&amp;/gi, '&')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>');
  }
  return s;
}

function rapikanTeks(value) {
  return decodeEntities(value)
    .replace(/\u00a0/g, ' ')
    .replace(/[\u2012\u2013\u2014\u2015]/g, '-')
    .replace(/\s+/g, ' ')
    .trim();
}

function kunciRk(value) {
  return rapikanTeks(value).toLowerCase().replace(/[^a-z0-9]/g, '');
}

function splitRkCell(value) {
  const hasil = [];
  const sudah = new Set();
  for (const bagian of String(value ?? '').split(/[•\n\r]+/)) {
    const rk = rapikanTeks(bagian).replace(/^[-–—*]+\s*/, '').trim();
    if (!rk || rk.length < 5) continue;
    const kunci = kunciRk(rk);
    if (!kunci || sudah.has(kunci)) continue;
    sudah.add(kunci);
    hasil.push(rk);
  }
  return hasil;
}

function parsePegawai(value) {
  const teks = rapikanTeks(value);
  const m = teks.match(/^\[([^\]]+)\]\s*(.*)$/);
  return m
    ? { nip: m[1].trim(), nama: rapikanTeks(m[2]) }
    : { nip: '', nama: teks };
}

/**
 * records: [{ nip, nama, jabatan, status, team, rks: string[] }]
 * Hasil: satu entri per pegawai, RK digabung dari semua tim tanpa duplikat.
 */
function susunPegawai(records) {
  const peta = new Map();
  for (const rec of Array.isArray(records) ? records : []) {
    const nip = rapikanTeks(rec && rec.nip);
    const nama = rapikanTeks(rec && rec.nama);
    if (!nip && !nama) continue;
    const kunci = nip ? `nip:${nip}` : `nama:${nama.toLowerCase()}`;
    if (!peta.has(kunci)) {
      peta.set(kunci, {
        nip,
        nama,
        jabatan: '',
        teams: [],
        ketuaTeams: [],
        peran: [],
        rks: [],
        _rkSeen: new Set(),
      });
    }
    const e = peta.get(kunci);
    if (nama && nama.length >= e.nama.length) e.nama = nama;
    const jabatan = rapikanTeks(rec && rec.jabatan);
    if (jabatan && jabatan.length >= e.jabatan.length) e.jabatan = jabatan;
    const team = rapikanTeks(rec && rec.team);
    const status = rapikanTeks(rec && rec.status);
    if (team && !e.teams.includes(team)) e.teams.push(team);
    if (team && /ketua/i.test(status) && !e.ketuaTeams.includes(team)) e.ketuaTeams.push(team);
    if (team || status) {
      const peran = `${team}::${status}`;
      if (!e.peran.some((p) => `${p.team}::${p.status}` === peran)) {
        e.peran.push({ team, status });
      }
    }
    for (const rk of Array.isArray(rec && rec.rks) ? rec.rks : []) {
      const namaRk = rapikanTeks(rk);
      const kunciRkIni = kunciRk(namaRk);
      if (!kunciRkIni || e._rkSeen.has(kunciRkIni)) continue;
      e._rkSeen.add(kunciRkIni);
      e.rks.push(namaRk);
    }
  }

  return [...peta.values()]
    .map(({ _rkSeen, ...e }) => e)
    .sort((a, b) => a.nama.localeCompare(b.nama, 'id'));
}

function ringkasDataset({ employees, teams }) {
  const semuaRk = new Set();
  for (const e of Array.isArray(employees) ? employees : []) {
    for (const rk of Array.isArray(e.rks) ? e.rks : []) {
      const k = kunciRk(rk);
      if (k) semuaRk.add(k);
    }
  }
  return {
    jumlahPegawai: Array.isArray(employees) ? employees.length : 0,
    jumlahTim: Array.isArray(teams) ? teams.length : 0,
    jumlahRkUnik: semuaRk.size,
    pegawaiTanpaRk: (Array.isArray(employees) ? employees : []).filter((e) => !e.rks || e.rks.length === 0).length,
  };
}

module.exports = {
  splitRkCell,
  parsePegawai,
  susunPegawai,
  ringkasDataset,
  rapikanTeks,
  kunciRk,
};
