# Panduan Multi-Pengguna â€” CKP App + CKP Companion

Panduan singkat untuk memakai CKP App bersama rekan sekantor. Inti perubahannya:
**setiap pegawai punya profil sendiri**, karena daftar Rencana Kinerja (RK) tiap
orang berbeda. Profil memisahkan RK, kata kunci RK, kamus singkatan, header Excel,
folder upload, dan riwayat ekspor.

---

## 1. Cara berbagi (pilih salah satu)

### A. Satu komputer jadi server kantor

Cocok bila rekan-rekan berada di jaringan kantor yang sama.

1. Jalankan `Jalankan CKP.bat` di komputer server.
2. Buka **Profil & rekan** di sidebar. Alamat LAN tertulis di kartu
   â€œDipakai bersama di kantorâ€, misalnya `http://10.210.2.88:3230`.
3. Bagikan alamat itu ke rekan. Mereka membuka di browser/Edge.
4. Bila muncul peringatan Windows Firewall, izinkan **Node.js** untuk
   jaringan privat/kantor.

Catatan:
- Server mendengarkan `0.0.0.0` secara default. Untuk mengunci hanya di komputer
  sendiri, jalankan dengan `set HOST=127.0.0.1` sebelum `node src/server.js`.
- Upload ke Google Drive tetap memakai **rclone** di komputer server. Bila akun
  Drive tiap pegawai berbeda, buat remote rclone berbeda lalu pilih per profil
  (tombol **Ubah** di kartu profil).
- Aplikasi belum memakai login. Gunakan hanya di jaringan kantor yang tepercaya.

### B. Tiap pegawai memakai salinan sendiri

Cocok bila tiap orang ingin memakai laptop masing-masing.

1. Di komputer Anda, jalankan **`Buat Paket Untuk Rekan.bat`**.
   Script membuat folder **dan ZIP** `CKP-App-Untuk-Rekan` yang berisi:
   - CKP App (tanpa `node_modules` dan `data/`),
   - Chrome extension `chrome-extension/ckp-companion`,
   - rclone portable di `tools/rclone/` (bila tersedia),
   - panduan `BACA-DULU.txt`.
2. Bagikan file **`CKP-App-Untuk-Rekan.zip`** ke rekan (WhatsApp/Drive/LAN).
3. Rekan mengekstrak ZIP, install **Node.js LTS**, lalu double-click
   **`Jalankan CKP.bat`**.
4. Rekan membuat profilnya sendiri, mengimpor RK miliknya, lalu menyiapkan
   rclone/Google Drive (panduan ada di `BACA-DULU.txt`).
5. Pasang extension: `chrome://extensions` → Developer mode → **Load unpacked**
   → pilih `chrome-extension/ckp-companion`.

Data antar-laptop terpisah total. Untuk memindahkan pengaturan RK, gunakan
**Ekspor** / **Impor profil** (file JSON). Jangan pernah membagikan folder
`data/` milik Anda karena berisi upload, hasil ekspor, dan token SIKAP pribadi.

---

## 2. Menyiapkan profil pegawai baru

1. Buka **Profil & rekan**.
2. Isi **Nama pegawai**, **NIP**, **Jabatan**, **Unit kerja**.
3. Pilih isi awal:
   - **Kosong** â€” disarankan, karena RK tiap pegawai berbeda.
   - **Salin dari profilâ€¦** â€” hanya bila RK-nya memang sama (mis. satu tim).
4. Klik **Buat profil & pakai**. Aplikasi otomatis pindah ke halaman Daftar RK.

### Mengisi RK milik pegawai itu

**Cara tercepat:** di **Profil & rekan** ada kartu **Dataset RK kantor**. Klik
**Impor semua pegawai** — aplikasi membuat profil tiap pegawai beserta RK
miliknya. Satu pegawai = satu profil; tim hanya info tambahan. Untuk satu orang,
klik **Pilih pegawai** lalu **Buat profil**.

Kalau ingin manual, di **Daftar RK** ada dua cara:

- **Impor daftar RK** â€” tempel satu RK per baris, atau unggah file
  `.xlsx/.xls/.csv/.txt` yang memiliki kolom â€œRencana Kinerjaâ€.
- **Tambah satu RK** â€” untuk koreksi/tambahan kecil.

Setelah daftar RK terisi, buka **Kata kunci RK** dan petakan kata kunci yang
sering muncul di nama file (mis. `susenas`, `pst`, `rapat`) ke RK yang tepat.
Draft berikutnya akan menebak RK lebih akurat.

> Jangan menyalin daftar RK pegawai lain kecuali RK-nya memang sama. Export akan
> menolak RK yang tidak ada di daftar profil aktif.

---

## 3. Ganti profil

- Pemilih profil ada di **kanan atas** dan juga di kartu profil pada sidebar.
- Draft yang sedang dikerjakan disimpan dulu di browser untuk profil lama.
- Upload yang sedang berjalan tidak ikut pindah profil; selesaikan dulu.

Header **Pegawai** di kartu â€œKepala arsipâ€ otomatis tersimpan per profil. Mengubah
format `[NIP] Nama` di sana juga memperbarui identitas profil.

---

## 4. Memindahkan / mencadangkan profil

- **Ekspor** pada kartu profil menghasilkan `ckp-profil-<nama>.json` yang berisi
  identitas, header, daftar RK, kata kunci, dan kamus.
- Di komputer lain: **Profil & rekan â†’ Impor profil dari rekan â†’ pilih file**.
- File JSON tidak memuat foto/Excel/riwayat ekspor, jadi aman dibagikan.

---

## 5. Integrasi SIKAP (opsional, kirim langsung)

**Cara termudah — satu klik:**

1. CKP App → **Profil & rekan** → kartu **Integrasi SIKAP**.
2. Isi **Alamat SIKAP** (cukup sekali), klik **Hubungkan SIKAP**.
3. Tab SIKAP terbuka → login jika diminta → klik **Setujui & hubungkan CKP App**.
4. Kembali ke CKP App; koneksi selesai otomatis dan daftar RK ikut tersinkron.
5. Buka **Export** → **Kirim ke SIKAP**.

Tidak perlu menyalin token. Opsi token manual tetap ada di bagian **Opsi lanjutan**
bila dibutuhkan.

Jika ada pesan “RK berikut belum ada di SIKAP”, klik **Hubungkan ulang** (atau
tarik RK di opsi lanjutan) lalu pilih RK yang benar di Draft.

Token bersifat rahasia per pegawai. Jika bocor, cabut di SIKAP → **Integrasi CKP App**
→ daftar token. Token tidak ikut saat profil diekspor ke rekan.

---

## 6. Ekstensi Chrome (CKP Companion v0.4.1)

1. Buka `chrome://extensions` â†’ aktifkan **Developer mode**.
2. **Load unpacked** â†’ pilih folder
   `Auto-Input-CKP/chrome-extension-v0.3.4/ckp-v034`.
3. Buka `https://kipapp.bps.go.id/`, klik ikon CKP Companion.
4. Di panel ada kartu **Profil pegawai**:
   - Profil dari CKP-App dibuat otomatis saat handoff.
   - **Ganti** untuk memilih/menambah rekan.
   - Status kegiatan disimpan terpisah per profil.
5. Alur normal: susun draft di CKP-App â†’ pastikan profil aktif benar â†’
   **Export Excel** atau **Kirim ke KipApp** â†’ di panel klik
   **Isi & simpan semua kegiatan**.

> **Catatan jaringan:** tombol **Kirim ke KipApp** (handoff otomatis) hanya
> tersedia bila CKP-App dibuka lewat `localhost`/`127.0.0.1` â€” yaitu di komputer
> tempat server CKP-App berjalan. Rekan yang membuka CKP-App lewat alamat LAN
> sebaiknya memakai **Export Excel** lalu memilih file itu di panel ekstensi
> (prosesnya sama, hanya satu langkah tambahan).

Bila file Excel dipilih manual di panel, file itu masuk ke profil yang sedang
aktif. Ganti profil dulu bila file tersebut milik rekan lain.

---

## 7. Perilaku data & pembersihan

- Data profil: `CKP-App/data/profiles/<id-profil>/`
  (`config.json`, `rk-list.json`, `rk-keywords.json`, `kamus-singkatan.json`,
  `uploads/`, `Hasil Link/`, `Hasil CKP/`).
- Daftar profil: `CKP-App/data/profiles.json`.
- Profil pertama hasil migrasi diberi tanda `data lama`; riwayat ekspor di
  `data/Hasil CKP` tetap terlihat untuk profil itu.
- Menghapus profil akan menghapus folder profil tersebut. Minimal satu profil
  harus tersisa.
- Data ekstensi: `chrome.storage.local`, kunci
  `ckp-companion-state-v2:<id-profil>` dan `ckp-companion-profiles-v1`.

---

## 8. Jika ada masalah

| Gejala | Penyebab / solusi |
| --- | --- |
| Rekan tidak bisa membuka alamat LAN | Firewall Windows memblokir Node.js; izinkan di jaringan kantor. Pastikan satu jaringan/Wi-Fi. |
| RK rekan tidak muncul | Pastikan profil yang aktif di kanan atas sudah benar, lalu cek **Daftar RK**. |
| Export menolak â€œRK belum dipilih / tidak validâ€ | RK baris itu bukan milik daftar profil aktif. Pilih RK dari picker atau impor RK yang benar. |
| Draft lama berisi RK pegawai lain | Ganti profil, lalu muat draft yang ditawarkan untuk profil itu; atau hitung ulang saran RK. |
| Handoff masuk ke profil ekstensi yang salah | Di CKP-App pastikan profil aktif benar sebelum **Kirim ke KipApp**; ekstensi akan mengikuti `profileId` yang dikirim. |
| Ekstensi versi lama | `chrome://extensions` â†’ **Reload** pada CKP Companion, lalu muat ulang halaman KipApp. |
