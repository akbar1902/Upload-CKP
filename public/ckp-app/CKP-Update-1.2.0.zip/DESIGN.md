# Design

<!-- impeccable:design-schema 1 -->

## World

Arsip dinas bercahaya: ritual arsip bulanan, bukan form admin. Cahaya teal menandai
yang hidup (tahap aktif, progress berjalan, aksi utama); cap amber miring menandai
yang butuh mata manusia. Gelap pine-ink sebagai default (dipakai malam hari),
terang warm-paper via toggle (ruangan terang). Playful di permukaan, presisi di data.

## Tokens

- Font UI: Plus Jakarta Sans (400–800). Mono (JetBrains Mono / SF Mono):
  nama file, ukuran, tanggal, nomor slip — hanya data teknis.
- Aksen: teal BPS `#0F766E`; glow `#14B8A6` (dark) — hanya live state.
  Amber `#F59E0B` — hanya stamp review / warning.
- Status: sukses hijau, gagal merah, uploading biru — sticker pills + glow lembut.
- Radius: kartu 16px, kontrol 10px, pills 999px. Spacing basis 8px.
- Angka selalu tabular-nums; heading tracking -0.02em s/d -0.03em.

## Signature interaction

Rel pipa bercahaya: satu garis vertikal di rail menyala bertahap mengikuti tahap
selesai (transition 0.6s expo-out). Tiap tahap: orb bernomor → centang teal saat
selesai, sublabel status live ("23 berkas siap", "4 bercap miring").

## Components

- Rail tahap (pengganti nav-item langkah): orb + label + sublabel + badge count.
- Slip arsip: kartu dengan nomor slip mono (SLIP-01…) + sekat perforasi dashed
  antara area aksi dan area isi.
- Sapaan bulan oversized: "Bulan Oktober, arsip beres." — glow hanya di nama bulan.
- Month stamp miring -2deg di topbar: "CKP · Oktober".
- Stamp review miring -3deg uppercase pada baris draft belum lengkap.
- Statistik chunky 26px tabular; progress global 30px + bar 10px.
- Segmented kecepatan: opsi aktif = teal menyala.
- Theme toggle di rail-foot, persisten via localStorage `ckp_theme`.

## States & motion

Satu authored moment: cahaya rel. Selebihnya fadeUp 0.25s antar view,
hover lembut, tanpa entrance per-section. Hormati prefers-reduced-motion.
Empty state tiap tahap menjelaskan tahap berikutnya. Export terkunci sampai valid.

## Constraints kept

Semua 105 ID + 6 ID dinamis + kelas render app.js dipertahankan; logic
upload/draft/export/bridge tidak berubah. Kontras AA: teks teal di dark memakai
`#2dd4bf`, di light `--teal-d`; faint dark `#7e9794`.
