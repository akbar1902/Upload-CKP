'use strict';

/**
 * parser.js
 * Parsing nama file bukti dukung menjadi tanggal + kegiatan mentah.
 *
 * Pola utama yang didukung (ekstensi file diabaikan):
 *   "21 September_melakukan pelayanan PST"      -> tgl 21-21 September
 *   "20-27 September_Klasikal Latsar"           -> tgl 20-27 September
 *   "1 Oktober_Menjadi Operator Rilis BRS"      -> tgl 1-1 Oktober
 *
 * Varian yang ikut diterima (sering muncul di nama file nyata):
 *   "1. Oktober_Apel"                 (titik setelah tanggal)
 *   "1 Oktober 2026_Apel"             (tahun di nama file)
 *   "1 Okt 2026 - Apel"               (singkatan bulan + strip)
 *   "01-10-2026_Apel" / "2026-10-01"  (tanggal angka)
 *   "01.10.2026 - Apel"               (tanggal angka gaya Indonesia)
 *   "Dokumentasi 5 Oktober_kegiatan"  (tanggal tidak di awal nama)
 *   "WhatsApp Image 2026-10-21 at 10.30.00 - kegiatan"
 *
 * Tahun tidak wajib ada di nama file; bila tidak ada, diisi dari form
 * (default tahun berjalan). Bila ada, tahun itu yang dipakai.
 */

const BULAN = {
  januari: { index: 1, nama: 'Januari' },
  februari: { index: 2, nama: 'Februari' },
  maret: { index: 3, nama: 'Maret' },
  april: { index: 4, nama: 'April' },
  mei: { index: 5, nama: 'Mei' },
  juni: { index: 6, nama: 'Juni' },
  juli: { index: 7, nama: 'Juli' },
  agustus: { index: 8, nama: 'Agustus' },
  september: { index: 9, nama: 'September' },
  oktober: { index: 10, nama: 'Oktober' },
  november: { index: 11, nama: 'November' },
  desember: { index: 12, nama: 'Desember' },
};

// Singkatan / ejaan lain yang lazim. Semua dipetakan ke nama bulan resmi di BULAN.
const ALIAS_BULAN = {
  jan: 'januari', january: 'januari',
  feb: 'februari', pebruari: 'februari', february: 'februari',
  mar: 'maret', march: 'maret',
  apr: 'april', april: 'april',
  may: 'mei',
  jun: 'juni', june: 'juni',
  jul: 'juli', july: 'juli',
  agu: 'agustus', agt: 'agustus', agust: 'agustus', aug: 'agustus', august: 'agustus',
  sep: 'september', sept: 'september', septem: 'september', september: 'september',
  okt: 'oktober', oct: 'oktober', october: 'oktober',
  nov: 'november', nop: 'november', nopember: 'november', november: 'november',
  des: 'desember', dec: 'desember', december: 'desember',
};

const MAKS_HARI = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function escapeRegExp(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function cariBulan(token) {
  const t = String(token || '').toLowerCase().replace(/\./g, '').trim();
  if (!t) return null;
  const kunci = BULAN[t] ? t : ALIAS_BULAN[t];
  return kunci ? BULAN[kunci] : null;
}

function tanpaEkstensi(namaFile) {
  return String(namaFile || '')
    .replace(/\.[A-Za-z0-9]{1,5}$/, '')
    .replace(/[\u2012\u2013\u2014\u2015]/g, '-')
    .replace(/\u00a0/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^[•·*]+\s*/, '');
}

// Buang pemisah di awal sisa teks ("_", "-", ".", ":") + keterangan jam
// yang sering menempel setelah tanggal pada nama file kamera/WhatsApp.
function bersihkanKegiatan(sisa) {
  return String(sisa || '')
    .replace(/^[\s_\-–—|.,:;()[\]]+/, '')
    .replace(/^(?:at|jam|pukul)\s+\d{1,2}[.:]\d{2}(?:[.:]\d{2})?\s*[-_ ]*/i, '')
    .replace(/^\d{6}\s*[-_ ]+/, '') // 20261021_103000_kegiatan
    .replace(/^[\s_\-–—|.,:;()[\]]+/, '')
    .replace(/_/g, ' ')
    .replace(/\s*\((?:copy\s*)?\d+\)\s*$/i, '') // buang penanda duplikat "(1)", "(copy 2)"
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[\s_|.,:;()[\]]+$/, '');
}

// Hasil tanggal lengkap (bisa dipakai walau kegiatan belum terbaca).
function tanggalHasil({ tglAwal, tglAkhir, bulan, tahun, sisa }) {
  const akhir = tglAkhir || tglAwal;
  const MAKS = MAKS_HARI[bulan.index - 1];
  if (tglAwal < 1 || tglAwal > MAKS || akhir < 1 || akhir > MAKS) {
    return { ok: false, alasan: 'Tanggal di luar rentang valid', kegiatanRaw: bersihkanKegiatan(sisa) };
  }
  if (akhir < tglAwal) {
    return { ok: false, alasan: 'Tanggal selesai lebih awal dari tanggal mulai', kegiatanRaw: bersihkanKegiatan(sisa) };
  }
  const kegiatanRaw = bersihkanKegiatan(sisa);
  return {
    ok: !!kegiatanRaw,
    tglAwal,
    tglAkhir: akhir,
    bulan: bulan.nama,
    bulanIndex: bulan.index,
    tahun: tahun || null,
    kegiatanRaw,
    alasan: kegiatanRaw ? '' : 'Kegiatan kosong setelah tanggal — tulis kegiatan manual',
  };
}

// Cari tanggal lengkap dari nama file. Mengembalikan null bila tidak ada tanggal.
function cariTanggal(teks) {
  // 1. Rentang lintas bulan: "30 September-2 Oktober_kegiatan".
  //    Tanggal mulai tetap diselamatkan; bulan selesai berbeda sehingga
  //    user diminta melengkapi sendiri.
  const lintas = teks.match(/(\d{1,2})\s*(?:\.\s*)?([A-Za-z]+)\s*(?:-|s\.?\s?d\.?|s\/d|sampai(?:\s+dengan)?|hingga)\s*(\d{1,2})\s+([A-Za-z]+)\s*(?:(\d{4}))?/i);
  if (lintas) {
    const bAwal = cariBulan(lintas[2]);
    const bAkhir = cariBulan(lintas[4]);
    if (bAwal && bAkhir && bAwal.index !== bAkhir.index) {
      const tglAwal = parseInt(lintas[1], 10);
      const MAKS = MAKS_HARI[bAwal.index - 1];
      if (tglAwal >= 1 && tglAwal <= MAKS) {
        return {
          ok: false,
          tglAwal,
          tglAkhir: null,
          bulan: bAwal.nama,
          bulanIndex: bAwal.index,
          tahun: lintas[5] ? parseInt(lintas[5], 10) : null,
          kegiatanRaw: bersihkanKegiatan(teks.slice(lintas.index + lintas[0].length)),
          alasan: 'Rentang lintas bulan — tanggal selesai isi manual',
        };
      }
    }
  }

  // 2. Tanggal dengan nama bulan, boleh rentang dalam bulan yang sama.
  //    Contoh: "21 September_…", "20-27 September_…", "1. Okt 2026 - …".
  //    Coba semua kemunculan karena nama file bisa berawalan kata lain
  //    ("Dokumentasi 5 Oktober_kegiatan").
  const polaNamaBulan = /(?<!\d)(\d{1,2})\s*(?:\.\s*)?(?:(?:-|s\.?\s?d\.?|s\/d|sampai(?:\s+dengan)?|hingga)\s*(\d{1,2}))?\s*[._\-/]?\s*([A-Za-z]+)\s*(?:(\d{4}))?/gi;
  for (const m of teks.matchAll(polaNamaBulan)) {
    const bulan = cariBulan(m[3]);
    if (!bulan) continue;
    return tanggalHasil({
      tglAwal: parseInt(m[1], 10),
      tglAkhir: m[2] ? parseInt(m[2], 10) : null,
      bulan,
      tahun: m[4] ? parseInt(m[4], 10) : null,
      sisa: teks.slice(m.index + m[0].length),
    });
  }

  // 3. Tanggal angka: 2026-10-21 / 21-10-2026 / 21.10.2026 / 21/10/2026.
  const angka = teks.match(/(?<!\d)(\d{4})[._/-](\d{1,2})[._/-](\d{1,2})(?!\d)/)
    || teks.match(/(?<!\d)(\d{1,2})[._/-](\d{1,2})[._/-](\d{4})(?!\d)/);
  if (angka) {
    let th, bl, tg;
    if (angka[1].length === 4) { th = +angka[1]; bl = +angka[2]; tg = +angka[3]; }
    else { tg = +angka[1]; bl = +angka[2]; th = +angka[3]; }
    const bulan = Object.values(BULAN).find((b) => b.index === bl);
    if (bulan) {
      return tanggalHasil({ tglAwal: tg, tglAkhir: null, bulan, tahun: th, sisa: teks.slice(angka.index + angka[0].length) });
    }
  }

  // 4. Tanggal angka tanpa tahun: "01-10_kegiatan" / "1.10 - kegiatan".
  const angkaPendek = teks.match(/(?<!\d)(\d{1,2})[./-](\d{1,2})(?![./-]?\d)(?!\d)/);
  if (angkaPendek) {
    const tg = +angkaPendek[1];
    const bl = +angkaPendek[2];
    const bulan = Object.values(BULAN).find((b) => b.index === bl);
    if (bulan && tg >= 1 && tg <= MAKS_HARI[bulan.index - 1]) {
      return tanggalHasil({ tglAwal: tg, tglAkhir: null, bulan, tahun: null, sisa: teks.slice(angkaPendek.index + angkaPendek[0].length) });
    }
  }

  // 5. Nama kamera/WhatsApp: "IMG_20261021_103000_kegiatan".
  const kamera = teks.match(/(?<!\d)(20\d{2})(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])(?!\d)/);
  if (kamera) {
    const bulan = Object.values(BULAN).find((b) => b.index === +kamera[2]);
    if (bulan) {
      return tanggalHasil({ tglAwal: +kamera[3], tglAkhir: null, bulan, tahun: +kamera[1], sisa: teks.slice(kamera.index + kamera[0].length) });
    }
  }

  return null;
}

function parseFileName(namaFile) {
  const teks = tanpaEkstensi(namaFile);

  if (!teks) {
    return { ok: false, alasan: 'Nama file kosong', kegiatanRaw: '' };
  }

  const hasil = cariTanggal(teks);
  if (hasil) return hasil;

  return {
    ok: false,
    alasan: 'Tanggal tidak terbaca dari nama file (contoh benar: "21 September_kegiatan")',
    kegiatanRaw: teks,
  };
}

/**
 * Kembangkan singkatan whole-word (case-insensitive) memakai kamus.
 * Aturan terpanjang diproses dulu; aturan dilewati bila ekspansinya
 * sudah ada di teks (mencegah ekspansi ganda).
 */
function expandKegiatan(teks, kamus) {
  let hasil = String(teks || '');
  const daftar = [...(kamus || [])]
    .filter((e) => e && e.singkatan && e.ekspansi)
    .sort((a, b) => b.singkatan.length - a.singkatan.length);

  for (const { singkatan, ekspansi } of daftar) {
    if (hasil.toLowerCase().includes(ekspansi.toLowerCase())) continue;
    // Hindari duplikasi kata: "pelayanan PST" -> langsung ekspansi
    // (kata sebelum singkatan sama dengan kata pertama ekspansi).
    const kataPertama = ekspansi.split(/\s+/)[0].replace(/[^a-zA-Z]/g, '');
    if (kataPertama) {
      const reDobel = new RegExp(`\\b${escapeRegExp(kataPertama)}\\s+${escapeRegExp(singkatan)}\\b`, 'gi');
      hasil = hasil.replace(reDobel, ekspansi);
      if (hasil.toLowerCase().includes(ekspansi.toLowerCase())) continue;
    }
    const re = new RegExp(`\\b${escapeRegExp(singkatan)}\\b`, 'gi');
    hasil = hasil.replace(re, ekspansi);
  }
  return hasil.replace(/\s+/g, ' ').trim();
}

function formatTanggal(tgl, bulanNama, tahun) {
  return `${tgl} ${bulanNama} ${tahun}`;
}

module.exports = { BULAN, parseFileName, expandKegiatan, formatTanggal, cariBulan };
