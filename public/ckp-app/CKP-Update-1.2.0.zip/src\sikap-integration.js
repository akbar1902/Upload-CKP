'use strict';

/**
 * Helper integrasi CKP App → SIKAP.
 * Semua fungsi murni (tanpa jaringan) supaya mudah diuji.
 */

const crypto = require('crypto');

const BULAN = {
  januari: 1, februari: 2, maret: 3, april: 4, mei: 5, juni: 6,
  juli: 7, agustus: 8, september: 9, oktober: 10, november: 11, desember: 12,
};

function normalizeBaseUrl(value) {
  const raw = String(value || '').trim();
  if (!raw) return { ok: false, error: 'Alamat SIKAP belum diisi.' };
  let url;
  try {
    url = new URL(raw);
  } catch (e) {
    return { ok: false, error: 'Alamat SIKAP tidak valid. Contoh: https://sikap.bps.go.id' };
  }
  if (!/^https?:$/.test(url.protocol)) {
    return { ok: false, error: 'Alamat SIKAP harus diawali http:// atau https://.' };
  }
  if (url.username || url.password) {
    return { ok: false, error: 'Alamat SIKAP tidak boleh memuat username/password.' };
  }
  const path = url.pathname.replace(/\/+$/, '');
  return { ok: true, url: `${url.origin}${path}` };
}

function periodeKeBulanTahun(header) {
  const nama = String((header && header.bulanPeriode) || '').trim().toLowerCase();
  const bulan = BULAN[nama];
  const tahun = parseInt((header && header.tahunData), 10);
  if (!bulan) return { ok: false, error: 'Bulan periode belum diisi (mis. Oktober).' };
  if (!tahun || tahun < 2020 || tahun > 2100) {
    return { ok: false, error: 'Tahun data belum valid.' };
  }
  return { ok: true, bulan, tahun };
}

function normalizeNamaRk(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/\btahun\s*20\d{2}\b/g, '')
    .replace(/\b20\d{2}\b/g, '')
    .replace(/[^a-z0-9]/g, '');
}

function cocokkanRkSikap(rks, nama) {
  const kunci = normalizeNamaRk(nama);
  if (!kunci) return null;
  const daftar = Array.isArray(rks) ? rks : [];
  for (const rk of daftar) {
    if (normalizeNamaRk(rk && rk.rencana_kinerja) === kunci) return rk;
  }
  // Fallback: abaikan akronim dalam tanda kurung, mis. "(PST)".
  const inti = (v) => normalizeNamaRk(String(v || '').replace(/\([^)]*\)/g, ' '));
  const kunciInti = inti(nama);
  if (!kunciInti) return null;
  for (const rk of daftar) {
    if (inti(rk && rk.rencana_kinerja) === kunciInti) return rk;
  }
  return null;
}

function cariRkBelumCocok(rks, rows) {
  const belum = [];
  const sudah = new Set();
  for (const row of Array.isArray(rows) ? rows : []) {
    const nama = String((row && row.rk) || '').trim();
    if (!nama) continue;
    const kunci = normalizeNamaRk(nama);
    if (!kunci || sudah.has(kunci)) continue;
    if (cocokkanRkSikap(rks, nama)) continue;
    sudah.add(kunci);
    belum.push(nama);
  }
  return belum;
}

function buatClientUploadId(rows, header) {
  const payload = {
    bulanPeriode: String((header && header.bulanPeriode) || ''),
    tahunData: Number(header && header.tahunData) || 0,
    sheetName: String((header && header.sheetName) || ''),
    rows: (Array.isArray(rows) ? rows : []).map((d) => ({
      kegiatan: String((d && d.kegiatan) || '').trim(),
      rk: String((d && d.rk) || '').trim(),
      tglAwal: (d && d.tglAwal) ?? null,
      tglAkhir: (d && d.tglAkhir) ?? null,
      bulan: String((d && d.bulan) || ''),
      tahun: (d && d.tahun) ?? null,
      link: String((d && d.link) || '').trim(),
    })),
  };
  return crypto.createHash('sha256').update(JSON.stringify(payload)).digest('hex');
}

module.exports = {
  BULAN,
  normalizeBaseUrl,
  periodeKeBulanTahun,
  normalizeNamaRk,
  cocokkanRkSikap,
  cariRkBelumCocok,
  buatClientUploadId,
};
