# ============================================================================
#  Updater CKP App
#
#  - Mengunduh paket update (ZIP) dari URL/path, atau membaca manifest update.json
#  - Menghentikan server, membackup kode lama, mengekstrak paket baru
#  - TIDAK menyentuh folder data/ (profil, token SIKAP, upload, hasil)
#  - Menjalankan ulang CKP App
#
#  Pemakaian:
#    powershell -ExecutionPolicy Bypass -File scripts\update-ckp.ps1 -Source <url|path|update.json>
#    powershell ... -File scripts\update-ckp.ps1 -Source https://.../update.json -Port 3230
# ============================================================================
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$Source,
  [int]$Port = 3230,
  [string]$Root = ''
)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($Root)) {
  $Root = Split-Path -Parent $PSScriptRoot
}
Set-Location $Root

$logDir = Join-Path $Root 'data\logs'
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$logFile = Join-Path $logDir 'update.log'

function Log([string]$pesan) {
  $baris = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $pesan"
  Write-Host $baris
  try { Add-Content -Path $logFile -Value $baris -Encoding UTF8 } catch { }
}

function Get-PortOwner([int]$p) {
  try {
    $conn = Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction Stop | Select-Object -First 1
    if ($conn) { return [int]$conn.OwningProcess }
  } catch { }
  try {
    $line = (netstat -ano | Select-String -Pattern ":$p\s+.*LISTENING" | Select-Object -First 1).Line
    if ($line) { return [int](($line -split '\s+')[-1]) }
  } catch { }
  return 0
}

function Stop-Ckp {
  $pidLama = Get-PortOwner $Port
  if ($pidLama -gt 0) {
    Log "Menghentikan CKP App (PID $pidLama)..."
    Stop-Process -Id $pidLama -Force -ErrorAction SilentlyContinue
    for ($i = 0; $i -lt 30; $i++) {
      Start-Sleep -Milliseconds 300
      if ((Get-PortOwner $Port) -eq 0) { return }
    }
  }
}

function Start-Ckp {
  $starter = Join-Path $Root 'scripts\start-ckp.ps1'
  if (Test-Path $starter) {
    Log 'Menjalankan CKP App...'
    Start-Process -FilePath 'powershell.exe' `
      -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $starter, '-Port', $Port) `
      -WorkingDirectory $Root | Out-Null
  } else {
    Log 'start-ckp.ps1 tidak ditemukan. Jalankan "Jalankan CKP.bat" manual.'
  }
}

# Fingerprint dependency saja — perubahan nomor versi di package.json tidak
# boleh memicu npm install ulang.
function Get-DependencyFingerprint([string]$file) {
  if (-not (Test-Path $file)) { return '' }
  try {
    $j = Get-Content $file -Raw | ConvertFrom-Json
    $d = [ordered]@{
      dependencies    = $j.dependencies
      devDependencies = $j.devDependencies
    }
    return ($d | ConvertTo-Json -Depth 12 -Compress)
  } catch {
    return ''
  }
}

# Sumber bisa berupa: URL zip, URL update.json, path zip, path update.json, folder.
function Resolve-ZipSource([string]$sumber) {
  $s = $sumber.Trim().Trim('"')
  if (-not $s) { throw 'Sumber update kosong.' }

  if ($s -match '^https?://') {
    if ($s -match '\.json(\?|$)') {
      Log "Membaca manifest: $s"
      $m = Invoke-RestMethod -Uri $s -TimeoutSec 30
      $u = [string]$m.url
      if (-not $u) { throw 'Manifest tidak memuat "url".' }
      if ($u -match '^https?://') { return $u }
      return ([uri]::new([uri]$s, $u)).AbsoluteUri
    }
    return $s
  }

  $p = $s
  if (-not [System.IO.Path]::IsPathRooted($p)) { $p = Join-Path $Root $p }
  if (-not (Test-Path $p)) { throw "Sumber update tidak ditemukan: $p" }
  if ((Get-Item $p).PSIsContainer) { $p = Join-Path $p 'update.json' }
  if ($p -match '\.json$') {
    Log "Membaca manifest: $p"
    $m = Get-Content -Path $p -Raw | ConvertFrom-Json
    $u = [string]$m.url
    if (-not $u) { throw 'Manifest tidak memuat "url".' }
    if ($u -match '^https?://') { return $u }
    if ([System.IO.Path]::IsPathRooted($u)) { return $u }
    return (Join-Path (Split-Path -Parent $p) $u)
  }
  return $p
}

$tmp = Join-Path $env:TEMP ('ckp-update-' + [guid]::NewGuid().ToString('N'))
$backup = $null
$zip = Join-Path $tmp 'update.zip'

try {
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null

  $zipSource = Resolve-ZipSource $Source
  Log "Mengambil paket update: $zipSource"
  if ($zipSource -match '^https?://') {
    Invoke-WebRequest -UseBasicParsing -Uri $zipSource -OutFile $zip -TimeoutSec 180
  } else {
    Copy-Item -Path $zipSource -Destination $zip -Force
  }

  if (-not (Test-Path $zip) -or (Get-Item $zip).Length -lt 1024) {
    throw 'Paket update kosong / gagal diunduh.'
  }

  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $arsip = [System.IO.Compression.ZipFile]::OpenRead($zip)
  try {
    $nama = @($arsip.Entries | ForEach-Object { ($_.FullName -replace '\\', '/').TrimStart('/') })
  } finally {
    $arsip.Dispose()
  }
  if (-not ($nama -contains 'src/server.js')) { throw 'Paket update tidak valid: src/server.js tidak ada.' }
  if (-not ($nama -contains 'versi.json')) { throw 'Paket update tidak valid: versi.json tidak ada.' }

  Stop-Ckp

  $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
  $backup = Join-Path $Root "data\backup-update-$stamp"
  New-Item -ItemType Directory -Force -Path $backup | Out-Null
  $daftarBackup = @(
    'src', 'web', 'public', 'scripts',
    'package.json', 'package-lock.json', 'versi.json',
    'Jalankan CKP.bat', 'Hentikan CKP.bat', 'Update CKP.bat', 'update-source.txt'
  )
  foreach ($item in $daftarBackup) {
    $p = Join-Path $Root $item
    if (Test-Path $p) { Copy-Item -Path $p -Destination $backup -Recurse -Force }
  }
  Log "Backup kode lama: $backup"

  $extract = Join-Path $tmp 'extract'
  Expand-Archive -Path $zip -DestinationPath $extract -Force

  # Jangan pernah menimpa data pengguna / dependency / tools.
  foreach ($terlarang in @('data', 'node_modules', 'tools', 'chrome-extension', '.git')) {
    $p = Join-Path $extract $terlarang
    if (Test-Path $p) { Remove-Item -Path $p -Recurse -Force }
  }

  Log 'Menyalin file baru...'
  robocopy $extract $Root /E /NFL /NDL /NJH /NJS /NP /XF *.log | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "robocopy gagal (kode $LASTEXITCODE)." }

  # npm install hanya bila dependency berubah.
  $fingerprintBaru = Get-DependencyFingerprint (Join-Path $extract 'package.json')
  $fingerprintLama = Get-DependencyFingerprint (Join-Path $backup 'package.json')
  $perluInstall = ($fingerprintBaru -ne $fingerprintLama)
  if ($perluInstall) {
    $npm = Get-Command npm -ErrorAction SilentlyContinue
    if ($npm) {
      Log 'Dependency berubah — menjalankan npm install...'
      & npm install --no-audit --no-fund
      if ($LASTEXITCODE -ne 0) { throw "npm install gagal (kode $LASTEXITCODE)." }
    } else {
      Log 'PERINGATAN: npm tidak ditemukan; dependency tidak diperbarui.'
    }
  }

  Log "Update selesai. Versi baru: $((Get-Content (Join-Path $Root 'versi.json') -Raw | ConvertFrom-Json).versi)"
  Start-Ckp
  Log 'Selesai.'
  exit 0
} catch {
  Log "GAGAL: $($_.Exception.Message)"
  if ($backup -and (Test-Path $backup)) {
    Log 'Mengembalikan kode versi lama...'
    robocopy $backup $Root /E /NFL /NDL /NJH /NJS /NP | Out-Null
  }
  Start-Ckp
  exit 1
} finally {
  Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
