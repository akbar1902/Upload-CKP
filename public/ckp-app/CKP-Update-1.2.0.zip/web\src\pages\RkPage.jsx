import { useMemo, useRef, useState } from 'react';
import {
  ArrowRight, Check, ClipboardList, FileSpreadsheet, ListChecks, Pencil, Plus,
  Search, Sparkles, Trash2, Upload, X,
} from 'lucide-react';
import { useApp } from '../store.jsx';
import { Button, Card, Empty, Field, inputCls, SectionHead, Segmented } from '../components/ui.jsx';

const MODE = [
  { value: 'append', label: 'Tambah ke daftar' },
  { value: 'replace', label: 'Ganti semua' },
];

export default function RkPage() {
  const { s, tambahRk, go, toast, imporRk, ubahRk, hapusRk } = useApp();
  const [q, setQ] = useState('');
  const [nama, setNama] = useState('');
  const [busy, setBusy] = useState(false);
  const [edit, setEdit] = useState(null);
  const [teks, setTeks] = useState('');
  const [mode, setMode] = useState('append');
  const [berkas, setBerkas] = useState(null);
  const berkasRef = useRef(null);

  const hasil = useMemo(() => {
    const k = q.trim().toLowerCase();
    return s.rk.filter((rk) => !k || rk.toLowerCase().includes(k));
  }, [s.rk, q]);

  const jumlahBaris = useMemo(() => teks.split(/\r?\n/).filter((x) => x.trim()).length, [teks]);

  const tambah = async (e) => {
    e?.preventDefault();
    const v = nama.trim();
    if (!v) return toast('Tulis nama RK baru dulu.', 'warn');
    setBusy(true);
    try {
      await tambahRk(v);
      setNama('');
      setQ('');
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const simpanEdit = async () => {
    if (!edit) return;
    setBusy(true);
    try {
      await ubahRk(edit.lama, edit.baru);
      setEdit(null);
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const buang = async (rk) => {
    if (!window.confirm(`Hapus RK ini dari daftar profil ${s.profile?.nama || 'aktif'}?\n\n“${rk}”`)) return;
    setBusy(true);
    try { await hapusRk(rk); } catch (err) { toast(err.message, 'err'); } finally { setBusy(false); }
  };

  const impor = async () => {
    if (!teks.trim() && !berkas) return toast('Tempel daftar RK atau pilih file dulu.', 'warn');
    setBusy(true);
    try {
      await imporRk({ text: teks, mode, file: berkas });
      setTeks('');
      setBerkas(null);
      if (berkasRef.current) berkasRef.current.value = '';
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <SectionHead
        eyebrow={`Data induk · ${s.profile?.nama || 'profil aktif'}`}
        title="Daftar Rencana Kinerja"
        desc="Daftar RK ini khusus untuk profil aktif. Rekan sekantor punya daftar RK-nya sendiri, jadi tidak saling menimpa. Tambah satu per satu atau impor sekaligus dari Excel/teks."
        right={<Button variant="secondary" icon={ArrowRight} onClick={() => go('draft')}>Buka Draft</Button>}
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_400px]">
        <Card className="overflow-hidden">
          <div className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-4">
            <div className="relative min-w-[200px] flex-1">
              <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
              <input className={`${inputCls} pl-10`} placeholder="Cari RK…" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <span className="tnum text-[12.5px] text-muted">{hasil.length} dari {s.rk.length} RK</span>
          </div>

          {s.rk.length === 0 ? (
            <Empty
              icon={ClipboardList}
              title="Daftar RK profil ini masih kosong"
              desc="Impor daftar RK dari file SKP/Excel di panel kanan, atau tambahkan satu per satu. RK tidak boleh dipinjam dari pegawai lain karena isinya berbeda."
            />
          ) : hasil.length === 0 ? (
            <p className="px-5 py-10 text-center text-[13px] text-muted">Tidak ada RK yang cocok dengan pencarian.</p>
          ) : (
            <ul className="scroll-thin max-h-[620px] divide-y divide-line overflow-y-auto">
              {hasil.map((rk) => {
                const no = s.rk.indexOf(rk) + 1;
                const sedangEdit = edit && edit.lama === rk;
                return (
                  <li key={rk} className="flex items-start gap-3 px-5 py-3.5">
                    <span className="tnum mt-0.5 grid size-6 shrink-0 place-items-center rounded-md bg-surface-3 text-[11px] font-bold text-muted">{no}</span>
                    {sedangEdit ? (
                      <div className="flex min-w-0 flex-1 flex-col gap-2">
                        <textarea
                          autoFocus
                          rows={2}
                          className={`${inputCls} min-h-[64px] resize-y leading-relaxed`}
                          value={edit.baru}
                          onChange={(e) => setEdit({ ...edit, baru: e.target.value })}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) simpanEdit();
                            if (e.key === 'Escape') setEdit(null);
                          }}
                        />
                        <div className="flex gap-2">
                          <Button size="sm" variant="primary" icon={Check} disabled={busy || !edit.baru.trim()} onClick={simpanEdit}>Simpan</Button>
                          <Button size="sm" variant="secondary" icon={X} onClick={() => setEdit(null)}>Batal</Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="min-w-0 flex-1 text-[13.5px] leading-snug font-medium text-ink">{rk}</p>
                        <div className="flex shrink-0 gap-1">
                          <button type="button" title="Ubah nama RK" aria-label="Ubah nama RK" disabled={busy} onClick={() => setEdit({ lama: rk, baru: rk })} className="grid size-7 place-items-center rounded-lg text-muted transition hover:bg-surface-2 hover:text-ink disabled:opacity-40"><Pencil className="size-3.5" /></button>
                          <button type="button" title="Hapus RK" aria-label="Hapus RK" disabled={busy} onClick={() => buang(rk)} className="grid size-7 place-items-center rounded-lg text-muted transition hover:bg-bad-soft hover:text-bad disabled:opacity-40"><Trash2 className="size-3.5" /></button>
                        </div>
                      </>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <div className="flex flex-col gap-5">
          <Card className="flex h-fit flex-col gap-4 p-5">
            <div>
              <h3 className="flex items-center gap-2 text-[14.5px] font-bold text-ink">
                <span className="grid size-7 place-items-center rounded-lg bg-accent-soft text-accent-text"><Upload className="size-4" /></span>
                Impor daftar RK
              </h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">
                Tempel satu RK per baris, atau pilih file <span className="font-mono text-[11.5px]">.xlsx/.csv/.txt</span> yang punya kolom “Rencana Kinerja”. Nomor di depan RK otomatis dibuang.
              </p>
            </div>
            <textarea
              rows={6}
              className={`${inputCls} min-h-[132px] resize-y font-mono text-[12px] leading-relaxed`}
              placeholder={'Terlaksananya Kegiatan Survei …\nTerlaksananya Penyusunan Publikasi …'}
              value={teks}
              onChange={(e) => setTeks(e.target.value)}
            />
            <div className="flex flex-wrap items-center gap-2">
              <input
                ref={berkasRef}
                type="file"
                accept=".xlsx,.xls,.csv,.txt"
                hidden
                onChange={(e) => setBerkas(e.target.files?.[0] || null)}
              />
              <Button size="sm" variant="secondary" icon={FileSpreadsheet} onClick={() => berkasRef.current?.click()}>
                {berkas ? 'Ganti file' : 'Pilih file'}
              </Button>
              {berkas && <span className="max-w-[180px] truncate font-mono text-[11.5px] text-muted">{berkas.name}</span>}
              <span className="tnum ml-auto text-[11.5px] text-faint">{jumlahBaris ? `${jumlahBaris} baris teks` : ''}</span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="text-[12px] font-semibold text-muted">Cara simpan</span>
              <Segmented name="mode-rk" value={mode} onChange={setMode} options={MODE} />
              <p className="text-[11.5px] text-faint">“Ganti semua” berguna saat RK tahun anggaran baru — daftar lama diganti, kata kunci yang tidak cocok ikut dibersihkan.</p>
            </div>
            <Button variant="primary" icon={Upload} disabled={busy || (!teks.trim() && !berkas)} onClick={impor} className="w-full">
              {busy ? 'Mengimpor…' : 'Impor sekarang'}
            </Button>
          </Card>

          <Card className="flex h-fit flex-col gap-4 p-5">
            <div>
              <h3 className="flex items-center gap-2 text-[14.5px] font-bold text-ink">
                <span className="grid size-7 place-items-center rounded-lg bg-accent-soft text-accent-text"><Plus className="size-4" /></span>
                Tambah satu RK
              </h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">
                Tulis nama RK persis seperti yang dipakai di SKP profil {s.profile?.nama || 'ini'}.
              </p>
            </div>
            <form onSubmit={tambah} className="flex flex-col gap-3">
              <Field label="Nama Rencana Kinerja">
                <textarea
                  rows={3}
                  className={`${inputCls} min-h-[92px] resize-y leading-relaxed`}
                  placeholder="cth: Terlaksananya Survei Industri Mikro dan Kecil Tahunan 2027"
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) tambah(e);
                  }}
                />
              </Field>
              <Button type="submit" variant="primary" icon={Plus} disabled={busy || !nama.trim()} className="w-full">
                {busy ? 'Menyimpan…' : 'Simpan RK baru'}
              </Button>
              <p className="text-[11.5px] leading-relaxed text-faint">Ctrl+Enter untuk menyimpan. Duplikat otomatis ditolak.</p>
            </form>
          </Card>

          <div className="rounded-xl bg-surface-2 p-3.5 text-[12px] leading-relaxed text-muted ring-1 ring-inset ring-line">
            <p className="mb-1 flex items-center gap-1.5 font-bold text-ink"><Sparkles className="size-3.5 text-accent-text" /> Tips untuk rekan baru</p>
            Buka <span className="font-semibold text-ink">Profil &amp; rekan</span> → tambah pegawai → impor RK miliknya di halaman ini. Setelah itu atur kata kunci agar draft otomatis menebak RK dengan tepat.
          </div>

          <div className="flex items-start gap-2 border-t border-line pt-4 text-[11.5px] leading-relaxed text-faint">
            <ListChecks className="mt-0.5 size-3.5 shrink-0" />
            <span>Daftar ini dipakai untuk rekomendasi otomatis, validasi export, dan kolom <span className="font-semibold">Rencana Kinerja</span> di Excel profil ini.</span>
          </div>
        </div>
      </div>
    </>
  );
}
