@echo off
setlocal
cd /d "%~dp0"
title Hentikan CKP App
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\stop-ckp.ps1" %*
echo.
pause
