import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowDown, ArrowUp, KeyRound, Pencil, Plus, Save, Search, Trash2 } from 'lucide-react';
import { useApp } from '../store.jsx';
import { Button, Card, Empty, inputCls, SectionHead, Segmented, TagInput } from '../components/ui.jsx';
import RkPicker from '../components/RkPicker.jsx';

const TAB = [
  { value: 'daftar', label: 'Daftar tersimpan' },
  { value: 'atur', label: 'Atur aturan' },
];

export default function KataKunciPage() {
  const { s, simpanKunci, tambahRk, toast } = useApp();
  const [tab, setTab] = useState('daftar');
  const [rows, setRows] = useState(s.kunci);
  const [simpan, setSimpan] = useState(false);
  const [fokus, setFokus] = useState('');
  const [pilihRk, setPilihRk] = useState(false);
  const [rkBaru, setRkBaru] = useState('');
  const [kunciBaru, setKunciBaru] = useState([]);

  useEffect(() => { setRows(s.kunci); }, [s.kunci]);

  const kotor = JSON.stringify(rows) !== JSON.stringify(s.kunci);
  const used = useMemo(() => new Set(rows.map((r) => r.rk)), [rows]);

  const ubahKunci = (i, kunci) => setRows((rs) => rs.map((r, k) => (k === i ? { ...r, kunci } : r)));
  const hapus = (i) => setRows((rs) => rs.filter((_, k) => k !== i));
  const geser = (i, d) => setRows((rs) => {
    const j = i + d;
    if (j < 0 || j >= rs.length) return rs;
    const copy = [...rs];
    [copy[i], copy[j]] = [copy[j], copy[i]];
    return copy;
  });

  const tambahAturan = () => {
    if (!rkBaru) return toast('Pilih RK dulu.', 'warn');
    if (!kunciBaru.length) return toast('Isi minimal satu kata kunci.', 'warn');
    setRows((rs) => {
      const ada = rs.find((r) => r.rk === rkBaru);
      if (ada) return rs.map((r) => (r.rk === rkBaru ? { ...r, kunci: [...new Set([...r.kunci, ...kunciBaru])] } : r));
      return [...rs, { rk: rkBaru, kunci: kunciBaru }];
    });
    setRkBaru('');
    setKunciBaru([]);
  };

  const doSimpan = async () => {
    setSimpan(true);
    try {
      await simpanKunci(rows.filter((r) => r.rk && r.kunci.length));
    } catch (e) {
      toast(e.message, 'err');
    } finally {
      setSimpan(false);
    }
  };

  const bukaUbah = (rk) => { setFokus(rk); setTab('atur'); };

  return (
    <>
      <SectionHead
        eyebrow="Data induk"
        title="Kata kunci RK"
        desc="Jika nama file memuat salah satu kata kunci, file itu langsung direkomendasikan ke RK terkait, menimpa tebakan otomatis. Aturan ini khusus profil aktif. Kata kunci dicocokkan sebagai kata utuh — “SE” cocok pada “SE 2026”/“SE2026”, tetapi tidak pada “Susenas”. Tidak perlu mengisi semua RK. Aturan yang paling atas dicek lebih dulu."
        right={
          tab === 'atur' && (
            <Button variant="primary" icon={Save} disabled={!kotor || simpan} onClick={doSimpan}>{kotor ? 'Simpan perubahan' : 'Tersimpan'}</Button>
          )
        }
      />

      <div className="mb-5 flex flex-wrap items-center gap-3">
        <Segmented name="kunci-tab" value={tab} onChange={setTab} options={TAB} />
        <span className="tnum text-[12.5px] text-muted">{rows.length} aturan · {rows.reduce((a, r) => a + r.kunci.length, 0)} kata kunci</span>
      </div>

      {tab === 'daftar' ? (
        <Daftar rows={s.kunci} onUbah={bukaUbah} />
      ) : (
        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
          <Card className="overflow-hidden">
            {rows.length === 0 ? (
              <Empty icon={KeyRound} title="Belum ada aturan" desc="Tambahkan RK dan kata kunci di panel kanan. Contoh: “pengaduan” untuk RK Tugas Harian Pelayanan Pengaduan." />
            ) : (
              <ul className="scroll-thin max-h-[640px] divide-y divide-line overflow-y-auto">
                <AnimatePresence initial={false}>
                  {rows.map((r, i) => (
                    <motion.li
                      key={r.rk} layout
                      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: -10 }}
                      className={`px-5 py-4 transition ${fokus === r.rk ? 'bg-accent-soft/60' : ''}`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="tnum mt-0.5 grid size-6 shrink-0 place-items-center rounded-md bg-surface-3 text-[11px] font-bold text-muted">{i + 1}</span>
                        <div className="min-w-0 flex-1">
                          <p className="text-[13.5px] leading-snug font-semibold text-ink">{r.rk}</p>
                          <div className="mt-2.5">
                            <TagInput value={r.kunci} onChange={(k) => ubahKunci(i, k)} placeholder="Ketik kata kunci, Enter untuk menambah" />
                          </div>
                        </div>
                        <div className="flex shrink-0 flex-col gap-1">
                          <IconBtn label="Naikkan prioritas" icon={ArrowUp} onClick={() => geser(i, -1)} disabled={i === 0} />
                          <IconBtn label="Turunkan prioritas" icon={ArrowDown} onClick={() => geser(i, 1)} disabled={i === rows.length - 1} />
                          <IconBtn label="Hapus aturan" icon={Trash2} onClick={() => hapus(i)} danger />
                        </div>
                      </div>
                    </motion.li>
                  ))}
                </AnimatePresence>
              </ul>
            )}
          </Card>

          <Card className="flex h-fit flex-col gap-4 p-5">
            <div>
              <h3 className="text-[14.5px] font-bold text-ink">Tambah aturan</h3>
              <p className="mt-1 text-[12.5px] text-muted">Pilih RK yang sudah punya aturan untuk menambah kata kunci ke aturan itu.</p>
            </div>
            <div className="flex flex-col gap-1.5">
              <span className="text-[12px] font-semibold text-muted">Rencana Kinerja</span>
              <button
                type="button"
                onClick={() => setPilihRk(true)}
                className={`${inputCls} flex items-center gap-2 text-left ${rkBaru ? '' : 'text-faint'}`}
              >
                <Pencil className="size-3.5 shrink-0 text-muted" />
                <span className="min-w-0 flex-1 truncate">{rkBaru || 'Klik untuk cari RK…'}</span>
              </button>
            </div>
            <div className="flex flex-col gap-1.5">
              <span className="text-[12px] font-semibold text-muted">Kata kunci</span>
              <TagInput value={kunciBaru} onChange={setKunciBaru} placeholder="cth: pengaduan, buku tamu" />
            </div>
            <Button variant="soft" icon={Plus} onClick={tambahAturan} className="w-full">Tambah ke daftar</Button>
            <p className="text-[11.5px] leading-relaxed text-faint">Perubahan belum tersimpan sebelum kamu menekan “Simpan perubahan”.</p>
          </Card>
        </div>
      )}

      <RkPicker
        open={pilihRk}
        onClose={() => setPilihRk(false)}
        onPick={setRkBaru}
        rkList={s.rk}
        terpilih={rkBaru}
        used={used}
        onAddRk={async (nama) => { const v = await tambahRk(nama); setRkBaru(v); return v; }}
        title="Pilih Rencana Kinerja"
        desc="RK yang sudah punya aturan ditandai. Menambah kata kunci ke RK itu akan menggabungkannya."
      />
    </>
  );
}

function Daftar({ rows, onUbah }) {
  const [q, setQ] = useState('');
  const hasil = useMemo(() => {
    const k = q.trim().toLowerCase();
    return rows.filter((r) => !k || r.rk.toLowerCase().includes(k) || r.kunci.some((x) => x.toLowerCase().includes(k)));
  }, [rows, q]);

  return (
    <Card className="overflow-hidden">
      <div className="flex items-center gap-3 border-b border-line px-5 py-4">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
          <input className={`${inputCls} pl-10`} placeholder="Cari RK atau kata kunci…" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <span className="tnum text-[12.5px] text-muted">{hasil.length} dari {rows.length}</span>
      </div>
      {rows.length === 0 ? (
        <Empty icon={KeyRound} title="Belum ada kata kunci tersimpan" desc="Buka tab “Atur aturan” untuk mulai memetakan kata kunci ke RK." action={null} />
      ) : hasil.length === 0 ? (
        <p className="px-5 py-10 text-center text-[13px] text-muted">Tidak ada yang cocok dengan pencarian.</p>
      ) : (
        <ul className="scroll-thin max-h-[620px] divide-y divide-line overflow-y-auto">
          {hasil.map((r) => (
            <li key={r.rk} className="flex items-start gap-4 px-5 py-4">
              <div className="min-w-0 flex-1">
                <p className="text-[13.5px] leading-snug font-semibold text-ink">{r.rk}</p>
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {r.kunci.map((k) => (
                    <span key={k} className="rounded-lg bg-accent-soft px-2.5 py-1 text-[12px] font-semibold text-accent-text ring-1 ring-inset ring-accent/20">{k}</span>
                  ))}
                </div>
              </div>
              <Button size="sm" variant="secondary" icon={Pencil} onClick={() => onUbah(r.rk)}>Ubah</Button>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function IconBtn({ icon: Icon, label, onClick, disabled, danger }) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      disabled={disabled}
      className={`grid size-8 place-items-center rounded-lg text-muted transition disabled:pointer-events-none disabled:opacity-30 ${danger ? 'hover:bg-bad-soft hover:text-bad' : 'hover:bg-surface-2 hover:text-ink'}`}
    >
      <Icon className="size-4" />
    </button>
  );
}
