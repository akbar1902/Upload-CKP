'use strict';

const path = require('path');
const fs = require('fs');
const AdmZip = require('adm-zip');
const ExcelJS = require('exceljs');
const {
  splitRkCell,
  parsePegawai,
  susunPegawai,
  ringkasDataset,
  rapikanTeks,
} = require('./rk-dataset');

function bacaCell(cell) {
  let v = cell && cell.value;
  if (v && typeof v === 'object') {
    if (v.text) v = v.text;
    else if (v.richText) v = v.richText.map((x) => x.text).join('');
    else if (v.result) v = v.result;
    else v = '';
  }
  return rapikanTeks(v);
}

async function bacaWorkbook(buffer, teamName) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(buffer);
  const ws = wb.worksheets.find((w) => /matriks/i.test(w.name)) || wb.worksheets[0];
  if (!ws) return { team: teamName, records: [] };

  let headerRow = 0;
  const headers = {};
  ws.eachRow({ includeEmpty: false }, (row, r) => {
    if (headerRow) return;
    const vals = {};
    row.eachCell({ includeEmpty: false }, (cell, c) => { vals[c] = bacaCell(cell); });
    const adaPegawai = Object.values(vals).some((v) => /pegawai/i.test(v));
    const adaRk = Object.values(vals).some((v) => /rencana kinerja/i.test(v));
    if (adaPegawai && adaRk) {
      headerRow = r;
      Object.assign(headers, vals);
    }
  });

  const kolomRk = Object.keys(headers)
    .filter((c) => /rencana kinerja/i.test(headers[c] || ''))
    .map(Number)
    .sort((a, b) => a - b);

  const records = [];
  ws.eachRow({ includeEmpty: false }, (row, r) => {
    if (r <= headerRow) return;
    const vals = {};
    row.eachCell({ includeEmpty: false }, (cell, c) => { vals[c] = bacaCell(cell); });
    const pegawai = parsePegawai(vals[1]);
    if (!pegawai.nip && !pegawai.nama) return;
    const rks = [];
    for (const c of kolomRk) rks.push(...splitRkCell(vals[c]));
    records.push({
      nip: pegawai.nip,
      nama: pegawai.nama,
      jabatan: vals[2] || '',
      status: vals[3] || '',
      team: teamName,
      rks,
    });
  });

  return { team: teamName, records };
}

async function bacaDataset(buffer, namaFile = 'Dataset RK') {
  const file = String(namaFile || '').toLowerCase();
  const files = [];
  if (file.endsWith('.zip')) {
    const zip = new AdmZip(buffer);
    for (const entry of zip.getEntries()) {
      if (entry.isDirectory) continue;
      const name = entry.entryName.replace(/\\/g, '/');
      if (name.startsWith('__MACOSX/') || !/\.xlsx$/i.test(name)) continue;
      const teamName = path.basename(name, path.extname(name));
      const hasil = await bacaWorkbook(entry.getData(), teamName);
      files.push(hasil);
    }
  } else {
    files.push(await bacaWorkbook(buffer, path.basename(namaFile, path.extname(namaFile))));
  }

  const records = files.flatMap((f) => f.records);
  const employees = susunPegawai(records);
  const teams = files.map((f) => {
    const ketua = f.records.filter((r) => /ketua/i.test(r.status)).map((r) => ({
      nip: r.nip,
      nama: r.nama,
    }));
    const rkSet = new Set(f.records.flatMap((r) => r.rks.map((x) => x.toLowerCase().replace(/[^a-z0-9]/g, ''))));
    return {
      team: f.team,
      ketua,
      jumlahPegawai: f.records.filter((r) => r.nip || r.nama).length,
      jumlahRk: rkSet.size,
    };
  }).sort((a, b) => a.team.localeCompare(b.team, 'id'));

  return {
    source: namaFile,
    generatedAt: new Date().toISOString(),
    teams,
    employees,
    ringkasan: ringkasDataset({ employees, teams }),
  };
}

async function bacaDatasetDariPath(filePath) {
  const buffer = fs.readFileSync(filePath);
  return bacaDataset(buffer, path.basename(filePath));
}

module.exports = { bacaDataset, bacaDatasetDariPath, bacaWorkbook };
