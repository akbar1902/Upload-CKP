@echo off
setlocal
cd /d "%~dp0"
title Pasang Autostart CKP App
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\pasang-autostart.ps1"
echo.
pause
