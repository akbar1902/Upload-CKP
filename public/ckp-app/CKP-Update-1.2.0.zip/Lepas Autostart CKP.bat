@echo off
setlocal
cd /d "%~dp0"
title Lepas Autostart CKP App
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\lepas-autostart.ps1"
echo.
pause
