# Pasang CKP App agar otomatis berjalan saat Windows login.
# Server tetap hidup di background tanpa jendela; buka http://localhost:3230 kapan saja.
$ErrorActionPreference = 'Stop'

$startup = [Environment]::GetFolderPath('Startup')
$ps1 = Join-Path $PSScriptRoot 'start-ckp.ps1'
if (-not (Test-Path $ps1)) {
  Write-Host "ERROR: start-ckp.ps1 tidak ditemukan." -ForegroundColor Red
  exit 1
}

$vbs = Join-Path $startup 'CKP App.vbs'
$isi = @(
  'Set sh = CreateObject("WScript.Shell")',
  ('sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File ""' + $ps1 + '"" -NoBrowser", 0, False')
) -join "`r`n"

Set-Content -Path $vbs -Value $isi -Encoding ASCII

Write-Host "Autostart CKP App sudah dipasang." -ForegroundColor Green
Write-Host "  File: $vbs"
Write-Host "  CKP App akan menyala sendiri setiap login Windows."
Write-Host "  Untuk melepas: jalankan 'Lepas Autostart CKP.bat'."
exit 0
