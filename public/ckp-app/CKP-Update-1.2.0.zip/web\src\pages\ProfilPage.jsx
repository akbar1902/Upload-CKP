import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check, ClipboardList, Copy, Database, Download, ExternalLink, FileJson, Link2, Pencil, Plus,
  RefreshCw, Search, Send, Share2, ShieldCheck, Trash2, Upload, UserRound, Users, X,
} from 'lucide-react';
import { useApp } from '../store.jsx';
import { api } from '../lib/api.js';
import { Button, Card, Field, inputCls, Modal, Pill, SectionHead } from '../components/ui.jsx';

const KOSONG = { nama: '', nip: '', jabatan: '', unitKerja: '', template: 'kosong', copyFrom: '' };

export default function ProfilPage() {
  const {
    s, go, toast, gantiProfil, buatProfil, ubahProfil, duplikatProfil,
    hapusProfil, imporProfil, segarkanProfil, simpanSikap, ujiSikap, tarikRkSikap,
    mulaiPairingSikap, cekPairingSikap, batalPairingSikap, lupakanSikap,
    muatDatasetRk, imporDatasetRk, imporDatasetRkFile,
  } = useApp();
  const [form, setForm] = useState({ ...KOSONG, unitKerja: (s.profile && s.profile.unitKerja) || '' });
  const [busy, setBusy] = useState(false);
  const [edit, setEdit] = useState(null);
  const [salin, setSalin] = useState(null);
  const [sikapForm, setSikapForm] = useState({ baseUrl: s.sikap.baseUrl || s.sikap.defaultBaseUrl || '', token: '' });
  const [sikapBusy, setSikapBusy] = useState(false);
  const [pairingError, setPairingError] = useState('');
  const [datasetOpen, setDatasetOpen] = useState(false);
  const [datasetQ, setDatasetQ] = useState('');
  const [datasetBusy, setDatasetBusy] = useState(false);
  const [qProfil, setQProfil] = useState('');
  const importRef = useRef(null);
  const datasetFileRef = useRef(null);
  const aktifId = s.profile && s.profile.id;

  useEffect(() => {
    if (!s.dataset.loaded) {
      muatDatasetRk().catch((e) => toast(e.message, 'err'));
    }
  }, [s.dataset.loaded, muatDatasetRk, toast]);

  const datasetFiltered = useMemo(() => {
    const k = datasetQ.trim().toLowerCase();
    return (s.dataset.employees || []).filter((e) => (
      !k || String(e.nama || '').toLowerCase().includes(k) || String(e.nip || '').includes(k) || String(e.jabatan || '').toLowerCase().includes(k)
    ));
  }, [s.dataset.employees, datasetQ]);

  const profilTampil = useMemo(() => {
    const k = qProfil.trim().toLowerCase();
    return (s.profiles || []).filter((p) => (
      !k || String(p.nama || '').toLowerCase().includes(k) || String(p.nip || '').includes(k)
    ));
  }, [s.profiles, qProfil]);

  const pindahSet = useMemo(
    () => new Set((s.dataset.pegawaiPindah || []).map(String)),
    [s.dataset.pegawaiPindah]
  );

  useEffect(() => {
    setSikapForm((f) => ({ ...f, baseUrl: s.sikap.baseUrl || f.baseUrl }));
  }, [s.sikap.baseUrl]);

  // Polling pairing: begitu disetujui di SIKAP, CKP App tersambung otomatis.
  useEffect(() => {
    if (!s.sikap.pairing?.active) return undefined;
    let stop = false;
    let timer = null;
    const tick = async () => {
      try {
        const j = await cekPairingSikap();
        if (stop) return;
        if (j.status === 'connected') {
          setPairingError('');
          toast(`Terhubung ke SIKAP sebagai ${j.sikap?.user?.full_name || 'akun Anda'}. ${j.sikap?.rkCount || 0} RK disiapkan.`);
          return;
        }
        if (j.status === 'pending') timer = setTimeout(tick, 2000);
      } catch (err) {
        if (stop) return;
        setPairingError(err.message);
        timer = setTimeout(tick, 4000);
      }
    };
    timer = setTimeout(tick, 1200);
    return () => { stop = true; if (timer) clearTimeout(timer); };
  }, [s.sikap.pairing?.active, cekPairingSikap, toast]);

  const ubahForm = (patch) => setForm((f) => ({ ...f, ...patch }));

  const simpanBaru = async (e) => {
    e.preventDefault();
    if (!form.nama.trim()) return toast('Isi nama pegawai dulu.', 'warn');
    setBusy(true);
    try {
      await buatProfil({
        ...form,
        copyFrom: form.template === 'salin' ? (form.copyFrom || aktifId) : '',
      });
      setForm({ ...KOSONG, unitKerja: form.unitKerja });
      go('rk');
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setBusy(false);
    }
  };

  const pakai = async (id) => {
    if (id === aktifId) return;
    setBusy(true);
    try { await gantiProfil(id); go('upload'); } catch (err) { toast(err.message, 'err'); } finally { setBusy(false); }
  };

  const unduh = async (profile) => {
    try {
      const j = await api(`/api/profiles/${encodeURIComponent(profile.id)}/bundle`);
      const isi = JSON.stringify(j.bundle, null, 2);
      const blob = new Blob([isi], { type: 'application/json' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = `ckp-profil-${(profile.nama || profile.id).replace(/[^\w-]+/g, '-')}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      toast(`Profil ${profile.nama} diekspor.`);
    } catch (err) { toast(err.message, 'err'); }
  };

  const imporBerkas = async (file) => {
    if (!file) return;
    setBusy(true);
    try {
      const teks = await file.text();
      const j = JSON.parse(teks);
      await imporProfil(j.bundle || j);
      go('rk');
    } catch (err) {
      toast('Gagal mengimpor profil: ' + err.message, 'err');
    } finally {
      setBusy(false);
      if (importRef.current) importRef.current.value = '';
    }
  };

  const hapus = async (profile) => {
    if (!window.confirm(`Hapus profil “${profile.nama}”?\n\nDaftar RK, kata kunci, kamus, dan riwayat ekspor profil ini ikut terhapus. File lama di luar folder profil tidak disentuh.`)) return;
    setBusy(true);
    try { await hapusProfil(profile.id); } catch (err) { toast(err.message, 'err'); } finally { setBusy(false); }
  };

  const imporSemuaDataset = async () => {
    const pindahCount = s.dataset.pegawaiPindah?.length || 0;
    const total = (s.dataset.ringkasan?.jumlahPegawai || s.dataset.employees.length || 0) - pindahCount;
    if (!total) return toast('Dataset RK belum termuat.', 'warn');
    if (!window.confirm(`Buat/perbarui profil untuk ${total} pegawai aktif dari dataset?\n\n${pindahCount} pegawai yang pindah satker otomatis dilewati.\nRK dari dataset akan DITAMBAHKAN ke RK lokal yang sudah ada (tidak menghapus). Kata kunci yang ada tetap dipertahankan.`)) return;
    setDatasetBusy(true);
    try {
      await imporDatasetRk({ mode: 'gabung' });
      setDatasetOpen(false);
      await segarkanProfil();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setDatasetBusy(false);
    }
  };

  const imporSatuDataset = async (emp) => {
    setDatasetBusy(true);
    try {
      await imporDatasetRk({ mode: 'gabung', nips: [emp.nip] });
      toast(`Profil ${emp.nama} siap; RK dataset digabungkan dengan RK lokal.`);
      setDatasetOpen(false);
      await segarkanProfil();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setDatasetBusy(false);
    }
  };

  const imporFileDataset = async (file) => {
    if (!file) return;
    if (!window.confirm('Impor dataset dari file ini? Profil yang cocok akan dibuat/diperbarui; RK dataset ditambahkan ke RK lokal yang sudah ada.')) return;
    setDatasetBusy(true);
    try {
      await imporDatasetRkFile(file, 'gabung');
      setDatasetOpen(false);
      await segarkanProfil();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setDatasetBusy(false);
      if (datasetFileRef.current) datasetFileRef.current.value = '';
    }
  };

  const hubungkanKlik = async (url = sikapForm.baseUrl) => {
    const alamat = String(url || '').trim();
    if (!alamat) return toast('Isi alamat SIKAP dulu.', 'warn');
    // Buka tab kosong SEKARANG (masih dalam gesture klik) supaya tidak diblokir
    // popup blocker setelah request jaringan selesai.
    const tab = window.open('', '_blank');
    setSikapBusy(true);
    setPairingError('');
    try {
      const j = await mulaiPairingSikap(alamat);
      if (j.pairUrl) {
        if (tab && !tab.closed) tab.location.href = j.pairUrl;
        else window.open(j.pairUrl, '_blank');
      }
      toast('Tab SIKAP dibuka. Klik “Setujui & hubungkan CKP App” di sana.');
    } catch (err) {
      try { tab?.close(); } catch (e) { /* abaikan */ }
      const pesan = err.status === 404
        ? 'Server CKP App masih versi lama. Tutup CKP App lalu jalankan “Jalankan CKP.bat” sekali lagi.'
        : err.message;
      setPairingError(pesan);
      toast(pesan, 'err');
    } finally {
      setSikapBusy(false);
    }
  };

  const hubungkanUlangKlik = async () => {
    if (!window.confirm('Ganti koneksi SIKAP? Token yang tersimpan di CKP App akan diganti setelah Anda menyetujui koneksi baru.')) return;
    await hubungkanKlik(s.sikap.baseUrl);
  };

  const batalPairingKlik = async () => {
    setSikapBusy(true);
    try { await batalPairingSikap(); setPairingError(''); } catch (err) { toast(err.message, 'err'); } finally { setSikapBusy(false); }
  };

  const lupakanKlik = async () => {
    if (!window.confirm('Lupakan koneksi SIKAP di CKP App ini? Token akan dihapus dari perangkat. Cabut juga token di SIKAP jika perlu.')) return;
    setSikapBusy(true);
    try { await lupakanSikap(); } catch (err) { toast(err.message, 'err'); } finally { setSikapBusy(false); }
  };

  const simpanSikapKlik = async (e) => {
    e?.preventDefault();
    if (!sikapForm.baseUrl.trim()) return toast('Isi alamat SIKAP dulu.', 'warn');
    if (!sikapForm.token.trim() && !s.sikap.hasToken) return toast('Tempel token integrasi dari SIKAP.', 'warn');
    setSikapBusy(true);
    try {
      await simpanSikap(sikapForm);
      setSikapForm((f) => ({ ...f, token: '' }));
      // Langsung uji + samakan RK agar token manual juga sekali klik.
      await ujiSikap();
      await tarikRkSikap('append');
      toast('SIKAP terhubung. Daftar RK sudah disamakan.');
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setSikapBusy(false);
    }
  };

  const ujiSikapKlik = async () => {
    setSikapBusy(true);
    try {
      await ujiSikap();
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setSikapBusy(false);
    }
  };

  const tarikRkKlik = async () => {
    if (!s.sikap.hasToken) return toast('Uji koneksi dulu sebelum menarik RK.', 'warn');
    if (!window.confirm('Tarik RK dari SIKAP dan gabungkan dengan daftar RK lokal? RK lokal yang sudah ada tidak dihapus.')) return;
    setSikapBusy(true);
    try {
      const j = await tarikRkSikap('append');
      toast(`${j.jumlah} RK tersedia. RK lokal tetap dipertahankan.`);
    } catch (err) {
      toast(err.message, 'err');
    } finally {
      setSikapBusy(false);
    }
  };

  return (
    <>
      <SectionHead
        eyebrow="Multi-pegawai"
        title="Profil pegawai"
        desc="Setiap pegawai punya daftar RK, kata kunci, kamus, header Excel, dan riwayat ekspor sendiri. Tambahkan rekan sekantor di sini — mereka bisa memakai aplikasi ini tanpa mengubah data Anda."
        right={<Button variant="secondary" icon={ClipboardList} onClick={() => go('rk')}>Atur RK profil aktif</Button>}
      />

      <Card className="mb-5 overflow-hidden">
        <div className="flex flex-col gap-4 p-5 lg:flex-row lg:items-center">
          <span className="grid size-11 shrink-0 place-items-center rounded-xl bg-accent-soft text-accent-text">
            <Database className="size-5" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-[14.5px] font-bold text-ink">Dataset RK kantor</h3>
              {s.dataset.ringkasan && (
                <span className="tnum rounded-full bg-surface-2 px-2.5 py-1 text-[11px] font-semibold text-muted ring-1 ring-inset ring-line">
                  {s.dataset.ringkasan.jumlahPegawai} pegawai · {s.dataset.ringkasan.jumlahTim} tim · {s.dataset.ringkasan.jumlahRkUnik} RK unik
                  {s.dataset.pegawaiPindah?.length ? ` · ${s.dataset.pegawaiPindah.length} pindah` : ''}
                </span>
              )}
            </div>
            <p className="mt-1 text-[12.5px] leading-relaxed text-muted">
              Satu pegawai = satu profil, berisi RK miliknya sendiri. Tim hanya info tambahan.
              Pegawai yang sudah pindah satker otomatis dilewati. RK dataset ditambahkan ke RK lokal yang sudah ada, jadi tambahan RK tahun ini tidak hilang.
            </p>
          </div>
          <div className="flex shrink-0 flex-wrap gap-2">
            <Button variant="primary" icon={Database} disabled={datasetBusy || !s.dataset.loaded} onClick={imporSemuaDataset}>
              {datasetBusy ? 'Mengimpor…' : 'Impor semua pegawai'}
            </Button>
            <Button variant="secondary" icon={Search} disabled={datasetBusy || !s.dataset.loaded} onClick={() => setDatasetOpen(true)}>
              Pilih pegawai
            </Button>
          </div>
        </div>
        <details className="border-t border-line px-5 py-3">
          <summary className="cursor-pointer text-[11.5px] font-semibold text-muted">Impor dataset dari file ZIP/Excel (opsional)</summary>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <input
              ref={datasetFileRef}
              type="file"
              accept=".zip,.xlsx"
              hidden
              onChange={(e) => imporFileDataset(e.target.files?.[0])}
            />
            <Button size="sm" variant="ghost" icon={Upload} disabled={datasetBusy} onClick={() => datasetFileRef.current?.click()}>
              Pilih file dataset
            </Button>
            <span className="text-[11.5px] text-faint">Format: ZIP berisi file .xlsx per tim, atau satu .xlsx.</span>
          </div>
        </details>
      </Card>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
        <div className="flex flex-col gap-5">
          <Card className="overflow-hidden">
            <div className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-4">
              <Users className="size-4.5 text-accent-text" />
              <div className="min-w-0 flex-1">
                <h3 className="text-[14.5px] font-bold text-ink">Daftar profil</h3>
                <p className="text-[12px] text-muted">{s.profiles.length} pegawai terdaftar di instalasi ini.</p>
              </div>
              <div className="relative w-full sm:w-56">
                <Search className="pointer-events-none absolute top-1/2 left-3 size-3.5 -translate-y-1/2 text-faint" />
                <input
                  className={`${inputCls} py-2 pl-8 text-[12px]`}
                  placeholder="Cari nama/NIP…"
                  value={qProfil}
                  onChange={(e) => setQProfil(e.target.value)}
                />
              </div>
              <Button size="sm" variant="ghost" onClick={async () => { await segarkanProfil(); toast('Daftar profil dimuat ulang.'); }}>Muat ulang</Button>
            </div>
            {profilTampil.length === 0 && (
              <p className="px-5 py-8 text-center text-[13px] text-muted">Tidak ada profil yang cocok.</p>
            )}
            <ul className="divide-y divide-line">
              {profilTampil.map((p) => {
                const aktif = p.id === aktifId;
                return (
                  <li key={p.id} className={`px-5 py-4 transition ${aktif ? 'bg-accent-soft/40' : ''}`}>
                    <div className="flex flex-wrap items-start gap-3">
                      <span className={`grid size-10 shrink-0 place-items-center rounded-xl text-[14px] font-extrabold ${aktif ? 'bg-accent-solid text-white' : 'bg-surface-3 text-muted'}`}>
                        {(p.nama || '?').trim()[0]?.toUpperCase() || <UserRound className="size-4" />}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="text-[14px] font-bold text-ink">{p.nama}</p>
                          {aktif && <Pill tone="ok"><Check className="size-3" /> Aktif</Pill>}
                          {p.legacyData && <Pill tone="wait">data lama</Pill>}
                        </div>
                        <p className="mt-0.5 text-[12px] text-muted">
                          {p.nip ? `NIP ${p.nip}` : 'NIP belum diisi'}
                          {p.jabatan ? ` · ${p.jabatan}` : ''}
                          {p.unitKerja ? ` · ${p.unitKerja}` : ''}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-1.5 text-[11px] font-semibold">
                          <span className="tnum rounded-md bg-surface-2 px-2 py-1 text-muted ring-1 ring-inset ring-line">{p.jumlahRk || 0} RK</span>
                          <span className="tnum rounded-md bg-surface-2 px-2 py-1 text-muted ring-1 ring-inset ring-line">{p.jumlahKunci || 0} aturan kunci</span>
                          <span className="tnum rounded-md bg-surface-2 px-2 py-1 text-muted ring-1 ring-inset ring-line">{p.jumlahEkspor || 0} ekspor</span>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {!aktif && <Button size="sm" variant="primary" icon={Check} disabled={busy} onClick={() => pakai(p.id)}>Pakai</Button>}
                        <Button size="sm" variant="secondary" icon={Pencil} onClick={() => setEdit({ ...p })}>Ubah</Button>
                        <Button size="sm" variant="ghost" icon={Copy} onClick={() => setSalin({ id: p.id, nama: `${p.nama} (salinan)` })}>Duplikat</Button>
                        <Button size="sm" variant="ghost" icon={Download} onClick={() => unduh(p)}>Ekspor</Button>
                        <Button size="sm" variant="ghost" icon={Trash2} disabled={busy || s.profiles.length <= 1} onClick={() => hapus(p)} aria-label={`Hapus ${p.nama}`} />
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>
          </Card>

          <Card className="p-5">
            <div className="flex items-start gap-3">
              <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-run-soft text-run"><Share2 className="size-4.5" /></span>
              <div className="min-w-0">
                <h3 className="text-[14.5px] font-bold text-ink">Dipakai bersama di kantor</h3>
                <p className="mt-1 text-[12.5px] leading-relaxed text-muted">
                  Satu komputer bisa menjadi server untuk rekan sekantor. Mereka membuka alamat di bawah, lalu memilih profilnya sendiri.
                  Aplikasi ini belum memakai login, jadi gunakan hanya di jaringan kantor yang tepercaya.
                </p>
                {s.network.urls.length > 0 ? (
                  <div className="mt-3 flex flex-col gap-2">
                    {s.network.urls.map((u) => (
                      <button
                        key={u}
                        type="button"
                        onClick={async () => {
                          try { await navigator.clipboard.writeText(u); toast('Alamat disalin: ' + u); }
                          catch (e) { toast('Salin manual: ' + u, 'warn'); }
                        }}
                        className="flex items-center justify-between gap-3 rounded-xl bg-surface-2 px-3.5 py-2.5 text-left ring-1 ring-inset ring-line transition hover:bg-surface-3"
                      >
                        <span className="font-mono text-[12.5px] text-ink">{u}</span>
                        <Copy className="size-3.5 shrink-0 text-muted" />
                      </button>
                    ))}
                  </div>
                ) : (
                  <p className="mt-3 rounded-xl bg-surface-2 px-3.5 py-2.5 font-mono text-[12px] text-muted ring-1 ring-inset ring-line">http://&lt;IP-komputer-ini&gt;:{s.network.port || 3230}</p>
                )}
                <p className="mt-3 text-[11.5px] leading-relaxed text-faint">
                  Setiap pegawai tetap memakai akun Google Drive/rclone di komputernya sendiri. Bila server dipakai bersama,
                  atur remote rclone per profil di tombol “Ubah”.
                </p>
              </div>
            </div>
          </Card>
        </div>

        <div className="flex flex-col gap-5">
          <Card className="flex h-fit flex-col gap-4 p-5">
            <div>
              <h3 className="flex items-center gap-2 text-[14.5px] font-bold text-ink">
                <span className="grid size-7 place-items-center rounded-lg bg-accent-soft text-accent-text"><Plus className="size-4" /></span>
                Tambah pegawai
              </h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-muted">
                Profil baru langsung aktif. Daftar RK-nya kosong secara default karena RK tiap pegawai berbeda — isi lewat impor di halaman Daftar RK.
              </p>
            </div>
            <form onSubmit={simpanBaru} className="flex flex-col gap-3">
              <Field label="Nama pegawai">
                <input className={inputCls} placeholder="cth: Siti Aminah, S.Stat." value={form.nama} onChange={(e) => ubahForm({ nama: e.target.value })} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="NIP"><input className={`${inputCls} tnum`} placeholder="cth: 19900101..." value={form.nip} onChange={(e) => ubahForm({ nip: e.target.value })} /></Field>
                <Field label="Jabatan"><input className={inputCls} placeholder="cth: Statistisi" value={form.jabatan} onChange={(e) => ubahForm({ jabatan: e.target.value })} /></Field>
              </div>
              <Field label="Unit kerja"><input className={inputCls} placeholder="cth: BPS Kabupaten Belitung" value={form.unitKerja} onChange={(e) => ubahForm({ unitKerja: e.target.value })} /></Field>
              <Field label="Isi awal data induk">
                <select className={inputCls} value={form.template} onChange={(e) => ubahForm({ template: e.target.value })}>
                  <option value="kosong">Kosong — RK diisi/impor sendiri (disarankan)</option>
                  <option value="salin">Salin RK, kata kunci &amp; kamus dari profil…</option>
                </select>
              </Field>
              {form.template === 'salin' && (
                <Field label="Salin dari">
                  <select className={inputCls} value={form.copyFrom || aktifId || ''} onChange={(e) => ubahForm({ copyFrom: e.target.value })}>
                    {s.profiles.map((p) => <option key={p.id} value={p.id}>{p.nama}</option>)}
                  </select>
                </Field>
              )}
              <Button type="submit" variant="primary" icon={Plus} disabled={busy || !form.nama.trim()} className="w-full">
                {busy ? 'Menyimpan…' : 'Buat profil & pakai'}
              </Button>
            </form>
          </Card>

          <Card className="flex flex-col gap-3 p-5">
            <h3 className="flex items-center gap-2 text-[14.5px] font-bold text-ink"><FileJson className="size-4 text-accent-text" /> Impor profil dari rekan</h3>
            <p className="text-[12.5px] leading-relaxed text-muted">
              Menerima file <span className="font-mono text-[11.5px]">ckp-profil-*.json</span> hasil tombol Ekspor. RK, kata kunci, kamus, dan header ikut masuk.
            </p>
            <input ref={importRef} type="file" accept=".json,application/json" hidden onChange={(e) => imporBerkas(e.target.files?.[0])} />
            <Button variant="soft" icon={Upload} disabled={busy} onClick={() => importRef.current?.click()} className="w-full">Pilih file profil</Button>
          </Card>

          <Card className="flex flex-col gap-3 p-5">
            <div className="flex items-start justify-between gap-2">
              <h3 className="flex items-center gap-2 text-[14.5px] font-bold text-ink">
                <Link2 className="size-4 text-accent-text" /> Integrasi SIKAP
              </h3>
              {s.sikap.configured ? (
                <span className="inline-flex items-center gap-1 rounded-full bg-ok-soft px-2 py-1 text-[10.5px] font-bold text-ok">
                  <ShieldCheck className="size-3" /> terhubung
                </span>
              ) : s.sikap.pairing?.active ? (
                <span className="rounded-full bg-amber-soft px-2 py-1 text-[10.5px] font-bold text-amber">menunggu</span>
              ) : (
                <span className="rounded-full bg-surface-3 px-2 py-1 text-[10.5px] font-bold text-muted">belum</span>
              )}
            </div>

            {s.sikap.configured && s.sikap.user ? (
              <>
                <div className="rounded-xl bg-ok-soft p-3.5 text-[12px] leading-relaxed text-muted">
                  <p className="font-semibold text-ink">
                    {s.sikap.user.full_name}{s.sikap.user.nip ? ` · NIP ${s.sikap.user.nip}` : ''}
                  </p>
                  <p className="mt-1">{s.rk.length} RK di profil{s.sikap.lastSyncAt ? ` · ${new Date(s.sikap.lastSyncAt).toLocaleString('id-ID')}` : ''}</p>
                  {s.sikap.lastUpload && (
                    <p className="mt-1">Upload terakhir: versi {s.sikap.lastUpload.version || '-'} · {s.sikap.lastUpload.status || '-'}</p>
                  )}
                </div>
                <Button variant="primary" icon={Send} onClick={() => go('export')} className="w-full">Buka Export &amp; kirim CKP</Button>
                <div className="flex flex-wrap gap-2">
                  <Button variant="secondary" icon={RefreshCw} disabled={sikapBusy} onClick={hubungkanUlangKlik}>Hubungkan ulang</Button>
                  <Button variant="ghost" icon={X} disabled={sikapBusy} onClick={lupakanKlik}>Lupakan</Button>
                </div>
                <p className="text-[11px] leading-relaxed text-faint">
                  RK otomatis disamakan dengan SIKAP setiap kali koneksi dibuat. Token tidak ikut diekspor saat profil dibagikan.
                </p>
              </>
            ) : s.sikap.pairing?.active ? (
              <>
                <p className="text-[12.5px] leading-relaxed text-muted">
                  Tab SIKAP sudah dibuka. Login jika diminta, lalu klik <span className="font-semibold text-ink">“Setujui &amp; hubungkan CKP App”</span>. Halaman ini tersambung otomatis.
                </p>
                <div className="rounded-xl bg-accent-soft p-4 text-center ring-1 ring-inset ring-accent/20">
                  <p className="text-[10px] font-bold tracking-[0.16em] text-accent-text uppercase">Kode pairing</p>
                  <p className="mt-1 font-mono text-[26px] font-extrabold tracking-[0.18em] text-ink">{s.sikap.pairing.code || '······'}</p>
                  {s.sikap.pairing.expiresAt && (
                    <p className="mt-1 text-[11px] text-muted">
                      Berlaku sampai {new Date(s.sikap.pairing.expiresAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  )}
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant="primary"
                    icon={ExternalLink}
                    disabled={sikapBusy || !s.sikap.pairing.pairUrl}
                    onClick={() => window.open(s.sikap.pairing.pairUrl, '_blank')}
                    className="flex-1"
                  >
                    Buka tab SIKAP
                  </Button>
                  <Button variant="secondary" onClick={batalPairingKlik} disabled={sikapBusy}>Batal</Button>
                </div>
                {pairingError && <p className="rounded-lg bg-bad-soft px-3 py-2 text-[11.5px] text-bad">{pairingError}</p>}
              </>
            ) : (
              <>
                <p className="text-[12.5px] leading-relaxed text-muted">
                  Satu klik: buka SIKAP, setujui, selesai. Tidak perlu salin token. Daftar RK langsung ikut tersinkron.
                </p>
                <Field label="Alamat SIKAP">
                  <input
                    className={inputCls}
                    placeholder="https://sikap.bps.go.id atau http://localhost:3000"
                    value={sikapForm.baseUrl}
                    onChange={(e) => setSikapForm((f) => ({ ...f, baseUrl: e.target.value }))}
                  />
                </Field>
                <Button
                  variant="primary"
                  icon={Link2}
                  disabled={sikapBusy || !sikapForm.baseUrl.trim()}
                  onClick={() => hubungkanKlik()}
                  className="w-full"
                >
                  {sikapBusy ? 'Membuka SIKAP…' : 'Hubungkan SIKAP'}
                </Button>
                {pairingError && <p className="rounded-lg bg-bad-soft px-3 py-2 text-[11.5px] text-bad">{pairingError}</p>}
                <p className="text-[11px] leading-relaxed text-faint">Alamat cukup diisi sekali. Setelah terhubung, tombol Kirim ke SIKAP muncul di halaman Export.</p>
              </>
            )}

            <details className="mt-1 border-t border-line pt-3">
              <summary className="cursor-pointer text-[11.5px] font-semibold text-muted">Opsi lanjutan: token manual</summary>
              <form onSubmit={simpanSikapKlik} className="mt-3 flex flex-col gap-3">
                <Field label="Token integrasi">
                  <input
                    type="password"
                    className={inputCls}
                    placeholder={s.sikap.hasToken ? 'Token tersimpan — kosongkan jika tidak diubah' : 'Tempel token ckp_…'}
                    value={sikapForm.token}
                    onChange={(e) => setSikapForm((f) => ({ ...f, token: e.target.value }))}
                    autoComplete="off"
                  />
                </Field>
                <div className="flex flex-wrap gap-2">
                  <Button type="submit" variant="secondary" icon={Check} disabled={sikapBusy} className="flex-1">Simpan token</Button>
                  <Button type="button" variant="ghost" icon={RefreshCw} disabled={sikapBusy} onClick={ujiSikapKlik}>Uji</Button>
                </div>
              </form>
              <Button variant="ghost" icon={Download} disabled={sikapBusy || !s.sikap.hasToken} onClick={tarikRkKlik} className="mt-2 w-full">
                Tarik &amp; gabungkan RK dari SIKAP
              </Button>
            </details>
          </Card>
        </div>
      </div>

      <Modal open={datasetOpen} onClose={() => setDatasetOpen(false)} title="Pilih pegawai dari dataset" desc="Profil dibuat/diperbarui dengan RK milik pegawai tersebut. Tim hanya info tambahan." width="max-w-2xl">
        <div className="relative mb-4">
          <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
          <input
            autoFocus
            className={`${inputCls} pl-10`}
            placeholder="Cari nama, NIP, atau jabatan…"
            value={datasetQ}
            onChange={(e) => setDatasetQ(e.target.value)}
          />
        </div>
        <div className="scroll-thin max-h-[52vh] divide-y divide-line overflow-y-auto rounded-xl border border-line">
          {datasetFiltered.length === 0 ? (
            <p className="px-4 py-10 text-center text-[13px] text-muted">
              {s.dataset.loaded ? 'Tidak ada pegawai yang cocok.' : 'Memuat dataset…'}
            </p>
          ) : datasetFiltered.map((emp) => {
            const ada = s.profiles.some((p) => p.nip === emp.nip);
            const pindah = pindahSet.has(String(emp.nip));
            return (
              <div key={emp.nip || emp.nama} className="flex flex-wrap items-center gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-[13.5px] font-bold text-ink">{emp.nama}</p>
                    {pindah && <Pill tone="wait">pindah satker</Pill>}
                  </div>
                  <p className="mt-0.5 text-[11.5px] text-muted">
                    {emp.nip ? `NIP ${emp.nip}` : 'NIP belum ada'}
                    {emp.jabatan ? ` · ${emp.jabatan}` : ''}
                    {` · ${emp.rks?.length || 0} RK`}
                    {emp.teams?.length ? ` · ${emp.teams.length} tim` : ''}
                  </p>
                </div>
                <Button size="sm" variant={ada ? 'secondary' : 'primary'} icon={pindah ? X : (ada ? RefreshCw : Plus)} disabled={datasetBusy || pindah} onClick={() => imporSatuDataset(emp)}>
                  {pindah ? 'Dilewati' : ada ? 'Perbarui' : 'Buat profil'}
                </Button>
              </div>
            );
          })}
        </div>
        <p className="mt-3 text-[11.5px] leading-relaxed text-faint">
          {datasetFiltered.length} dari {s.dataset.employees.length} pegawai. RK dataset ditambahkan ke RK lokal; kata kunci lama dipertahankan. Pegawai pindah satker dilewati.
        </p>
      </Modal>

      <Modal open={!!edit} onClose={() => setEdit(null)} title="Ubah profil" desc="Nama, NIP, dan unit kerja dipakai untuk identitas serta header Excel profil ini.">
        {edit && (
          <div className="flex flex-col gap-3.5">
            <Field label="Nama pegawai"><input className={inputCls} value={edit.nama} onChange={(e) => setEdit({ ...edit, nama: e.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="NIP"><input className={`${inputCls} tnum`} value={edit.nip || ''} onChange={(e) => setEdit({ ...edit, nip: e.target.value })} /></Field>
              <Field label="Jabatan"><input className={inputCls} value={edit.jabatan || ''} onChange={(e) => setEdit({ ...edit, jabatan: e.target.value })} /></Field>
            </div>
            <Field label="Unit kerja"><input className={inputCls} value={edit.unitKerja || ''} onChange={(e) => setEdit({ ...edit, unitKerja: e.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Remote rclone">
                <select className={inputCls} value={edit.remote || ''} onChange={(e) => setEdit({ ...edit, remote: e.target.value })}>
                  <option value="">Ikuti default</option>
                  {(s.rclone.remotes || []).map((r) => <option key={r} value={r}>{r}</option>)}
                </select>
              </Field>
              <Field label="Folder Drive default"><input className={inputCls} placeholder="cth: CKP 2026/Nama" value={edit.driveFolder || ''} onChange={(e) => setEdit({ ...edit, driveFolder: e.target.value })} /></Field>
            </div>
            <p className="text-[11.5px] leading-relaxed text-faint">Remote rclone dipakai bila beberapa pegawai berbagi satu server tetapi akun Drive-nya berbeda.</p>
          </div>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setEdit(null)}>Batal</Button>
          <Button
            variant="primary"
            disabled={busy || !edit || !String(edit.nama || '').trim()}
            onClick={async () => {
              setBusy(true);
              try { await ubahProfil(edit.id, edit); setEdit(null); } catch (e) { toast(e.message, 'err'); } finally { setBusy(false); }
            }}
          >Simpan</Button>
        </div>
      </Modal>

      <Modal open={!!salin} onClose={() => setSalin(null)} title="Duplikat profil" desc="Semua RK, kata kunci, dan kamus disalin. Riwayat upload/ekspor tidak ikut disalin.">
        {salin && (
          <Field label="Nama profil salinan">
            <input className={inputCls} value={salin.nama} onChange={(e) => setSalin({ ...salin, nama: e.target.value })} />
          </Field>
        )}
        <div className="mt-5 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setSalin(null)}>Batal</Button>
          <Button
            variant="primary"
            icon={Copy}
            disabled={busy || !salin || !String(salin.nama || '').trim()}
            onClick={async () => {
              setBusy(true);
              try { await duplikatProfil(salin.id, salin.nama); setSalin(null); } catch (e) { toast(e.message, 'err'); } finally { setBusy(false); }
            }}
          >Duplikat</Button>
        </div>
      </Modal>
    </>
  );
}
