# ============================================================================
#  Launcher CKP App
#
#  Menjalankan server Node sebagai proses yang benar-benar terpisah dari
#  terminal pemanggil. Jadi CKP App tetap hidup walaupun jendela cmd, VS Code,
#  atau OpenCode ditutup.
#
#  Pemakaian:
#    start-ckp.ps1              -> jalankan (atau pakai yang sudah jalan) + buka browser
#    start-ckp.ps1 -Restart     -> hentikan server lama lalu jalankan ulang
#    start-ckp.ps1 -NoBrowser   -> jalankan tanpa membuka browser (untuk autostart)
# ============================================================================
[CmdletBinding()]
param(
  [switch]$Restart,
  [switch]$NoBrowser,
  [int]$Port = 0
)

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

if (-not $Port -or $Port -le 0) {
  $Port = if ($env:PORT) { [int]$env:PORT } else { 3230 }
}

$healthUrl = "http://127.0.0.1:$Port/api/health"
$logDir = Join-Path $root 'data\logs'
$logFile = Join-Path $logDir 'server.log'

function Test-Ckp {
  try {
    $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 -Uri $healthUrl
    return ($r.StatusCode -eq 200 -and $r.Content -match '"app"\s*:\s*"ckp"')
  } catch {
    return $false
  }
}

function Get-PortOwner {
  try {
    $conn = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop | Select-Object -First 1
    if ($conn) { return [int]$conn.OwningProcess }
  } catch { }
  try {
    $line = (netstat -ano | Select-String -Pattern ":$Port\s+.*LISTENING" | Select-Object -First 1).Line
    if ($line) { return [int](($line -split '\s+')[-1]) }
  } catch { }
  return 0
}

function Join-JikaAda($base, $child) {
  if ([string]::IsNullOrWhiteSpace($base)) { return $null }
  return (Join-Path $base $child)
}

function Open-Ckp {
  if ($NoBrowser) { return }
  $url = "http://localhost:$Port"
  $kandidat = @(
    (Join-JikaAda $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-JikaAda ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-JikaAda $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
    (Join-JikaAda $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
    (Join-JikaAda ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe')
  ) | Where-Object { $_ -and (Test-Path $_) }
  $browser = $kandidat | Select-Object -First 1
  if ($browser) {
    Start-Process -FilePath $browser -ArgumentList "--app=$url", '--window-size=1320,900'
  } else {
    Start-Process $url
  }
}

if ($Restart) {
  $pidLama = Get-PortOwner
  if ($pidLama -gt 0) {
    Write-Host "Menghentikan CKP App lama (PID $pidLama)..."
    Stop-Process -Id $pidLama -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 800
  }
}

if (Test-Ckp) {
  Write-Host "CKP App sudah berjalan di http://localhost:$Port"
  Open-Ckp
  exit 0
}

$pemilik = Get-PortOwner
if ($pemilik -gt 0) {
  $namaProses = (Get-Process -Id $pemilik -ErrorAction SilentlyContinue).ProcessName
  if ($namaProses -eq 'node') {
    # Server lama ada tapi tidak merespons (mungkin hang). Jalankan ulang
    # otomatis supaya pengguna tidak terjebak "localhost tidak bisa dibuka".
    Write-Host "CKP App lama tidak merespons - menjalankan ulang (PID $pemilik)..."
    Stop-Process -Id $pemilik -Force -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 900
  } else {
    Write-Host "Port $Port sedang dipakai aplikasi lain ($namaProses, PID $pemilik)." -ForegroundColor Yellow
    Write-Host "Tutup aplikasi itu, atau jalankan: Jalankan CKP.bat -Restart"
    exit 1
  }
}

$nodeCmd = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeCmd) {
  Write-Host "ERROR: Node.js tidak ditemukan. Install dari https://nodejs.org/" -ForegroundColor Red
  exit 1
}
$nodeExe = $nodeCmd.Source

if (-not (Test-Path (Join-Path $root 'node_modules'))) {
  Write-Host "Dependency belum ada. Menjalankan npm install (sekali saja)..."
  & npm install
  if (-not (Test-Path (Join-Path $root 'node_modules'))) {
    Write-Host "ERROR: npm install gagal. Periksa koneksi internet lalu coba lagi." -ForegroundColor Red
    exit 1
  }
}

New-Item -ItemType Directory -Force -Path $logDir | Out-Null
if ((Test-Path $logFile) -and ((Get-Item $logFile).Length -gt 5MB)) {
  Move-Item -Path $logFile -Destination ($logFile + '.old') -Force
}

Write-Host "Menjalankan CKP App Engine..."
$dijalankan = $false
try {
  # WMI membuat proses di luar job object/console pemanggil, sehingga tidak
  # ikut mati saat OpenCode atau terminal ditutup.
  $cmdLine = 'cmd.exe /d /s /c ""' + $nodeExe + '" src\server.js >> "' + $logFile + '" 2>&1"'
  $hasil = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
    CommandLine      = $cmdLine
    CurrentDirectory = $root
  }
  $dijalankan = ($hasil -and $hasil.ReturnValue -eq 0)
} catch {
  $dijalankan = $false
}
if (-not $dijalankan) {
  # Cadangan bila WMI diblokir kebijakan sistem.
  Start-Process -FilePath $nodeExe -ArgumentList 'src/server.js' -WorkingDirectory $root -WindowStyle Hidden
}

Write-Host "Menunggu CKP App siap..."
$siap = $false
for ($i = 0; $i -lt 150; $i++) {
  if (Test-Ckp) { $siap = $true; break }
  Start-Sleep -Milliseconds 400
}

if (-not $siap) {
  Write-Host ""
  Write-Host "GAGAL: server tidak merespons di http://localhost:$Port setelah 60 detik." -ForegroundColor Red
  if (Test-Path $logFile) {
    Write-Host ""
    Write-Host "--- 20 baris terakhir data\logs\server.log ---"
    Get-Content $logFile -Tail 20
  }
  exit 1
}

Write-Host "CKP App siap di http://localhost:$Port"
Open-Ckp
exit 0
