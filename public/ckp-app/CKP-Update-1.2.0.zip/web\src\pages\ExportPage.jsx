import { useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Download, ExternalLink, FileSpreadsheet, FolderOpen, History, Link2, Lock, Send, TriangleAlert } from 'lucide-react';
import { useApp } from '../store.jsx';
import { api, kirimJson, urlProfil } from '../lib/api.js';
import { fmtBytes, fmtTanggal } from '../lib/format.js';
import { payloadKipapp } from '../lib/draft.js';
import { turunkan } from '../lib/derive.js';
import { Button, Card, Empty, Pill, SectionHead } from '../components/ui.jsx';

// Kirim ke KipApp lewat bridge extension (window.postMessage). Kontrak tidak boleh berubah.
function kirimKeBridge(payload) {
  return new Promise((resolve) => {
    const handler = (e) => {
      const m = e.data;
      if (e.source !== window || !m || m.source !== 'CKP_COMPANION' || m.type !== 'CKP_HANDOFF_ACK') return;
      window.removeEventListener('message', handler);
      resolve(m);
    };
    window.addEventListener('message', handler);
    window.postMessage(payload, '*');
    setTimeout(() => { window.removeEventListener('message', handler); resolve(null); }, 3000);
  });
}

function unduhJson(payload) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'ckp-kipapp.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

export default function ExportPage() {
  const { s, toast, exportExcel, muatRiwayat, kirimSikap, go } = useApp();
  const d = turunkan(s);
  const [hint, setHint] = useState('Butuh Chrome (bukan Edge) dengan extension CKP Companion terpasang di browser yang sama.');
  const [kirim, setKirim] = useState(false);
  const [sikapBusy, setSikapBusy] = useState(false);
  const [sikapHasil, setSikapHasil] = useState(null);
  const [sikapError, setSikapError] = useState('');
  const bisa = d.canExport && !s.exp.busy;
  const sikapSiap = s.sikap.configured && (s.sikap.rkCount > 0 || s.sikap.subRkCount > 0);

  const kirimKeSikap = async () => {
    if (!s.sikap.configured) return go('profil');
    if (!bisa) return;
    setSikapBusy(true);
    setSikapError('');
    setSikapHasil(null);
    try {
      const j = await kirimSikap();
      setSikapHasil(j);
      toast(`CKP tersimpan di SIKAP${j.version ? ` (versi ${j.version})` : ''}.`);
    } catch (err) {
      const daftar = err?.payload && Array.isArray(err.payload.unmatchedRks) ? err.payload.unmatchedRks : [];
      setSikapError(daftar.length
        ? `${err.message}\n${daftar.map((x) => `• ${x}`).join('\n')}`
        : err.message);
      toast('Gagal mengirim ke SIKAP.', 'err');
    } finally {
      setSikapBusy(false);
    }
  };

  const kirimKipapp = async () => {
    if (!s.draft.length) return toast('Belum ada draft.', 'warn');
    const payload = payloadKipapp(s.draft, s.header, s.profile);
    const kurang = payload.rows.filter((r) => r.warnings.length).length;
    if (kurang) return toast(`${kurang} baris belum lengkap — bereskan dulu di Draft.`, 'err');
    setKirim(true);
    const res = await kirimKeBridge(payload);
    setKirim(false);
    if (res && res.ok) {
      setHint(`${res.saved} baris diterima extension — buka sidepanel lalu “Isi & simpan”.`);
      toast(`${res.saved} baris terkirim ke extension.`);
      return;
    }
    const alasan = res ? 'Extension menolak payload' : 'Extension tidak terdeteksi';
    setHint(res
      ? 'Extension menolak: ' + (res.error || 'unknown')
      : 'Buka CKP App di Chrome yang sudah memasang CKP Companion. Jika memakai Edge, pasang extension di Edge juga — lalu reload halaman.');
    try {
      await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
      toast(`${alasan} — JSON disalin, tempel ke extension.`, 'warn');
    } catch (e) {
      unduhJson(payload);
      toast(`${alasan} — JSON diunduh (ckp-kipapp.json).`, 'warn');
    }
  };

  const hasil = s.exp.result;

  return (
    <>
      <SectionHead
        eyebrow="Tahap 4 dari 4"
        title={<>Stempel <span className="text-accent-text">lolos</span>.</>}
        desc="File Excel siap dipakai SIKAP atau Auto-Input. Progres selalu 100 dan capaian berbunyi “Telah + kegiatan”."
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <div className="flex flex-col gap-5">
          <Card className="flex flex-col gap-5 p-6">
            <div className="flex items-start gap-4">
              <div className={`grid size-12 shrink-0 place-items-center rounded-xl ${bisa ? 'bg-accent-soft text-accent-text' : 'bg-surface-3 text-faint'}`}>
                {bisa ? <FileSpreadsheet className="size-6" strokeWidth={1.8} /> : <Lock className="size-5" />}
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-[15px] font-bold text-ink">Export Excel CKP</h3>
                <p className="mt-1 text-[13px] leading-relaxed text-muted">
                  {!s.draft.length
                    ? 'Belum ada draft. Susun dulu dari tahap Drive atau buka file hasil lama.'
                    : bisa
                      ? `${s.draft.length} baris siap diekspor ke sheet “${s.header.sheetName || 'CKP'}”.`
                      : `Lengkapi ${d.perluCek} baris di tahap Draft dulu. Export dikunci agar tidak ditolak SIKAP.`}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3 border-t border-line pt-5">
              <Button variant="primary" size="lg" icon={FileSpreadsheet} disabled={!bisa} onClick={exportExcel}>
                {s.exp.busy ? 'Menyusun Excel…' : 'Export Excel CKP'}
              </Button>
              {!bisa && s.draft.length > 0 && <Pill tone="warn">Terkunci · {d.perluCek} belum lengkap</Pill>}
            </div>
            {s.exp.error && (
              <div className="flex items-start gap-2.5 rounded-xl bg-bad-soft p-3.5 text-[13px] text-bad">
                <TriangleAlert className="mt-0.5 size-4 shrink-0" />
                <span className="whitespace-pre-line">{s.exp.error}</span>
              </div>
            )}
            {hasil && (
              <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col gap-3 rounded-xl bg-ok-soft p-4">
                <div className="flex items-center gap-2 text-[14px] font-bold text-ink">
                  <CheckCircle2 className="size-4.5 text-ok" /> Jadi! {hasil.jumlah} baris tersimpan.
                </div>
                <p className="font-mono text-[11.5px] break-all text-muted">{hasil.path}</p>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="primary" icon={Download} onClick={() => window.open(urlProfil('/api/download?path=' + encodeURIComponent(hasil.path)), '_blank')}>Unduh Excel</Button>
                  <Button size="sm" variant="secondary" icon={FolderOpen} onClick={() => bukaFolder(hasil.path, toast)}>Tampilkan di Explorer</Button>
                </div>
              </motion.div>
            )}
          </Card>

          <Card className="flex flex-col gap-4 p-6">
            <div className="flex items-start gap-3">
              <span className={`grid size-10 shrink-0 place-items-center rounded-xl ${s.sikap.configured ? 'bg-accent-soft text-accent-text' : 'bg-surface-3 text-faint'}`}>
                <Link2 className="size-5" />
              </span>
              <div className="min-w-0 flex-1">
                <h3 className="text-[15px] font-bold text-ink">Kirim ke SIKAP</h3>
                <p className="mt-1 text-[13px] leading-relaxed text-muted">
                  {sikapSiap
                    ? `Excel dibuat otomatis lalu diunggah ke SIKAP sebagai ${s.sikap.user?.full_name || 'akun Anda'}. Tidak perlu download-upload manual.`
                    : s.sikap.configured
                      ? 'Token tersimpan, tetapi daftar RK SIKAP belum ditarik. Buka Profil & rekan → Tarik RK dari SIKAP.'
                      : 'Hubungkan profil ini ke SIKAP dulu. Token dibuat di SIKAP → menu Integrasi CKP App.'}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              {sikapSiap ? (
                <Button variant="primary" size="lg" icon={Link2} disabled={!bisa || sikapBusy} onClick={kirimKeSikap}>
                  {sikapBusy ? 'Mengirim ke SIKAP…' : 'Kirim ke SIKAP'}
                </Button>
              ) : (
                <Button variant="soft" size="lg" icon={Link2} onClick={() => go('profil')}>
                  {s.sikap.configured ? 'Tarik RK dari SIKAP' : 'Atur integrasi SIKAP'}
                </Button>
              )}
              {s.sikap.configured && (
                <span className="text-[12px] text-faint">{s.rk.length} RK profil · {s.sikap.baseUrl}</span>
              )}
            </div>
            {sikapError && (
              <div className="flex items-start gap-2.5 rounded-xl bg-bad-soft p-3.5 text-[13px] text-bad">
                <TriangleAlert className="mt-0.5 size-4 shrink-0" />
                <span className="whitespace-pre-line">{sikapError}</span>
              </div>
            )}
            {sikapHasil && (
              <div className="flex flex-col gap-2 rounded-xl bg-ok-soft p-3.5">
                <p className="flex items-center gap-2 text-[13.5px] font-bold text-ink">
                  <CheckCircle2 className="size-4 text-ok" />
                  Tersimpan di SIKAP{sikapHasil.version ? ` · versi ${sikapHasil.version}` : ''}
                  {sikapHasil.duplicate ? ' (sudah pernah dikirim)' : ''}
                </p>
                {sikapHasil.url && (
                  <a href={sikapHasil.url} target="_blank" rel="noreferrer" className="inline-flex w-fit items-center gap-1.5 text-[12.5px] font-semibold text-accent-text hover:underline">
                    Buka CKP di SIKAP <ExternalLink className="size-3.5" />
                  </a>
                )}
              </div>
            )}
          </Card>

          <Card className="flex flex-col gap-4 p-6">
            <div>
              <h3 className="text-[15px] font-bold text-ink">Kirim ke KipApp</h3>
              <p className="mt-1 text-[13px] leading-relaxed text-muted">Isi form KipApp otomatis lewat extension CKP Companion, tanpa salin-tempel per baris.</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <Button variant="soft" size="lg" icon={Send} disabled={!bisa || kirim} onClick={kirimKipapp}>
                {kirim ? 'Mengirim…' : 'Kirim ke KipApp'}
              </Button>
            </div>
            <p className="text-[12.5px] text-faint">{hint}</p>
          </Card>
        </div>

        <Card className="flex flex-col">
          <div className="flex items-center gap-3 border-b border-line px-5 py-4">
            <History className="size-4.5 text-accent-text" />
            <div className="min-w-0 flex-1">
              <h3 className="text-[14.5px] font-bold text-ink">Riwayat file</h3>
              <p className="text-[12px] text-muted">50 file terakhir — hasil CKP &amp; laporan link Drive.</p>
            </div>
            <Button size="sm" variant="ghost" onClick={muatRiwayat}>Muat ulang</Button>
          </div>
          <div className="scroll-thin max-h-[560px] overflow-y-auto">
            {s.history.length === 0 ? (
              <Empty icon={History} title="Belum ada riwayat" desc="File hasil export dan laporan upload akan muncul di sini." />
            ) : (
              <ul className="divide-y divide-line">
                {s.history.map((f) => (
                  <li key={f.path} className="flex items-center gap-3 px-5 py-3.5">
                    <span className={`grid size-9 shrink-0 place-items-center rounded-lg ${f.jenis === 'Hasil Link' ? 'bg-run-soft text-run' : 'bg-accent-soft text-accent-text'}`}>
                      <FileSpreadsheet className="size-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-mono text-[12.5px] text-ink">{f.nama}</p>
                      <p className="truncate text-[11.5px] text-muted">{f.jenis} · {fmtBytes(f.ukuran)} · {fmtTanggal(f.diubah)}</p>
                    </div>
                    <div className="flex shrink-0 gap-1.5">
                      <Button size="sm" variant="ghost" icon={Download} onClick={() => window.open(urlProfil('/api/download?path=' + encodeURIComponent(f.path)), '_blank')} aria-label="Unduh" />
                      <Button size="sm" variant="ghost" icon={FolderOpen} onClick={() => bukaFolder(f.path, toast)} aria-label="Buka folder" />
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </Card>
      </div>
    </>
  );
}

async function bukaFolder(path, toast) {
  try {
    await api('/api/open-path', kirimJson({ targetPath: path }));
  } catch (e) {
    toast(e.message, 'err');
  }
}
