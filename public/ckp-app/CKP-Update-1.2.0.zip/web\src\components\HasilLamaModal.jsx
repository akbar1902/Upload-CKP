import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { FileSpreadsheet, History } from 'lucide-react';
import { useApp } from '../store.jsx';
import { api, kirimJson } from '../lib/api.js';
import { Empty, Modal } from './ui.jsx';

export default function HasilLamaModal() {
  const { s, dispatch, go, toast } = useApp();
  const open = s.modal === 'hasil';
  const [files, setFiles] = useState(null);
  const [err, setErr] = useState('');

  const tutup = () => dispatch({ type: 'modal', modal: null });

  useEffect(() => {
    if (!open) return;
    setFiles(null);
    setErr('');
    api('/api/hasil-files').then((j) => setFiles(j.files || [])).catch((e) => setErr(e.message));
  }, [open]);

  const buka = async (f) => {
    try {
      const j = await api('/api/draft/from-hasil', kirimJson({ hasilPath: f.path }));
      dispatch({ type: 'draft', rows: j.rows });
      dispatch({ type: 'zip', zip: { path: '', name: '', files: [], photos: 0, docs: 0, bytes: 0, total: 0, folder: '' } });
      tutup();
      go('draft');
      toast(`Draft dari file lama: ${j.rows.length} baris${j.gagalSkip ? ` (${j.gagalSkip} gagal dilewati)` : ''}.`);
    } catch (e) {
      toast(e.message, 'err');
    }
  };

  return (
    <Modal open={open} onClose={tutup} title="Buka file hasil lama" desc="Susun draft dari hasil_*.xlsx yang pernah dibuat. Hanya baris berstatus BERHASIL yang dipakai." width="max-w-lg">
      {err && <p className="text-[13px] text-bad">Gagal memuat: {err}</p>}
      {!err && files === null && <p className="py-8 text-center text-[13px] text-muted">Memuat daftar file…</p>}
      {files && files.length === 0 && (
        <Empty icon={History} title="Belum ada file hasil" desc="Hasil upload lama (hasil_*.xlsx) akan muncul di sini." />
      )}
      {files && files.length > 0 && (
        <ul className="divide-y divide-line overflow-hidden rounded-xl border border-line">
          {files.map((f, i) => (
            <motion.li key={f.path} initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: Math.min(i * 0.02, 0.2) }}>
              <button type="button" onClick={() => buka(f)} className="flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-surface-2">
                <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-accent-soft text-accent-text"><FileSpreadsheet className="size-4" /></span>
                <span className="min-w-0 flex-1 truncate font-mono text-[12.5px] text-ink">{f.nama}</span>
              </button>
            </motion.li>
          ))}
        </ul>
      )}
    </Modal>
  );
}
