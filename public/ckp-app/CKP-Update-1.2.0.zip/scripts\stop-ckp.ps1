# Hentikan CKP App yang sedang berjalan di port 3230 (atau $env:PORT).
[CmdletBinding()]
param([int]$Port = 0)

if (-not $Port -or $Port -le 0) {
  $Port = if ($env:PORT) { [int]$env:PORT } else { 3230 }
}

$pidCkp = 0
try {
  $conn = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop | Select-Object -First 1
  if ($conn) { $pidCkp = [int]$conn.OwningProcess }
} catch { }
if ($pidCkp -le 0) {
  try {
    $line = (netstat -ano | Select-String -Pattern ":$Port\s+.*LISTENING" | Select-Object -First 1).Line
    if ($line) { $pidCkp = [int](($line -split '\s+')[-1]) }
  } catch { }
}

if ($pidCkp -le 0) {
  Write-Host "CKP App tidak sedang berjalan di port $Port."
  exit 0
}

$proses = Get-Process -Id $pidCkp -ErrorAction SilentlyContinue
$nama = if ($proses) { $proses.ProcessName } else { '?' }
if ($nama -ne 'node') {
  Write-Host "Port $Port dipakai proses lain ($nama, PID $pidCkp). Tidak dihentikan." -ForegroundColor Yellow
  exit 1
}

Write-Host "Menghentikan CKP App (PID $pidCkp)..."
Stop-Process -Id $pidCkp -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 600
Write-Host "CKP App dihentikan."
exit 0
