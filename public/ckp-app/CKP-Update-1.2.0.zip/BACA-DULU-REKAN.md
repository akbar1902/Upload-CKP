# BACA DULU — Paket CKP App untuk Rekan

Paket ini berisi:

- **CKP App** (folder utama) — upload bukti dukung → Google Drive → draft → Excel → kirim ke SIKAP.
- **chrome-extension/ckp-companion** — extension CKP Companion untuk mengisi KipApp.
- **tools/rclone/rclone.exe** — rclone portable (kalau disertakan).
- **PANDUAN_MULTI_PENGGUNA.md** — panduan lengkap profil, RK, dan SIKAP.

## 1. Pasang CKP App

1. Ekstrak ZIP ini ke folder yang mudah diingat, misalnya `D:\CKP-App`.
2. Install **Node.js LTS** dari https://nodejs.org/ (centang *Add to PATH*).
3. Buka folder hasil ekstrak, lalu double-click **`Jalankan CKP.bat`**.
   - Pertama kali akan menjalankan `npm install` (butuh internet).
   - Browser/Edge akan terbuka di `http://localhost:3230`.
   - Server berjalan di background dan **tidak ikut mati** saat jendela cmd ditutup.
   - Ingin otomatis nyala tiap login? Jalankan **`Pasang Autostart CKP.bat`** sekali.
4. Di CKP App, buka **Profil & rekan**:
   - **Cara tercepat:** klik **Impor semua pegawai** di kartu **Dataset RK kantor**,
     lalu pilih nama Anda di daftar profil.
   - Atau **Tambah pegawai** manual, lalu impor RK sendiri di **Daftar RK**.
   - Satu pegawai = satu profil dengan RK miliknya. Tim hanya info tambahan.
5. Buka **Daftar RK** untuk memeriksa daftar RK profil Anda.
6. Atur **Kamus singkatan** dan **Kata kunci RK** sesuai kebutuhan.

## 2. Hubungkan Google Drive (rclone)

CKP App memakai rclone untuk mengunggah foto/dokumen ke Google Drive.

1. Buka Command Prompt di folder CKP App.
2. Jalankan:
   ```bat
   tools\rclone\rclone.exe config
   ```
   (kalau rclone tidak disertakan, install dari https://rclone.org/downloads/ lalu jalankan `rclone config`).
3. Pilih **n** (new remote) → nama **`gdrive`** → pilih **Google Drive** → ikuti proses login di browser.
4. Setelah selesai, cek:
   ```bat
   tools\rclone\rclone.exe listremotes
   ```
   Harus muncul `gdrive:`.
5. Di CKP App, status rclone di sidebar harus hijau.

> Setiap pegawai memakai akun Google Drive-nya sendiri. Jangan memakai akun orang lain.

## 3. Hubungkan ke SIKAP (satu klik)

1. Di CKP App → **Profil & rekan** → kartu **Integrasi SIKAP**.
2. Alamat SIKAP sudah terisi otomatis (atau isi `https://sikap-ckp.vercel.app`).
3. Klik **Hubungkan SIKAP**.
4. Tab SIKAP terbuka → login → klik **Setujui & hubungkan CKP App**.
5. Kembali ke CKP App; status berubah **terhubung** dan daftar RK ikut tersinkron.
   - Sinkron RK bersifat **menggabungkan**: RK lokal yang sudah ada tidak dihapus.
   - Jika draft sudah ada, klik **Hitung ulang RK** di halaman Draft.

Setelah terhubung, di halaman **Export** akan muncul tombol **Kirim ke SIKAP**.

## 4. Pasang Extension Chrome (CKP Companion)

1. Ekstrak ZIP (kalau belum).
2. Buka Chrome → ketik `chrome://extensions`.
   - `Jalankan CKP.bat` sekarang membuka **Chrome** karena extension biasanya dipasang di sana.
   - Kalau memakai Edge, pasang extension di Edge juga.
3. Aktifkan **Developer mode** (kanan atas).
4. Klik **Load unpacked** → pilih folder:
   `chrome-extension\ckp-companion` (folder yang berisi `manifest.json`).
5. Buka https://kipapp.bps.go.id/, klik ikon **CKP Companion** di toolbar.
6. Di panel extension, pilih profil pegawai (dibuat otomatis saat menerima data dari CKP App).

## 5. Alur kerja harian

1. CKP App → **Upload ZIP** bukti dukung.
2. **Sinkron Drive**.
3. **Draft & Koreksi** → cek tanggal, kegiatan, RK.
4. **Export** → **Kirim ke SIKAP** (atau unduh Excel).
5. Di KipApp, buka extension → **Isi & simpan semua kegiatan**.

## 6. Kalau ada masalah

| Gejala | Solusi |
|---|---|
| `rclone tidak ditemukan` | Jalankan `tools\rclone\rclone.exe version`; pastikan file ada. |
| `gdrive:` tidak muncul | Ulangi `rclone config`, pastikan remote bernama `gdrive`. |
| Halaman CKP App tidak terbuka | Jalankan `Jalankan CKP.bat` lagi (server hang otomatis dijalankan ulang). Bila tetap gagal, buka `data\logs\server.log` untuk melihat penyebabnya. |
| Port 3230 dipakai aplikasi lain | Tutup aplikasi tersebut, atau jalankan `Jalankan CKP.bat -Restart`. |
| Integrasi SIKAP 404/405 | Pastikan SIKAP sudah versi terbaru dan alamatnya benar. Restart CKP App. |
| Extension tidak muncul | Pastikan memilih folder yang berisi `manifest.json`, lalu **Reload** di `chrome://extensions`. |
| Extension masih v0.3.6 / profil “Pegawai 1” | Hapus extension lama, **Load unpacked** folder `chrome-extension\ckp-companion`, pastikan versi **0.4.1**. Buka CKP App di Chrome yang sama, lalu klik **Kirim ke KipApp**. |
| Data/akun tercampur | Gunakan profil pegawai masing-masing; jangan salin folder `data/` milik orang lain. |

## 7. Berbagi ke banyak rekan

- Untuk beberapa rekan, cukup bagikan ZIP ini. Mereka membuat profil masing-masing.
- Jangan pernah membagikan folder `data/` milik Anda — isinya upload, hasil ekspor, dan token SIKAP pribadi.
- Kalau nanti ingin lebih praktis, extension bisa dipublikasikan **unlisted/private** di Chrome Web Store agar tidak perlu *Load unpacked*.

## 8. Update aplikasi

- **Versi 1.2.0 ke atas:** buka CKP App → sidebar kiri bawah → klik
  **“Perbarui sekarang”**. Aplikasi menutup sebentar lalu terbuka lagi.
- **Versi lama (sekali saja):** unduh
  <https://sikap-ckp.vercel.app/ckp-app/CKP-Updater.zip>,
  ekstrak ke folder CKP App ini (yang berisi `Jalankan CKP.bat`), lalu
  double-click **`Update CKP.bat`**.
- Folder `data/` (profil, token SIKAP, upload, hasil) **tidak dihapus**.
- Panduan lengkap: `CARA_UPDATE_CKP.md`.
