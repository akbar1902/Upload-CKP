@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Update CKP App

set "SUMBER="
if exist "%~dp0update-source.txt" (
  for /f "usebackq delims=" %%L in ("%~dp0update-source.txt") do (
    if not defined SUMBER if not "%%L"=="" set "SUMBER=%%L"
  )
)
if not defined SUMBER set "SUMBER=https://sikap-cpk.vercel.app/ckp-app/update.json"

if not exist "%~dp0scripts\update-ckp.ps1" (
  echo File scripts\update-ckp.ps1 tidak ditemukan.
  echo Ekstrak "CKP-Updater.zip" ke folder CKP App ini lebih dulu.
  pause
  exit /b 1
)

echo ============================================================
echo  Update CKP App
echo  Sumber: %SUMBER%
echo ============================================================
echo.
echo Profil, token SIKAP, upload, dan hasil TIDAK akan dihapus.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\update-ckp.ps1" -Source "%SUMBER%" -Port 3230
set "KODE=%errorlevel%"
echo.
if not "%KODE%"=="0" (
  echo Update GAGAL. Lihat data\logs\update.log.
  pause
) else (
  echo Update selesai.
  timeout /t 2 >nul
)
exit /b %KODE%
