@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title CKP App

rem Launcher PowerShell menangani semuanya:
rem  - cek/instal dependency
rem  - menjalankan server sebagai proses terpisah (tetap hidup walau
rem    jendela ini, VS Code, atau OpenCode ditutup)
rem  - menunggu server siap, lalu membuka browser
rem
rem Contoh: Jalankan CKP.bat -Restart   (paksa jalankan ulang server)

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start-ckp.ps1" %*
set "KODE=%errorlevel%"

if not "%KODE%"=="0" (
    echo.
    pause
)
exit /b %KODE%
