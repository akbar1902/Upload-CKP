import { useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ArrowRight, CalendarDays, ClipboardList, ExternalLink, FileText, ListChecks, RefreshCw, Save, Search, Wand2, X } from 'lucide-react';
import { useApp } from '../store.jsx';
import { BULAN, fotoUrl, PHOTO_RE } from '../lib/format.js';
import { barisEntry, statusBaris } from '../lib/draft.js';
import { turunkan } from '../lib/derive.js';
import { Button, Card, Empty, inputCls, Pill, SectionHead } from '../components/ui.jsx';
import RkPicker from '../components/RkPicker.jsx';
import HeaderCard from '../components/HeaderCard.jsx';
import Lightbox from '../components/Lightbox.jsx';

const FILTER = [
  { value: '', label: 'Semua baris' },
  { value: 'review', label: 'Perlu dicek' },
  { value: 'ok', label: 'Sudah beres' },
  { value: 'nork', label: 'RK kosong' },
  { value: 'notgl', label: 'Tanggal kosong' },
];

export default function DraftPage() {
  const { s, dispatch, go, toast, simpanDraftLokal, tambahRk, susunUlangRk, isiTanggalDariNama } = useApp();
  const d = turunkan(s);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('');
  const [pick, setPick] = useState(null);
  const [lb, setLb] = useState(null);
  const cariRef = useRef(null);
  const autoTanggalRef = useRef(false);
  const autoRkRef = useRef(false);

  // Draft lama / hasil load bisa punya tanggal kosong. Isi otomatis sekali
  // dari nama file; isian manual tidak ditimpa.
  useEffect(() => {
    if (autoTanggalRef.current || !s.draft.length) return;
    if (!s.draft.some((d) => !d.tglAwal || !d.bulan)) return;
    autoTanggalRef.current = true;
    isiTanggalDariNama();
  }, [s.draft, isiTanggalDariNama]);

  // Setelah daftar RK/kata kunci berubah, isi ulang saran RK untuk baris yang
  // belum dikoreksi manual (mis. RK kosong karena nama RK berubah setelah sync).
  useEffect(() => {
    if (autoRkRef.current || !s.draft.length) return;
    const perlu = s.draft.some((d) => !d._touched && (!d.rk || !s.rk.includes(d.rk)));
    if (!perlu) return;
    autoRkRef.current = true;
    susunUlangRk();
  }, [s.draft, s.rk, susunUlangRk]);

  useEffect(() => {
    const k = (e) => {
      if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || '')) {
        e.preventDefault();
        cariRef.current?.focus();
      }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);

  const rows = useMemo(() => {
    const k = q.trim().toLowerCase();
    return s.draft.map((r, i) => ({ r, i })).filter(({ r }) => {
      if (k && !(r.namaFile.toLowerCase().includes(k) || (r.kegiatan || '').toLowerCase().includes(k))) return false;
      const st = statusBaris(r, s.rk);
      if (filter === 'review' && st.cls === 'ok') return false;
      if (filter === 'ok' && st.cls !== 'ok') return false;
      if (filter === 'nork' && r.rk) return false;
      if (filter === 'notgl' && r.tglAwal && r.bulan) return false;
      return true;
    });
  }, [s.draft, s.rk, q, filter]);

  const fotos = useMemo(() => (
    s.zip.path ? s.draft.filter((r) => PHOTO_RE.test(r.namaFile)).map((r) => ({
      entryName: barisEntry(r, s.zip.files), originalName: r.namaFile, size: 0, idx: s.draft.indexOf(r),
    })) : []
  ), [s.draft, s.zip.path, s.zip.files]);

  if (!s.draft.length) {
    return (
      <>
        <SectionHead eyebrow="Tahap 3 dari 4" title="Draft & koreksi" desc="Tanggal, kegiatan, dan RK ditebak otomatis dari nama file." />
        <Card>
          <Empty
            icon={Wand2}
            title="Belum ada draft"
            desc="Selesaikan upload ke Drive, draft akan tersusun otomatis. Atau buka file hasil lama dari menu di sebelah kiri."
            action={<Button variant="secondary" onClick={() => go('drive')}>Ke tahap Drive</Button>}
          />
        </Card>
      </>
    );
  }

  const terlihat = rows.map((x) => x.i);
  const semuaTerpilih = terlihat.length > 0 && terlihat.every((i) => s.sel.includes(i));
  const toggle = (i) => dispatch({ type: 'sel', sel: s.sel.includes(i) ? s.sel.filter((x) => x !== i) : [...s.sel, i] });
  const ubah = (i, patch) => dispatch({ type: 'draftPatch', i, patch });
  const beres = s.draft.length - d.perluCek;

  const pilihRk = (v) => {
    if (pick?.bulk) {
      dispatch({ type: 'draftBulk', patch: { rk: v } });
      toast(`RK diterapkan ke ${s.sel.length} baris.`);
    } else if (pick) {
      ubah(pick.i, { rk: v });
    }
  };
  const barisPick = pick && !pick.bulk ? s.draft[pick.i] : null;

  return (
    <>
      <SectionHead
        eyebrow="Tahap 3 dari 4"
        title="Draft & koreksi"
        desc="Bereskan baris bercap amber atau merah, lalu lanjut ke export. Perubahan di sini langsung mengalir ke Excel dan KipApp."
      />

      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Total baris" value={s.draft.length} />
        <Stat label="Sudah beres" value={beres} tone="ok" />
        <Stat label="Perlu dicek" value={d.perluCek} tone={d.perluCek ? 'warn' : ''} />
        <Stat label="RK kosong" value={d.rkKosong} tone={d.rkKosong ? 'bad' : ''} />
      </div>

      <div className="mb-5"><HeaderCard /></div>

      <Card className="overflow-hidden">
        <div className="flex flex-wrap items-center gap-3 border-b border-line px-5 py-4">
          <div className="relative min-w-[220px] flex-1">
            <Search className="pointer-events-none absolute top-1/2 left-3.5 size-4 -translate-y-1/2 text-faint" />
            <input ref={cariRef} className={`${inputCls} pl-10`} placeholder="Cari nama file atau kegiatan…   ( / )" value={q} onChange={(e) => setQ(e.target.value)} />
          </div>
          <select className={`${inputCls} w-auto min-w-[170px]`} value={filter} onChange={(e) => setFilter(e.target.value)}>
            {FILTER.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
          <Button size="sm" variant="secondary" icon={CalendarDays} onClick={isiTanggalDariNama} title="Isi tanggal yang masih kosong dari nama file">Isi tanggal</Button>
          <Button size="sm" variant="secondary" icon={RefreshCw} onClick={susunUlangRk} title="Hitung ulang saran RK untuk baris yang belum dikoreksi manual">Hitung ulang RK</Button>
          <Button size="sm" variant="secondary" icon={ClipboardList} onClick={() => go('rk')}>Kelola RK</Button>
        </div>

        <AnimatePresence initial={false}>
          {s.sel.length > 0 && (
            <motion.div
              initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden border-b border-line bg-accent-soft"
            >
              <div className="flex flex-wrap items-center gap-2.5 px-5 py-3">
                <span className="tnum mr-auto text-[13px] font-bold text-accent-text">{s.sel.length} baris dipilih</span>
                <Button size="sm" variant="primary" icon={ListChecks} onClick={() => setPick({ bulk: true })}>Pilih RK massal</Button>
                <Button size="sm" variant="secondary" icon={CalendarDays} onClick={() => { dispatch({ type: 'draftTglAtas' }); toast('Tanggal kosong mengikuti baris di atasnya.'); }}>Ikuti tanggal di atas</Button>
                <Button size="sm" variant="ghost" icon={X} onClick={() => dispatch({ type: 'sel', sel: [] })}>Batal pilih</Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="scroll-thin max-h-[calc(100vh-260px)] overflow-auto">
          <table className="w-full min-w-[960px] table-fixed text-left text-[13px]">
            <thead className="sticky top-0 z-10 bg-surface text-[11px] font-bold tracking-[0.08em] text-faint uppercase">
              <tr className="border-b border-line">
                <th className="w-12 px-4 py-3">
                  <input type="checkbox" aria-label="Pilih semua yang terlihat" checked={semuaTerpilih} onChange={(e) => dispatch({ type: 'sel', sel: e.target.checked ? terlihat : [] })} className="size-4 accent-[var(--accent-solid)]" />
                </th>
                <th className="w-10 px-2 py-3 text-center font-bold">No</th>
                <th className="w-[300px] px-3 py-3 font-bold">Berkas</th>
                <th className="w-[190px] px-3 py-3 font-bold">Tanggal</th>
                <th className="px-3 py-3 font-bold">Kegiatan &amp; Rencana Kinerja</th>
                <th className="w-[120px] px-4 py-3 font-bold">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ r, i }, n) => {
                const st = statusBaris(r, s.rk);
                const isFoto = PHOTO_RE.test(r.namaFile);
                const dipilih = s.sel.includes(i);
                const fotoIdx = isFoto ? fotos.findIndex((f) => f.idx === i) : -1;
                return (
                  <tr key={i} className={`border-b border-line/70 align-top transition ${dipilih ? 'bg-accent-soft/60' : st.cls !== 'ok' ? 'bg-amber-soft/40' : 'hover:bg-surface-2/50'}`}>
                    <td className="px-4 py-3">
                      <input type="checkbox" aria-label={`Pilih baris ${n + 1}`} checked={dipilih} onChange={() => toggle(i)} className="size-4 accent-[var(--accent-solid)]" />
                    </td>
                    <td className="tnum px-2 py-3 text-center text-muted">{n + 1}</td>
                    <td className="px-3 py-3">
                      <div className="flex items-start gap-3">
                        {isFoto && s.zip.path ? (
                          <button type="button" onClick={() => setLb(fotoIdx)} className="size-12 shrink-0 overflow-hidden rounded-lg bg-surface-3 ring-1 ring-inset ring-line" title="Klik untuk pratinjau">
                            <img loading="lazy" src={fotoUrl(s.zip.path, barisEntry(r, s.zip.files))} alt="" className="size-full object-cover" />
                          </button>
                        ) : (
                          <span className="grid size-12 shrink-0 place-items-center rounded-lg bg-surface-3 text-muted"><FileText className="size-4.5" /></span>
                        )}
                        <div className="min-w-0">
                          <p className="max-w-[200px] truncate font-mono text-[12.5px] text-ink" title={r.namaFile}>{r.namaFile}</p>
                          <div className="mt-1.5 flex gap-3 text-[12px] font-semibold">
                            <button type="button" onClick={() => window.open(r.link, '_blank')} className="inline-flex items-center gap-1 text-accent-text hover:underline"><ExternalLink className="size-3" />Drive</button>
                            {isFoto && s.zip.path && <button type="button" onClick={() => setLb(fotoIdx)} className="text-muted hover:text-ink hover:underline">Pratinjau</button>}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-1.5">
                          <input type="number" min={1} max={31} aria-label="Tanggal awal" value={r.tglAwal ?? ''} placeholder="Tgl"
                            onChange={(e) => ubah(i, { tglAwal: clampTgl(e.target.value) })}
                            className={`${inputCls} tnum w-16 px-2.5 py-2 text-center`} />
                          <span className="text-faint">–</span>
                          <input type="number" min={1} max={31} aria-label="Tanggal akhir" value={r.tglAkhir ?? ''} placeholder="s.d."
                            onChange={(e) => ubah(i, { tglAkhir: clampTgl(e.target.value) })}
                            className={`${inputCls} tnum w-16 px-2.5 py-2 text-center`} />
                        </div>
                        <select aria-label="Bulan" value={r.bulan || ''} onChange={(e) => ubah(i, { bulan: e.target.value })} className={`${inputCls} px-2.5 py-2`}>
                          <option value="">— Bulan —</option>
                          {BULAN.map((b) => <option key={b} value={b}>{b}</option>)}
                        </select>
                        {r.alasan && (!r.tglAwal || !r.bulan) && <p className="text-[11.5px] leading-snug text-amber">{r.alasan}</p>}
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex flex-col gap-2">
                        <textarea
                          rows={1}
                          aria-label="Kegiatan"
                          placeholder="Tulis kegiatan…"
                          value={r.kegiatan || ''}
                          onChange={(e) => ubah(i, { kegiatan: e.target.value })}
                          className={`${inputCls} min-h-[42px] resize-none leading-relaxed [field-sizing:content]`}
                        />
                        <button
                          type="button"
                          onClick={() => setPick({ i })}
                          className={`group flex w-full items-center gap-2.5 rounded-xl border px-3 py-2 text-left text-[12.5px] transition ${r.rk ? 'border-accent/30 bg-accent-soft text-accent-text hover:border-accent/60' : 'border-dashed border-line-strong text-muted hover:border-accent/50 hover:text-ink'}`}
                        >
                          <span className="rounded-md bg-surface/70 px-1.5 py-0.5 text-[10px] font-extrabold tracking-wider uppercase">RK</span>
                          <span className="min-w-0 flex-1 truncate font-medium">{r.rk || 'Pilih Rencana Kinerja…'}</span>
                          <span className="text-faint transition group-hover:translate-x-0.5">›</span>
                        </button>
                        {r.usulan?.length > 0 && !r.rk && (
                          <p className="truncate text-[11.5px] text-faint">Saran: {r.usulan[0]}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={st.cls !== 'ok' ? 'inline-block -rotate-2' : ''}>
                        <Pill tone={st.cls}>{st.txt}</Pill>
                      </span>
                    </td>
                  </tr>
                );
              })}
              {rows.length === 0 && (
                <tr><td colSpan={6} className="px-5 py-12 text-center text-muted">Tidak ada baris yang cocok dengan filter.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-wrap items-center gap-3 border-t border-line px-5 py-4">
          <p className="text-[13px] text-muted">
            <span className="tnum font-bold text-ink">{s.draft.length}</span> baris ·{' '}
            {d.perluCek
              ? <span className="font-semibold text-amber">{d.perluCek} belum lengkap — export terkunci</span>
              : <span className="font-semibold text-ok">semua lengkap</span>}
          </p>
          <div className="ml-auto flex gap-2">
            <Button variant="secondary" icon={Save} onClick={() => simpanDraftLokal(true)}>Simpan draft</Button>
            <Button variant="primary" icon={ArrowRight} onClick={() => go('export')}>Lanjut ke export</Button>
          </div>
        </div>
      </Card>

      <RkPicker
        open={pick !== null}
        onClose={() => setPick(null)}
        onPick={pilihRk}
        rkList={s.rk}
        usulan={barisPick?.usulan || []}
        terpilih={barisPick?.rk || ''}
        onAddRk={tambahRk}
        title={pick?.bulk ? `Pilih RK untuk ${s.sel.length} baris` : 'Pilih Rencana Kinerja'}
        desc={barisPick ? barisPick.namaFile : 'Rencana kinerja yang sama akan diterapkan ke semua baris terpilih.'}
      />

      <Lightbox
        open={lb !== null && fotos.length > 0}
        items={fotos}
        idx={Math.max(0, lb ?? 0)}
        zipPath={s.zip.path}
        onIdx={setLb}
        onClose={() => setLb(null)}
      />
    </>
  );
}

function clampTgl(v) {
  if (v === '') return null;
  const n = parseInt(v, 10);
  if (!n) return null;
  return Math.max(1, Math.min(31, n));
}

function Stat({ label, value, tone = '' }) {
  const warna = tone === 'ok' ? 'text-ok' : tone === 'warn' ? 'text-amber' : tone === 'bad' ? 'text-bad' : 'text-ink';
  return (
    <div className="rounded-2xl border border-line bg-surface px-4 py-3.5 shadow-[0_10px_30px_-18px_rgb(0_0_0/0.35)]">
      <p className={`tnum text-[24px] font-extrabold tracking-[-0.02em] ${warna}`}>{value}</p>
      <p className="text-[12px] font-medium text-muted">{label}</p>
    </div>
  );
}
