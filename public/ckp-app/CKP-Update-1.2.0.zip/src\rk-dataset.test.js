'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const {
  splitRkCell,
  parsePegawai,
  susunPegawai,
  ringkasDataset,
} = require('./rk-dataset');

test('splitRkCell memecah satu sel menjadi beberapa RK', () => {
  assert.deepEqual(
    splitRkCell('• Terlaksananya Kegiatan A • Terlaksananya Kegiatan B'),
    ['Terlaksananya Kegiatan A', 'Terlaksananya Kegiatan B']
  );
  assert.deepEqual(
    splitRkCell('Terlaksananya A\n• Terlaksananya B\n- Terlaksananya C'),
    ['Terlaksananya A', 'Terlaksananya B', 'Terlaksananya C']
  );
  assert.deepEqual(splitRkCell('• Terlaksananya A • Terlaksananya A'), ['Terlaksananya A']);
});

test('splitRkCell mendekode entitas HTML dan merapikan spasi', () => {
  assert.deepEqual(
    splitRkCell('• Tersedianya sarana &amp;amp; prasarana • Terlaksananya   Kegiatan'),
    ['Tersedianya sarana & prasarana', 'Terlaksananya Kegiatan']
  );
});

test('parsePegawai mengambil NIP dan nama', () => {
  assert.deepEqual(parsePegawai('[340066364] Muhammad Akbar S.Tr.Stat.'), {
    nip: '340066364',
    nama: 'Muhammad Akbar S.Tr.Stat.',
  });
  assert.deepEqual(parsePegawai('Tanpa NIP'), { nip: '', nama: 'Tanpa NIP' });
});

test('susunPegawai menggabungkan RK dari beberapa tim tanpa duplikat', () => {
  const hasil = susunPegawai([
    {
      nip: '1', nama: 'Pegawai Satu', jabatan: 'Statistisi', status: 'Anggota',
      team: 'Tim A', rks: ['RK A', 'RK B'],
    },
    {
      nip: '1', nama: 'Pegawai Satu, S.Stat.', jabatan: 'Statistisi Ahli', status: 'Ketua',
      team: 'Tim B', rks: ['RK B', 'RK C'],
    },
    {
      nip: '2', nama: 'Pegawai Dua', jabatan: 'Pelaksana', status: 'Anggota',
      team: 'Tim A', rks: [],
    },
  ]);

  assert.equal(hasil.length, 2);
  const satu = hasil.find((e) => e.nip === '1');
  assert.deepEqual(satu.rks, ['RK A', 'RK B', 'RK C']);
  assert.deepEqual(satu.teams, ['Tim A', 'Tim B']);
  assert.deepEqual(satu.ketuaTeams, ['Tim B']);
  assert.equal(satu.nama, 'Pegawai Satu, S.Stat.');
  assert.equal(satu.jabatan, 'Statistisi Ahli');
  assert.equal(hasil.find((e) => e.nip === '2').rks.length, 0);
});

test('ringkasDataset menghitung total pegawai, tim, dan RK', () => {
  const employees = [
    { nip: '1', nama: 'A', rks: ['RK A', 'RK B'] },
    { nip: '2', nama: 'B', rks: ['RK B', 'RK C'] },
  ];
  const teams = [{ team: 'Tim A' }, { team: 'Tim B' }];
  assert.deepEqual(ringkasDataset({ employees, teams }), {
    jumlahPegawai: 2,
    jumlahTim: 2,
    jumlahRkUnik: 3,
    pegawaiTanpaRk: 0,
  });
});
