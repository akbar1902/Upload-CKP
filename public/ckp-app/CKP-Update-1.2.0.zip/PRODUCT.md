# Product

<!-- impeccable:product-schema 1 -->

## Platform

web

## Users

Pegawai BPS (awal: satu pengguna; sekarang multi-profil untuk rekan sekantor). Memakai tiap bulan untuk menyusun CKP dari foto bukti dukung. Berjalan lokal di laptop Windows via Edge App Mode / browser, bisa juga satu server LAN dengan profil terpisah per pegawai. RK tiap pegawai berbeda → daftar RK, kata kunci, kamus, header, dan riwayat dipisah per profil.

## Product Purpose

Menggabungkan dua program menjadi satu alur: upload ZIP bukti dukung → sinkron Google Drive via rclone → draft baris otomatis (tanggal + kegiatan + usulan RK) → koreksi → export Excel CKP format SIKAP, lalu handoff ke extension KipApp. Sukses = Excel diterima SIKAP/KipApp tanpa edit manual, dan 20–50 file selesai dalam satu duduk.

## Positioning

Satu-satunya alur yang menyambung foto mentah sampai form KipApp terisi: menebak tanggal/kegiatan/RK dari nama file, bukan sekadar upload atau sekadar cetak Excel.

## Operating Context

Alur 4 langkah boleh direstruktur bila ada ide lebih baik: Upload → Drive → Draft → Export. File ZIP berisi foto/dokumen bernama `1 September_kegiatan…` / `20-27 September_kegiatan…`. Upload via rclone ke Drive (tetap). Header pegawai tetap; yang berganti tiap bulan hanya periode + bulan. Dipakai di ruangan terang maupun malam hari.

## Capabilities and Constraints

- Upload ZIP dari browser (maks ~1500 MB), inspect isi + thumbnail, pilih folder Drive + kecepatan paralel.
- Progress realtime per berkas (SSE), retry khusus yang gagal, laporan link cadangan.
- Draft otomatis: parser tanggal + ekspansi kamus singkatan + suggest RK dari daftar RK (bisa ditambah RK baru langsung dari picker); user koreksi tanggal/kegiatan/RK; validasi inline mengunci export.
- Export Excel persis template SIKAP (jangan geser struktur); riwayat 50 file.
- Integrasi SIKAP: token per pegawai, tarik RK dari SIKAP, kirim Excel langsung ke `/api/integrations/ckp-app` (tanpa download-upload manual).
- Handoff ke extension CKP Companion via bridge (postMessage); eksekusi pengisian tetap di extension.
- Batasan: tanpa PowerShell dialog / path hardcode (env-overridable); backend Node Express satu port; rclone wajib terinstall + remote gdrive login.
- Fakta belum diputus: tidak ada — navigasi final = rel pipa 4 tahap
  (Upload → Drive → Draft → Export) + topbar stepper slim + rail-foot
  (toggle tema, rclone, versi). Struktur rail/topbar/slip/greet terdeposit
  di DESIGN.md.

## Brand Commitments

Nama CKP App. Warna teal BPS Belitung (#0F766E) tetap sebagai identitas. Rasa: playful tapi profesional. Struktur: mode gelap sebagai default dengan toggle ke terang. Bahasa Indonesia kasual.

## Evidence on Hand

- App jalan: CKP-App/src/server.js, public/index.html + app.js + style.css.
- Logic inti: parser.js, rk-matcher.js (43 RK di src/config/rk-list.json), excel-builder.js, kamus-singkatan.json, config.json.
- Contoh nama file nyata dan hasil E2E (ZIP → draft → export) terverifikasi.
- Extension harian: Auto-Input-CKP/chrome-extension-v0.3.4/ckp-v034 (bridge + handoff ada).

## Product Principles

1. Nol kerja ulang: yang sudah benar (link Drive, tebakan draft) jangan disentuh user lagi.
2. Gagal itu lokal: satu file gagal tidak menggagalkan batch; retry menyasar yang gagal saja.
3. Export terkunci sampai valid: lebih baik ditahan di app daripada ditolak SIKAP.
4. Satu kebenaran draft: edit di satu tempat, mengalir ke Excel dan KipApp.
5. Berani tampil beda tapi tetap alat kerja: playful di permukaan, presisi di data.

## Accessibility & Inclusion

Kontras teks memenuhi WCAG AA di kedua mode; semua aksi bisa keyboard (termasuk picker RK); hormati prefers-reduced-motion.
