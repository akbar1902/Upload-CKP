@echo off
setlocal
cd /d "%~dp0"
title Buat Paket CKP App + Extension untuk Rekan

set "EXT_SRC=%~dp0..\Auto-Input-CKP\chrome-extension-v0.3.4\ckp-v034"
set "RCLONE_SRC=%~dp0..\Bukti Dukung\rclone-v1.75.0-windows-amd64\rclone.exe"
set "TUJUAN=%~dp0..\CKP-App-Untuk-Rekan"
set "ZIP=%~dp0..\CKP-App-Untuk-Rekan.zip"

echo ============================================================
echo  Membuat paket CKP App + Chrome Extension untuk rekan
echo  Folder : %TUJUAN%
echo  ZIP    : %ZIP%
echo ============================================================
echo.
echo  Folder data/ TIDAK ikut disalin, jadi rekan mulai dari
echo  profil kosong dan tidak membawa upload/token SIKAP Anda.
echo.

if exist "%TUJUAN%" (
    echo Menghapus salinan lama...
    rmdir /s /q "%TUJUAN%"
)
if exist "%ZIP%" del /q "%ZIP%"

echo Menyalin CKP App...
robocopy "%~dp0." "%TUJUAN%" /E /XD "%~dp0node_modules" "%~dp0data" "%~dp0.git" "%~dp0.agent" "%~dp0.agents" "%~dp0.codex" "%~dp0.cursor" "%~dp0.gemini" "%~dp0.hermes" "%~dp0.impeccable" "%~dp0.opencode" /XF *.log "Buat Paket Untuk Rekan.bat" "BACA-DULU-REKAN.md" "test-e2e.js" /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 goto gagal

if exist "%EXT_SRC%\manifest.json" (
    echo Menyalin extension Chrome...
    robocopy "%EXT_SRC%" "%TUJUAN%\chrome-extension\ckp-companion" /E /NFL /NDL /NJH /NJS /NP >nul
    if errorlevel 8 goto gagal
) else (
    echo [PERINGATAN] Folder extension tidak ditemukan:
    echo   %EXT_SRC%
    echo Extension tidak ikut dipaketkan.
)

if exist "%RCLONE_SRC%" (
    echo Menyalin rclone portable...
    if not exist "%TUJUAN%\tools\rclone" mkdir "%TUJUAN%\tools\rclone"
    copy /y "%RCLONE_SRC%" "%TUJUAN%\tools\rclone\rclone.exe" >nul
) else (
    echo [INFO] rclone portable tidak ditemukan; rekan perlu install rclone sendiri.
)

if exist "%~dp0BACA-DULU-REKAN.md" (
    copy /y "%~dp0BACA-DULU-REKAN.md" "%TUJUAN%\BACA-DULU.txt" >nul
)

echo Membuat file ZIP...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path '%TUJUAN%\*' -DestinationPath '%ZIP%' -Force"
if errorlevel 1 (
    echo [PERINGATAN] Gagal membuat ZIP. Folder hasil salinan tetap bisa dibagikan.
)

echo.
echo Selesai.
echo   1. Bagikan file ZIP: %ZIP%
echo   2. Rekan mengekstrak, lalu double-click "Jalankan CKP.bat".
echo   3. Panduan ada di dalam paket: BACA-DULU.txt
echo.
pause
exit /b 0

:gagal
echo.
echo GAGAL membuat paket. Pastikan tidak ada file yang sedang dipakai, lalu coba lagi.
pause
exit /b 1
