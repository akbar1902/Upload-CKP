import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CalendarRange, ChevronDown, Wand2 } from 'lucide-react';
import { useApp } from '../store.jsx';
import { BULAN } from '../lib/format.js';
import { periodeOtomatis, sheetCocokBulan, sheetStandar } from '../lib/header.js';
import { Card, Field, inputCls } from './ui.jsx';

export default function HeaderCard() {
  const { s, setHeader } = useApp();
  const [buka, setBuka] = useState(true);
  const h = s.header;
  const bulan = h.bulanPeriode || '';
  const sheet = (h.sheetName || '').trim();
  const salahSheet = bulan && sheet && !sheetCocokBulan(sheet, bulan) && sheetStandar(sheet);

  return (
    <Card className="overflow-hidden">
      <button type="button" onClick={() => setBuka((v) => !v)} aria-expanded={buka} className="flex w-full items-center gap-3 px-5 py-4 text-left transition hover:bg-surface-2/50">
        <span className="grid size-9 place-items-center rounded-lg bg-accent-soft text-accent-text"><CalendarRange className="size-4.5" /></span>
        <span className="min-w-0 flex-1">
          <span className="block text-[14.5px] font-bold text-ink">Kepala arsip</span>
          <span className="block truncate text-[12px] text-muted">
            {h.pegawai || 'Pegawai belum diisi'}{bulan ? ` · ${bulan}` : ''}{h.periode ? ` · ${h.periode}` : ''}
          </span>
        </span>
        <span className="text-[12px] text-faint">tersimpan otomatis</span>
        <motion.span animate={{ rotate: buka ? 180 : 0 }} transition={{ duration: 0.25 }} className="text-muted"><ChevronDown className="size-4.5" /></motion.span>
      </button>

      <AnimatePresence initial={false}>
        {buka && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
            <p className="border-t border-line px-5 pt-3 text-[11.5px] leading-relaxed text-faint">
              Header ini hanya untuk profil <span className="font-semibold text-muted">{s.profile?.nama || 'aktif'}</span>. Rekan lain punya header, RK, dan riwayat sendiri.
            </p>
            <div className="grid gap-4 px-5 pt-4 pb-6 md:grid-cols-2 xl:grid-cols-3">
              <Field label="Pegawai">
                <input className={inputCls} value={h.pegawai || ''} onChange={(e) => setHeader({ pegawai: e.target.value })} />
              </Field>
              <Field label="Tahun">
                <input className={inputCls} value={h.tahun || ''} onChange={(e) => setHeader({ tahun: e.target.value })} />
              </Field>
              <Field label="Wilayah">
                <input className={inputCls} value={h.wilayah || ''} onChange={(e) => setHeader({ wilayah: e.target.value })} />
              </Field>
              <Field label="Unit kerja">
                <input className={inputCls} value={h.unitKerja || ''} onChange={(e) => setHeader({ unitKerja: e.target.value })} />
              </Field>
              <Field label="Bulan periode">
                <select className={inputCls} value={bulan} onChange={(e) => setHeader({ bulanPeriode: e.target.value })}>
                  <option value="">— pilih —</option>
                  {BULAN.map((b) => <option key={b} value={b}>{b}</option>)}
                </select>
              </Field>
              <Field label="Tahun data (untuk tanggal)">
                <input type="number" className={`${inputCls} tnum`} value={h.tahunData ?? ''} onChange={(e) => setHeader({ tahunData: e.target.value })} />
              </Field>
              <Field
                label="Periode SKP"
                className="md:col-span-1"
                hint={bulan && (
                  <button type="button" onClick={() => setHeader({ periode: periodeOtomatis(bulan) })} className="flex w-fit items-center gap-1.5 text-[12px] font-semibold text-accent-text hover:underline">
                    <Wand2 className="size-3.5" /> Isi periode otomatis
                  </button>
                )}
              >
                <input className={inputCls} placeholder="cth: 26 Agustus – 25 September" value={h.periode || ''} onChange={(e) => setHeader({ periode: e.target.value })} />
              </Field>
              <Field
                label="Nama sheet"
                hint={salahSheet && (
                  <button type="button" onClick={() => setHeader({ sheetName: `CKP ${bulan}` })} className="w-fit text-left text-[12px] font-semibold text-amber hover:underline">
                    Tidak cocok dengan {bulan} — klik untuk selaraskan
                  </button>
                )}
              >
                <input className={inputCls} placeholder="cth: CKP September" value={h.sheetName || ''} onChange={(e) => setHeader({ sheetName: e.target.value })} />
              </Field>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}
