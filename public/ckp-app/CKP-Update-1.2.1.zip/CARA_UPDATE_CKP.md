# Cara Update CKP App

> Berlaku mulai versi **1.2.0** (31 Oktober 2026).
> Update **tidak pernah menghapus** folder `data/` (profil, token SIKAP, upload, hasil).

---

## 1. Untuk pengguna versi LAMA (sekali saja)

Pengguna yang sudah terlanjur memakai versi sebelum 1.2.0 belum punya tombol
“Perbarui” di dalam aplikasi. Lakukan sekali:

1. Unduh **`CKP-Updater.zip`**:
   <https://sikap-ckp.vercel.app/ckp-app/CKP-Updater.zip>
2. Ekstrak isi ZIP itu ke **folder CKP App** Anda
   (folder yang berisi `Jalankan CKP.bat`). Biarkan folder `data\` apa adanya.
3. Double-click **`Update CKP.bat`**.
4. Tunggu sampai CKP App terbuka kembali (biasanya 1–2 menit).

Setelah langkah ini, versi Anda menjadi 1.2.0 dan **update berikutnya cukup
lewat tombol “Perbarui sekarang” di dalam aplikasi**.

> Kalau `Update CKP.bat` bilang `scripts\update-ckp.ps1 tidak ditemukan`,
> berarti ZIP belum diekstrak ke folder yang benar. Ekstrak ulang ke folder
> yang sama dengan `Jalankan CKP.bat`.

---

## 2. Untuk versi 1.2.0 ke atas (satu klik)

1. Buka CKP App.
2. Di sidebar kiri bawah akan muncul kartu:
   **“Versi x.y.z tersedia”**.
3. Klik **Perbarui sekarang** → konfirmasi.
4. Aplikasi menutup sebentar, memperbarui, lalu terbuka kembali otomatis.

Jika kartu tidak muncul, berarti:
- Anda sudah memakai versi terbaru, atau
- komputer tidak bisa mengakses `update-source.txt` (lihat §5).

---

## 3. Apa yang dipertahankan & apa yang diganti

| Item | Saat update |
|---|---|
| `data\profiles.json`, `data\profiles\*` | **Dipertahankan** (profil, token SIKAP, RK, draft) |
| `data\uploads`, `data\Hasil CKP`, `data\Hasil Link` | **Dipertahankan** |
| `node_modules\` | Dipertahankan; `npm install` hanya bila dependency berubah |
| `tools\rclone\` | Dipertahankan |
| `chrome-extension\` | Dipertahankan (update extension terpisah) |
| `src\`, `public\`, `web\`, `scripts\` | **Diganti** dengan versi baru |
| `package.json`, `package-lock.json`, `versi.json`, `*.bat` | Diganti |
| `data\backup-update-<waktu>\` | Backup kode lama dibuat otomatis |

Log update: **`data\logs\update.log`**.

---

## 4. Untuk admin: merilis update baru

### 4.1 Siapkan versi

1. Ubah **`CKP-App/versi.json`** (dan `package.json` bila perlu):
   ```json
   { "versi": "1.2.1", "tanggal": "2026-11-10", "catatan": "Perbaikan ..." }
   ```
2. Build UI bila ada perubahan tampilan:
   ```powershell
   cd "C:\Users\muhak\Documents\Project CKP\CKP-App"
   node node_modules\vite\bin\vite.js build
   ```
3. Jalankan **`Buat Paket Update.bat`**.
   Hasil:
   - `..\CKP-Update-<versi>.zip`
   - `..\update.json`

### 4.2 Publikasikan

Cara default (paling mudah, tanpa server baru):

1. Salin **`CKP-Update-<versi>.zip`** dan **`update.json`** ke:
   ```
   SIKAP\public\ckp-app\
   ```
2. Commit + push SIKAP → Vercel otomatis deploy.
3. Pastikan `update-source.txt` di paket CKP App berisi:
   ```
   https://sikap-ckp.vercel.app/ckp-app/update.json
   ```

Cara alternatif (LAN kantor):

1. Taruh `CKP-Update-<versi>.zip` + `update.json` di folder share, mis.
   `\\server\CKP\`.
2. Isi `update-source.txt` dengan:
   ```
   \\server\CKP\update.json
   ```
   (atau path absolut `D:\CKP\update.json`).

Cara alternatif (HTTPS lain): isi `update-source.txt` dengan URL `update.json`
di hosting mana pun. `url` di dalam manifest boleh relatif terhadap manifest.

### 4.3 Verifikasi

- Buka `https://sikap-ckp.vercel.app/ckp-app/update.json` → harus JSON versi baru.
- Buka CKP App versi lama → kartu “Versi ... tersedia” muncul.
- Klik **Perbarui sekarang** → cek `data\logs\update.log`.

---

## 5. Mengatur sumber update

`CKP-App/update-source.txt` — satu baris berisi salah satu:

| Isi | Arti |
|---|---|
| `https://sikap-ckp.vercel.app/ckp-app/update.json` | Manifest di SIKAP (default) |
| `\\server\CKP\update.json` | Manifest di share LAN |
| `D:\CKP\update.json` | Manifest lokal |
| `D:\CKP\CKP-Update-1.2.1.zip` | Langsung ke ZIP (tanpa cek versi) |

Bisa juga lewat environment variable `CKP_UPDATE_SOURCE` (menang atas file).

Format `update.json`:

```json
{
  "versi": "1.2.1",
  "url": "CKP-Update-1.2.1.zip",
  "tanggal": "2026-11-10",
  "catatan": "Perbaikan ..."
}
```

`url` boleh:
- nama file (relatif terhadap lokasi `update.json`),
- URL penuh (`https://...`),
- path absolut (`\\server\...`).

---

## 6. Kalau update gagal

1. Buka **`data\logs\update.log`** — pesan terakhir menunjukkan penyebab.
2. Updater otomatis mengembalikan kode lama dan menyalakan ulang aplikasi.
3. Perbaiki penyebabnya (jaringan, URL, ZIP rusak), lalu:
   - klik **Perbarui** lagi, atau
   - jalankan **`Update CKP.bat`** manual.

Penyebab umum:

| Gejala | Solusi |
|---|---|
| `Sumber update tidak ditemukan` | Cek `update-source.txt` / share / URL |
| `Paket update tidak valid` | ZIP rusak / bukan paket CKP; build ulang |
| `npm install gagal` | Cek internet, lalu jalankan `npm install` manual |
| Aplikasi tidak terbuka lagi | Jalankan `Jalankan CKP.bat`; cek `data\logs\server.log` |
| Kartu update tidak muncul | Versi sudah terbaru, atau manifest tidak terbaca (cek §5) |
| `scripts\update-ckp.ps1 tidak ditemukan` | Ekstrak `CKP-Updater.zip` ke folder CKP App |

---

## 7. Catatan penting

- **Jangan pernah** menyalin folder `data/` milik orang lain.
- **Jangan** mengedit file di `src/` langsung di folder rekan — perubahan akan
  tertimpa saat update. Perbaikan dilakukan di folder pengembangan, lalu
  dirilis lewat `Buat Paket Update.bat`.
- Extension Chrome (`chrome-extension/`) di-update terpisah: ganti folder
  extension lalu **Reload** di `chrome://extensions`.
- Update bekerja selama komputer bisa mengakses sumber manifest (internet/LAN).

---

*Dokumen ini melengkapi `DOKUMENTASI_RK.md` (konsep RK) dan
`BACA-DULU-REKAN.md` (pemasangan awal).*
