'use strict';

/**
 * CKP App — server gabungan.
 * Alur: upload ZIP (via browser) → upload tiap file ke Google Drive via rclone
 *   → link per file → auto-generate draft (parser + suggest RK)
 *   → user koreksi → export Excel CKP format SIKAP.
 *
 * Publish-ready: tanpa dialog PowerShell, tanpa path hardcode.
 * Lokal: node src/server.js → http://localhost:3230 (atau Jalankan CKP.bat)
 *
 * Logic upload (rclone) diadaptasi dari Bukti Dukung/server.js,
 * logic draft/export dari CKP-Excel-Generator (parser/rk-matcher/excel-builder
 * dipakai ulang tanpa diubah).
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const AdmZip = require('adm-zip');
const ExcelJS = require('exceljs');
const multer = require('multer');

const { parseFileName, expandKegiatan, formatTanggal, BULAN } = require('./parser');
const { suggestRK } = require('./rk-matcher');
const { buildCKP } = require('./excel-builder');
const {
  normalizeBaseUrl,
  periodeKeBulanTahun,
  buatClientUploadId,
} = require('./sikap-integration');
const { bacaDataset } = require('./rk-dataset-excel');
const { ringkasDataset } = require('./rk-dataset');
const petaRkPegawai = require('./config/rk-pegawai.json');

const app = express();
const PORT = process.env.PORT || 3230;
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = path.join(__dirname, '..');

// ─── Direktori data (bisa di-override via env → publish-ready) ───────────────
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const PROFILES_DIR = path.join(DATA_DIR, 'profiles');
const PROFILES_FILE = path.join(DATA_DIR, 'profiles.json');
// Folder lama (sebelum multi-profil) — tetap dibaca untuk profil pertama.
const LEGACY_UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
const LEGACY_LINK_DIR = path.join(DATA_DIR, 'Hasil Link');
const LEGACY_CKP_DIR = path.join(DATA_DIR, 'Hasil CKP');
for (const d of [DATA_DIR, PROFILES_DIR, LEGACY_UPLOAD_DIR, LEGACY_LINK_DIR, LEGACY_CKP_DIR]) {
  fs.mkdirSync(d, { recursive: true });
}
// Folder legacy (import hasil lama) — best effort, tidak wajib ada.
const LEGACY_BUKTI_DIR = path.join(ROOT, '..', 'Bukti Dukung', 'Hasil Link');

// ─── Versi & update aplikasi ────────────────────────────────────────────────
const VERSI_FILE = path.join(ROOT, 'versi.json');
const UPDATE_SOURCE_FILE = path.join(ROOT, 'update-source.txt');
let updateSedangJalan = false;

function bacaVersi() {
  try {
    const j = JSON.parse(fs.readFileSync(VERSI_FILE, 'utf8'));
    const v = String(j.versi || '').trim();
    if (v) return v;
  } catch (e) { /* pakai package.json */ }
  try { return String(require(path.join(ROOT, 'package.json')).version || '0.0.0'); } catch (e) { return '0.0.0'; }
}

function bandingVersi(a, b) {
  const pa = String(a || '0').split(/[.\-+]/).map((n) => parseInt(n, 10) || 0);
  const pb = String(b || '0').split(/[.\-+]/).map((n) => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function bacaSumberUpdate() {
  const dariEnv = String(process.env.CKP_UPDATE_SOURCE || '').trim();
  if (dariEnv) return dariEnv;
  try {
    const baris = fs.readFileSync(UPDATE_SOURCE_FILE, 'utf8')
      .split(/\r?\n/)
      .map((x) => x.trim())
      .find(Boolean);
    return baris || '';
  } catch (e) {
    return '';
  }
}

async function bacaManifestUpdate() {
  const sumber = bacaSumberUpdate();
  if (!sumber) return null;
  let teks = '';
  if (/^https?:/i.test(sumber)) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 4000);
    try {
      const res = await fetch(sumber, { signal: ctrl.signal, headers: { 'Cache-Control': 'no-cache' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      teks = (await res.text()).replace(/^\uFEFF/, '');
    } finally {
      clearTimeout(timer);
    }
  } else {
    const p = path.isAbsolute(sumber) ? sumber : path.join(ROOT, sumber);
    teks = fs.readFileSync(p, 'utf8').replace(/^\uFEFF/, '');
  }
  const j = JSON.parse(teks);
  let url = String(j.url || '').trim();
  if (url && !/^https?:/i.test(url) && !path.isAbsolute(url)) {
    url = /^https?:/i.test(sumber)
      ? new URL(url, sumber).href
      : path.resolve(path.dirname(path.isAbsolute(sumber) ? sumber : path.join(ROOT, sumber)), url);
  }
  return {
    versi: String(j.versi || '').trim(),
    url,
    catatan: String(j.catatan || '').trim(),
    tanggal: String(j.tanggal || '').trim(),
    sumber,
  };
}


// ─── Ekstensi didukung ────────────────────────────────────────────────────────
const PHOTO_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.heic', '.webp']);
const DOC_EXTENSIONS = new Set(['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx']);
const SUPPORTED_EXTENSIONS = new Set([...PHOTO_EXTENSIONS, ...DOC_EXTENSIONS]);

// ─── Profil pegawai (multi-pengguna) ────────────────────────────────────────
// Setiap pegawai punya folder sendiri: config header, daftar RK, kata kunci,
// kamus, upload, dan hasil ekspor. RK antar-pegawai tidak saling menimpa.
const CONFIG_SEED_DIR = path.join(__dirname, 'config');
function rapikanTeks(v, maks = 200) {
  return String(v || '').replace(/\s+/g, ' ').trim().slice(0, maks);
}
function slugId(v, maks = 36) {
  return String(v || '')
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, maks);
}
function bacaJsonAbsolut(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return fallback; }
}
function tulisJsonAbsolut(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}
function bacaRegistry() {
  const reg = bacaJsonAbsolut(PROFILES_FILE, null);
  if (reg && Array.isArray(reg.profiles) && reg.profiles.length) return reg;
  return null;
}
function tulisRegistry(reg) {
  tulisJsonAbsolut(PROFILES_FILE, { version: 1, ...reg, updatedAt: new Date().toISOString() });
}
function pecahPegawai(nilai) {
  const teks = String(nilai || '').trim();
  const m = teks.match(/^\[([^\]]+)\]\s*(.*)$/);
  return m ? { nip: m[1].trim(), nama: m[2].trim() } : { nip: '', nama: teks };
}
function idProfilUnik(nama, nip, terpakai) {
  const dasar = slugId(nip || nama) || 'pegawai';
  let id = `p_${dasar}`;
  let n = 1;
  while (terpakai.has(id)) id = `p_${dasar}-${++n}`;
  return id;
}
function profilStoreDari(profile) {
  const dir = path.join(PROFILES_DIR, profile.id);
  const dirs = {
    root: dir,
    uploads: path.join(dir, 'uploads'),
    link: path.join(dir, 'Hasil Link'),
    ckp: path.join(dir, 'Hasil CKP'),
  };
  for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true });
  return {
    profile,
    dir,
    dirs,
    legacyHistory: !!profile.legacyData,
    read(nama, fallback) { return bacaJsonAbsolut(path.join(dir, nama), fallback); },
    write(nama, data) { tulisJsonAbsolut(path.join(dir, nama), data); },
    // Semua folder yang boleh dibaca untuk unduhan/riwayat profil ini.
    historyDirs() {
      const out = [{ dir: dirs.link, jenis: 'Hasil Link' }, { dir: dirs.ckp, jenis: 'CKP' }];
      if (profile.legacyData) {
        out.push({ dir: LEGACY_LINK_DIR, jenis: 'Hasil Link' }, { dir: LEGACY_CKP_DIR, jenis: 'CKP' });
      }
      // Kalau folder peninggalan program lama ada, tetap bisa diimpor (read-only).
      if (profile.legacyData && fs.existsSync(LEGACY_BUKTI_DIR)) out.push({ dir: LEGACY_BUKTI_DIR, jenis: 'Hasil Link' });
      return out;
    },
  };
}
function boolEnv(v) { return /^(1|true|yes|on)$/i.test(String(v || '')); }

function normalisasiNamaRk(v) {
  return String(v || '')
    .toLowerCase()
    .replace(/\btahun\s*20\d{2}\b/g, '')
    .replace(/\b20\d{2}\b/g, '')
    .replace(/[^a-z0-9]/g, '');
}

// Pernah terjadi: setelah "Tarik RK dari SIKAP", daftar lokal diganti sehingga
// RK yang masih dipakai aturan kata kunci hilang. Pulihkan RK seed yang
// direferensikan kata kunci (sekali per profil lama), tanpa mengubah data baru.
function pulihkanRkKataKunci(reg) {
  let berubah = false;
  for (const profile of reg.profiles) {
    if (!profile.legacyData || profile.seedRkRestoredAt) continue;
    const store = profilStoreDari(profile);
    const current = store.read('rk-list.json', []);
    const keywords = store.read('rk-keywords.json', []);
    const seed = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'rk-list.json'), []);
    if (!Array.isArray(current) || !Array.isArray(seed)) {
      profile.seedRkRestoredAt = new Date().toISOString();
      berubah = true;
      continue;
    }
    if (!current.length) {
      if (seed.length) store.write('rk-list.json', seed);
      profile.seedRkRestoredAt = new Date().toISOString();
      berubah = true;
      continue;
    }
    const ada = new Set(current.map(normalisasiNamaRk));
    const seedMap = new Map(seed.map((rk) => [normalisasiNamaRk(rk), rk]));
    const tambah = [];
    for (const aturan of Array.isArray(keywords) ? keywords : []) {
      const kunci = normalisasiNamaRk(aturan && aturan.rk);
      if (!kunci || ada.has(kunci)) continue;
      const asli = seedMap.get(kunci);
      if (asli) {
        ada.add(kunci);
        tambah.push(asli);
      }
    }
    if (tambah.length) store.write('rk-list.json', [...current, ...tambah]);
    profile.seedRkRestoredAt = new Date().toISOString();
    berubah = true;
  }
  if (berubah) tulisRegistry(reg);
  return reg;
}

// Migrasi otomatis: instalasi lama (satu pengguna) menjadi profil pertama.
// Salinan bersih untuk rekan (folder data kosong) dimulai tanpa RK pemilik
// sebelumnya — karena RK tiap pegawai berbeda.
function adaDataLama() {
  const adaFile = (dir, pola) => {
    try { return fs.readdirSync(dir).some((f) => pola.test(f)); } catch (e) { return false; }
  };
  return adaFile(LEGACY_UPLOAD_DIR, /\.zip$/i)
    || adaFile(LEGACY_CKP_DIR, /\.xlsx$/i)
    || adaFile(LEGACY_LINK_DIR, /\.(xlsx|csv)$/i)
    || boolEnv(process.env.MIGRASI_DATA_LAMA);
}
function pastikanProfil() {
  let reg = bacaRegistry();
  if (reg) return pulihkanRkKataKunci(reg);

  const seedKamus = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'kamus-singkatan.json'), []);
  const sekarang = new Date().toISOString();

  if (!adaDataLama()) {
    // Instalasi baru / salinan untuk rekan: profil pertama netral.
    const profile = {
      id: 'p_utama',
      nama: rapikanTeks(process.env.PEGAWAI_NAMA, 120) || 'Pegawai 1',
      nip: rapikanTeks(process.env.PEGAWAI_NIP, 40),
      jabatan: '',
      unitKerja: rapikanTeks(process.env.UNIT_KERJA, 120) || 'BPS Kabupaten/Kota',
      createdAt: sekarang,
      updatedAt: sekarang,
    };
    reg = { version: 1, profiles: [profile] };
    const store = profilStoreDari(profile);
    const tahun = new Date().getFullYear();
    store.write('config.json', {
      pegawai: profile.nip ? `[${profile.nip}] ${profile.nama}` : profile.nama,
      tahun: String(tahun), periode: '', wilayah: 'Belitung', unitKerja: profile.unitKerja,
      tahunData: tahun, bulanPeriode: '', sheetName: '',
    });
    store.write('rk-list.json', []);
    store.write('rk-keywords.json', []);
    store.write('kamus-singkatan.json', seedKamus);
    tulisRegistry(reg);
    return reg;
  }

  const lamaConfig = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'config.json'), {});
  const identitas = pecahPegawai(lamaConfig.pegawai);
  const nama = identitas.nama || 'Pegawai Utama';
  const nip = identitas.nip || '';
  const id = idProfilUnik(nama, nip, new Set());
  const profile = {
    id, nama, nip,
    jabatan: '',
    unitKerja: rapikanTeks(lamaConfig.unitKerja || '', 120),
    legacyData: true,
    createdAt: sekarang,
    updatedAt: sekarang,
  };
  reg = { version: 1, profiles: [profile] };
  const store = profilStoreDari(profile);
  const seedRk = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'rk-list.json'), []);
  const seedKunci = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'rk-keywords.json'), []);
  store.write('config.json', lamaConfig);
  store.write('rk-list.json', seedRk);
  store.write('kamus-singkatan.json', seedKamus);
  store.write('rk-keywords.json', seedKunci);
  if (boolEnv(process.env.RK_IMPORT_ONCE)) {
    // opsional: paksa daftar RK dari path tertentu saat migrasi
    const p = process.env.RK_IMPORT_ONCE;
    if (fs.existsSync(p)) {
      try {
        const isi = fs.readFileSync(p, 'utf8');
        const list = isi.split(/\r?\n/).map((x) => rapikanTeks(x, 300)).filter(Boolean);
        if (list.length) store.write('rk-list.json', [...new Set(list)]);
      } catch (e) { /* abaikan */ }
    }
  }
  tulisRegistry(reg);
  return reg;
}
function profilById(id) {
  const reg = pastikanProfil();
  return reg.profiles.find((p) => p.id === id) || reg.profiles[0];
}
// Peta RK per pegawai (hasil kompilasi Dataset RK + upload SIKAP).
// Dipakai untuk mengenali RK milik profil tanpa harus menarik SIKAP dulu.
function rkPegawaiUntuk(profile) {
  const nip = String((profile && profile.nip) || '').trim();
  const id = String((profile && profile.id) || '').trim();
  const daftar = Array.isArray(petaRkPegawai.pegawai) ? petaRkPegawai.pegawai : [];
  return daftar.find((p) => (nip && p.nip === nip) || (id && p.profileId === id)) || null;
}

// Bersihkan rk-list yang menumpuk (nama parent / sisa sync lama) dengan
// membandingkannya ke peta RK. Dijalankan saat start dan saat daftar dibaca.
// Penambahan manual yang bukan nama parent TIDAK dihapus.
function rekonsiliasiRkProfil(profile) {
  const peta = rkPegawaiUntuk(profile);
  if (!peta || !Array.isArray(peta.rks) || peta.rks.length === 0) return false;
  const store = profilStoreDari(profile);
  const daftar = [...new Set(peta.rks.map((r) => String(r.nama || '').trim()).filter(Boolean))];
  if (!daftar.length) return false;

  const lama = store.read('rk-list.json', []);
  if (!Array.isArray(lama) || lama.length === 0) return false;
  if (lama.length === daftar.length && lama.every((x, i) => x === daftar[i])) return false;

  const kunciPeta = new Set(daftar.map((x) => normalisasiNamaRk(x)));
  const kunciParent = new Set(
    peta.rks.map((r) => normalisasiNamaRk(r.parent)).filter(Boolean),
  );
  const adaNamaParent = lama.some(
    (x) => !kunciPeta.has(normalisasiNamaRk(x)) && kunciParent.has(normalisasiNamaRk(x)),
  );
  const jauhLebihPanjang = lama.length > daftar.length + 2;
  if (!adaNamaParent && !jauhLebihPanjang) return false;

  const file = path.join(store.dir, 'rk-list.json');
  const cadangan = path.join(store.dir, 'rk-list.sebelum-peta.json');
  try {
    if (fs.existsSync(file) && !fs.existsSync(cadangan)) fs.copyFileSync(file, cadangan);
  } catch (e) { /* abaikan */ }
  store.write('rk-list.json', daftar);
  return true;
}

function rekonsiliasiRkSemuaProfil() {
  try {
    const reg = pastikanProfil();
    let jumlah = 0;
    for (const profile of reg.profiles) {
      if (rekonsiliasiRkProfil(profile)) jumlah++;
    }
    if (jumlah) console.log(`[rk] ${jumlah} daftar RK profil dibersihkan/disamakan dengan peta RK.`);
  } catch (e) {
    console.error('[rk] gagal menyamakan daftar RK:', e.message);
  }
}
function resolveProfile(req) {
  const id = String(req.get('x-ckp-profile') || req.query.profile || '').trim();
  return profilById(id);
}
function networkUrls(port) {
  const urls = [];
  try {
    for (const daftar of Object.values(os.networkInterfaces())) {
      for (const it of daftar || []) {
        if (it.family === 'IPv4' && !it.internal) urls.push(`http://${it.address}:${port}`);
      }
    }
  } catch (e) { /* abaikan */ }
  return urls;
}
// Aman dari serangan path prefix (mis. C:\data\uploads-lain).
function diDalamFolder(target, folder) {
  const rel = path.relative(path.resolve(folder), path.resolve(target));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}
function ringkasProfil(profile) {
  const store = profilStoreDari(profile);
  const rk = store.read('rk-list.json', []);
  const kamus = store.read('kamus-singkatan.json', []);
  const kunci = store.read('rk-keywords.json', []);
  const config = store.read('config.json', {});
  let ekspor = 0;
  try { ekspor = fs.readdirSync(store.dirs.ckp).filter((f) => /\.xlsx$/i.test(f)).length; } catch (e) { /* abaikan */ }
  if (profile.legacyData) {
    try { ekspor += fs.readdirSync(LEGACY_CKP_DIR).filter((f) => /\.xlsx$/i.test(f)).length; } catch (e) { /* abaikan */ }
  }
  return {
    ...profile,
    remote: config.remote || '',
    driveFolder: config.driveFolder || '',
    jumlahRk: Array.isArray(rk) ? rk.length : 0,
    jumlahKamus: Array.isArray(kamus) ? kamus.length : 0,
    jumlahKunci: Array.isArray(kunci) ? kunci.length : 0,
    jumlahEkspor: ekspor,
  };
}

// ─── Dataset RK per pegawai ──────────────────────────────────────────────────
function bacaDatasetBundel() {
  return bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'rk-dataset.json'), { employees: [], teams: [] });
}
function bacaPegawaiPindah() {
  const arr = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'pegawai-pindah.json'), []);
  return new Set((Array.isArray(arr) ? arr : []).map((x) => String((x && x.nip) || x || '').trim()).filter(Boolean));
}
function gabungUnikRk(lama, baru) {
  const hasil = [];
  const seen = new Set();
  for (const rk of [...(Array.isArray(lama) ? lama : []), ...(Array.isArray(baru) ? baru : [])]) {
    const nama = rapikanTeks(rk, 300);
    const kunci = normalisasiNamaRk(nama);
    if (!kunci || seen.has(kunci)) continue;
    seen.add(kunci);
    hasil.push(nama);
  }
  return hasil;
}
function imporDatasetProfiles(dataset, { mode = 'ganti', nips = null } = {}) {
  const reg = pastikanProfil();
  const sekarang = new Date().toISOString();
  const daftarNip = Array.isArray(nips) && nips.length ? new Set(nips.map(String)) : null;
  const pindah = bacaPegawaiPindah();
  const seedKamus = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'kamus-singkatan.json'), []);
  const templateKunci = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'rk-keywords.json'), []);
  const hasil = [];

  for (const emp of Array.isArray(dataset.employees) ? dataset.employees : []) {
    const nip = String(emp.nip || '').trim();
    const nama = rapikanTeks(emp.nama, 120) || (nip ? `Pegawai ${nip}` : '');
    if (!nama || (daftarNip && !daftarNip.has(nip))) continue;
    // Jangan buat ulang profil pegawai yang sudah pindah saat impor semua.
    if (!daftarNip && nip && pindah.has(nip)) continue;

    let profile = reg.profiles.find((p) => nip && p.nip === nip);
    let baru = false;
    if (!profile) {
      const id = idProfilUnik(nama, nip, new Set(reg.profiles.map((p) => p.id)));
      profile = {
        id,
        nama,
        nip,
        jabatan: rapikanTeks(emp.jabatan, 120),
        unitKerja: 'BPS Kabupaten Belitung',
        teams: Array.isArray(emp.teams) ? emp.teams : [],
        ketuaTeams: Array.isArray(emp.ketuaTeams) ? emp.ketuaTeams : [],
        datasetAt: sekarang,
        datasetSource: dataset.source || '',
        createdAt: sekarang,
        updatedAt: sekarang,
      };
      reg.profiles.push(profile);
      baru = true;
    } else {
      profile.nama = nama || profile.nama;
      profile.nip = nip || profile.nip;
      profile.jabatan = rapikanTeks(emp.jabatan, 120) || profile.jabatan;
      profile.teams = Array.isArray(emp.teams) ? emp.teams : (profile.teams || []);
      profile.ketuaTeams = Array.isArray(emp.ketuaTeams) ? emp.ketuaTeams : (profile.ketuaTeams || []);
      profile.datasetAt = sekarang;
      profile.datasetSource = dataset.source || profile.datasetSource || '';
      profile.updatedAt = sekarang;
    }

    const store = profilStoreDari(profile);
    const tahun = new Date().getFullYear();
    const config = store.read('config.json', {});
    config.pegawai = nip ? `[${nip}] ${nama}` : nama;
    if (!config.unitKerja) config.unitKerja = profile.unitKerja || 'BPS Kabupaten Belitung';
    if (!config.tahun) config.tahun = String(tahun);
    if (!config.tahunData) config.tahunData = tahun;
    if (!config.wilayah) config.wilayah = 'Belitung';
    store.write('config.json', config);

    const lamaRk = store.read('rk-list.json', []);
    const rkBaru = mode === 'gabung'
      ? gabungUnikRk(lamaRk, emp.rks)
      : gabungUnikRk([], emp.rks);
    store.write('rk-list.json', rkBaru);

    // Kata kunci: pertahankan yang sudah ada, tambahkan template yang RK-nya
    // benar-benar ada di daftar pegawai ini.
    const kunciLama = store.read('rk-keywords.json', []);
    const kunciHasil = Array.isArray(kunciLama) ? [...kunciLama] : [];
    const kunciAda = new Set(kunciHasil.map((r) => normalisasiNamaRk(r && r.rk)));
    const rkAda = new Set(rkBaru.map(normalisasiNamaRk));
    for (const aturan of Array.isArray(templateKunci) ? templateKunci : []) {
      const kunci = normalisasiNamaRk(aturan && aturan.rk);
      if (!kunci || kunciAda.has(kunci) || !rkAda.has(kunci)) continue;
      kunciAda.add(kunci);
      kunciHasil.push(aturan);
    }
    store.write('rk-keywords.json', kunciHasil);

    const kamus = store.read('kamus-singkatan.json', []);
    if (!Array.isArray(kamus) || kamus.length === 0) store.write('kamus-singkatan.json', seedKamus);

    hasil.push({
      id: profile.id,
      nip: profile.nip,
      nama: profile.nama,
      baru,
      jumlahRk: rkBaru.length,
    });
  }

  // Saat impor semua di instalasi baru, buang profil default "Pegawai 1"
  // yang masih kosong agar daftar tidak berisi profil hantu.
  if (!daftarNip) {
    const idxKosong = reg.profiles.findIndex((p) => p.id === 'p_utama' && /^Pegawai 1$/i.test(p.nama));
    if (idxKosong >= 0 && reg.profiles.length > 1) {
      const p = reg.profiles[idxKosong];
      const st = profilStoreDari(p);
      const rk = st.read('rk-list.json', []);
      const sikap = st.read('sikap-integration.json', {});
      let adaHasil = false;
      try { adaHasil = fs.readdirSync(st.dirs.ckp).some((f) => /\.xlsx$/i.test(f)); } catch (e) { /* abaikan */ }
      if ((!Array.isArray(rk) || rk.length === 0) && !adaHasil && !sikap.token) {
        reg.profiles.splice(idxKosong, 1);
        try { fs.rmSync(st.dir, { recursive: true, force: true }); } catch (e) { /* abaikan */ }
      }
    }
  }

  tulisRegistry(reg);
  return {
    hasil,
    profiles: reg.profiles.map(ringkasProfil),
  };
}


app.use(express.json({ limit: '10mb' }));
// Health check khusus CKP: dipakai launcher untuk memastikan port 3230 benar
// benar aplikasi ini (bukan aplikasi lain yang kebetulan memakai port sama).
app.get('/api/health', (req, res) => {
  res.json({ app: 'ckp', ok: true, port: Number(PORT), versi: bacaVersi(), uptime: Math.round(process.uptime()) });
});

// ─── Update aplikasi ────────────────────────────────────────────────────────
// Cek manifest update (update-source.txt → update.json). Tidak pernah menulis
// apa pun; hanya membaca.
app.get('/api/system/version', async (req, res) => {
  const versi = bacaVersi();
  let manifest = null;
  let error = '';
  try {
    manifest = await bacaManifestUpdate();
  } catch (e) {
    error = e.message;
  }
  const terbaru = (manifest && manifest.versi) || '';
  res.json({
    success: true,
    versi,
    terbaru,
    adaUpdate: Boolean(terbaru && bandingVersi(terbaru, versi) > 0),
    catatan: (manifest && manifest.catatan) || '',
    tanggal: (manifest && manifest.tanggal) || '',
    sumber: (manifest && manifest.sumber) || bacaSumberUpdate(),
    error,
  });
});

// Jalankan updater (PowerShell) yang menghentikan server, membackup kode,
// mengekstrak paket baru tanpa menyentuh data/, lalu menyalakan ulang server.
app.post('/api/system/update', async (req, res) => {
  try {
    if (updateSedangJalan) {
      return res.status(409).json({ success: false, error: 'Update sedang berjalan.' });
    }
    const ps = path.join(ROOT, 'scripts', 'update-ckp.ps1');
    if (!fs.existsSync(ps)) {
      return res.status(500).json({
        success: false,
        error: 'Updater belum ada di perangkat ini. Jalankan "Update CKP.bat" (atau ekstrak CKP-Updater.zip) sekali.',
      });
    }
    const manifest = await bacaManifestUpdate();
    if (!manifest || !manifest.url) {
      return res.status(400).json({
        success: false,
        error: 'Sumber update belum diatur. Isi update-source.txt dengan alamat update.json.',
      });
    }
    const lokal = bacaVersi();
    if (manifest.versi && bandingVersi(manifest.versi, lokal) <= 0) {
      return res.json({ success: true, sudahTerbaru: true, versi: lokal });
    }

    updateSedangJalan = true;
    res.json({ success: true, mulai: true, dari: lokal, ke: manifest.versi || '' });
    // Beri waktu respons terkirim sebelum server dihentikan oleh updater.
    setTimeout(() => {
      try {
        const child = spawn('powershell.exe', [
          '-NoProfile', '-ExecutionPolicy', 'Bypass',
          '-File', ps,
          '-Source', manifest.url,
          '-Port', String(PORT),
          '-Root', ROOT,
        ], { detached: true, stdio: 'ignore', windowsHide: true });
        child.unref();
      } catch (e) {
        console.error('[update] gagal menjalankan updater:', e.message);
        updateSedangJalan = false;
      }
    }, 700);
  } catch (e) {
    updateSedangJalan = false;
    res.status(500).json({ success: false, error: e.message });
  }
});
app.use(express.static(path.join(ROOT, 'public'), {
  setHeaders(res, filePath) {
    // index.html jangan di-cache agar update UI langsung terpakai; aset
    // ber-hash boleh di-cache lama supaya halaman terbuka lebih cepat.
    if (/\.html?$/i.test(filePath)) res.setHeader('Cache-Control', 'no-cache');
    else res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
  },
}));

// Setiap request API otomatis terkait satu profil (header X-CKP-Profile).
app.use((req, res, next) => {
  req.profile = resolveProfile(req);
  req.store = profilStoreDari(req.profile);
  next();
});

// Daftar RK milik pegawai aktif — hasil kompilasi Dataset RK + upload SIKAP.
// Berguna saat token SIKAP belum diatur / untuk menampilkan RK yang memang milik
// pegawai ini saja.
app.get('/api/rk-pegawai', (req, res) => {
  const p = rkPegawaiUntuk(req.profile);
  if (!p) return res.json({ success: true, pegawai: null, rk: [] });
  res.json({
    success: true,
    pegawai: { nip: p.nip, nama: p.nama, nipSikap: p.nipSikap, profileId: p.profileId },
    rk: (p.rks || []).map((r) => ({
      nama: r.nama,
      parent: r.parent,
      jenis: r.jenis,
      sumber: r.sumber,
      baru: Boolean(r.baru),
      terdaftarDiSikap: Boolean(r.terdaftarSendiri || r.terdaftarGlobal),
    })),
  });
});

// Upload ZIP dari browser → simpan ke folder profil aktif.
const upload = multer({
  storage: multer.diskStorage({
    destination(req, file, cb) {
      try { fs.mkdirSync(req.store.dirs.uploads, { recursive: true }); cb(null, req.store.dirs.uploads); }
      catch (e) { cb(e); }
    },
    filename(req, file, cb) { cb(null, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`); },
  }),
  limits: { fileSize: (parseInt(process.env.MAX_ZIP_MB, 10) || 1500) * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (/\.zip$/i.test(file.originalname)) cb(null, true);
    else cb(new Error('Hanya file .zip yang diterima.'));
  },
});

// ─── rclone ───────────────────────────────────────────────────────────────────
function findRclone() {
  if (process.env.RCLONE_EXE && fs.existsSync(process.env.RCLONE_EXE)) {
    return process.env.RCLONE_EXE;
  }
  const candidates = [
    path.join(ROOT, 'tools', 'rclone', 'rclone.exe'),
    path.join(ROOT, 'tools', 'rclone.exe'),
    path.join(ROOT, '..', 'Bukti Dukung', 'rclone-v1.75.0-windows-amd64', 'rclone.exe'),
    path.join(ROOT, '..', 'Bukti Dukung', 'rclone.exe'),
  ];
  for (const c of candidates) if (fs.existsSync(c)) return c;
  return 'rclone'; // fallback: PATH sistem
}
const RCLONE_EXE = findRclone();

function runRclone(args, options = {}) {
  return new Promise((resolve) => {
    const proc = spawn(RCLONE_EXE, args, { windowsHide: true, ...options });
    let stdout = '';
    let stderr = '';
    proc.stdout?.on('data', (d) => { stdout += d.toString(); });
    proc.stderr?.on('data', (d) => { stderr += d.toString(); });
    proc.on('close', (code) => resolve({ code, stdout, stderr }));
    proc.on('error', (err) => resolve({ code: -1, stdout, stderr: err.message }));
  });
}

function cleanRcloneError(stderrText) {
  if (!stderrText) return 'Tidak ada pesan error';
  const lines = stderrText.split('\n')
    .map((l) => l.trim()
      // Buang prefiks log rclone: "2026/10/30 08:00:00 ERROR : ..."
      .replace(/^\d{4}\/\d{2}\/\d{2}\s+\d{2}:\d{2}:\d{2}\s+(?:ERROR|CRITICAL|NOTICE|INFO)\s*:\s*/i, ''))
    .filter((l) => l && !l.includes('NOTICE: gdrive') && !l.includes('Dangling shortcut'));
  const cleaned = lines.join(' ').trim();
  if (!cleaned) return 'Google Drive Rate Limit / koneksi terputus sesaat';
  if (cleaned.includes('rateLimitExceeded') || cleaned.includes('userRateLimit') || cleaned.includes('403')) {
    return 'Google Drive Rate Limit (terlalu banyak request). Coba ulang kembali.';
  }
  return cleaned;
}

// ─── Config / RK / Kamus (JSON per profil) ──────────────────────────────────

// ─── SSE (dipisah per profil agar unggahan rekan tidak tercampur) ────────────
// Setiap profil punya satu job upload. Status lengkapnya disimpan di
// job.state, jadi browser yang terlambat menyambung (atau reload di tengah
// proses) langsung menerima snapshot progres — bukan menunggu event berikutnya.
const uploadJobs = new Map();
let sseClients = [];
const JOB_KEEP_MS = 10 * 60 * 1000; // hasil upload tetap bisa dilihat 10 menit

function ssePayload(event, data) {
  return data === undefined
    ? `event: ${event}\n\n`
    : `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
}
function sendSSE(profileId, event, data) {
  const payload = ssePayload(event, data);
  sseClients.forEach((client) => {
    if (client.profileId !== profileId) return;
    try { client.res.write(payload); } catch (e) { /* client dropped */ }
  });
}
function jobBaru() {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    isRunning: true,
    isCancelled: false,
    proc: null,
    state: null,
    createdAt: Date.now(),
    finishedAt: 0,
  };
}
function publikasikanState(job) {
  if (job && job.state) job.state.running = !!job.isRunning;
}
// Hentikan job karena kesalahan yang tidak bisa dilanjutkan. Status disimpan
// agar browser yang terlambat menyambung tetap tahu upload gagal (tidak
// menggantung di "sedang mengunggah").
function gagalkanJob(job, profileId, message) {
  job.error = message;
  job.isRunning = false;
  if (job.state) {
    job.state.done = true;
    job.state.running = false;
    job.state.error = message;
  }
  sendSSE(profileId, 'fatal', { message });
}

// ═══════════════════════════ API ═══════════════════════════════════════════

// 1. Status sistem
app.get('/api/system/status', async (req, res) => {
  try {
    const versionRes = await runRclone(['version']);
    const isReady = versionRes.code === 0;
    let remotes = [];
    if (isReady) {
      const remotesRes = await runRclone(['listremotes']);
      if (remotesRes.code === 0) {
        remotes = remotesRes.stdout.split('\n').map((l) => l.trim().replace(/:$/, '')).filter(Boolean);
      }
    }
    const config = req.store.read('config.json', {});
    const remoteDisimpan = String(config.remote || '').trim();
    const defaultRemote = remotes.includes(remoteDisimpan)
      ? remoteDisimpan
      : (remotes.includes('gdrive') ? 'gdrive' : (remotes[0] || ''));
    res.json({
      success: true,
      rcloneReady: isReady,
      rclonePath: RCLONE_EXE,
      version: (versionRes.stdout || '').split('\n')[0] || 'Unknown',
      remotes,
      defaultRemote,
      maxZipMB: parseInt(process.env.MAX_ZIP_MB, 10) || 1500,
      config,
      profile: ringkasProfil(req.profile),
      profiles: pastikanProfil().profiles.map(ringkasProfil),
      networkUrls: networkUrls(PORT),
      port: Number(PORT),
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── Profil pegawai ──────────────────────────────────────────────────────────
app.get('/api/profiles', (req, res) => {
  const reg = pastikanProfil();
  res.json({
    success: true,
    profiles: reg.profiles.map(ringkasProfil),
    aktif: req.profile.id,
    networkUrls: networkUrls(PORT),
    port: Number(PORT),
  });
});

function buatProfilBaru({ nama, nip, jabatan, unitKerja, remote, driveFolder, template, copyFrom }) {
  const reg = pastikanProfil();
  const namaBersih = rapikanTeks(nama, 120);
  if (!namaBersih) throw new Error('Nama pegawai tidak boleh kosong.');
  const nipBersih = rapikanTeks(nip, 40);
  const terpakai = new Set(reg.profiles.map((p) => p.id));
  const id = idProfilUnik(namaBersih, nipBersih, terpakai);
  const sekarang = new Date().toISOString();
  const profile = {
    id,
    nama: namaBersih,
    nip: nipBersih,
    jabatan: rapikanTeks(jabatan, 120),
    unitKerja: rapikanTeks(unitKerja, 120),
    createdAt: sekarang,
    updatedAt: sekarang,
  };
  const store = profilStoreDari(profile);
  const salin = template === 'salin' ? profilStoreDari(profilById(copyFrom || '')) : null;
  const tahun = new Date().getFullYear();
  const configSumber = salin ? salin.read('config.json', {}) : {};
  const config = {
    ...configSumber,
    pegawai: nipBersih ? `[${nipBersih}] ${namaBersih}` : namaBersih,
    unitKerja: profile.unitKerja || configSumber.unitKerja || '',
    tahun: String(configSumber.tahun || tahun),
    tahunData: Number(configSumber.tahunData) || tahun,
    bulanPeriode: configSumber.bulanPeriode || '',
    periode: configSumber.periode || '',
    sheetName: configSumber.sheetName || '',
    remote: rapikanTeks(remote, 60) || rapikanTeks(configSumber.remote, 60) || '',
    driveFolder: rapikanTeks(driveFolder, 200) || rapikanTeks(configSumber.driveFolder, 200) || '',
  };
  if (!config.wilayah) config.wilayah = 'Belitung';
  const seedKamus = bacaJsonAbsolut(path.join(CONFIG_SEED_DIR, 'kamus-singkatan.json'), []);
  // Profil baru langsung mengenal RK milik pegawai (jika ada di peta RK).
  const peta = rkPegawaiUntuk(profile);
  const rkAwal = peta ? [...new Set(peta.rks.map((r) => r.nama).filter(Boolean))] : [];
  store.write('config.json', config);
  store.write('rk-list.json', salin ? salin.read('rk-list.json', []) : rkAwal);
  store.write('rk-keywords.json', salin ? salin.read('rk-keywords.json', []) : []);
  store.write('kamus-singkatan.json', salin ? salin.read('kamus-singkatan.json', seedKamus) : seedKamus);
  reg.profiles.push(profile);
  tulisRegistry(reg);
  return { profile, store };
}

app.post('/api/profiles', (req, res) => {
  try {
    const b = req.body || {};
    const { profile } = buatProfilBaru({
      nama: b.nama, nip: b.nip, jabatan: b.jabatan, unitKerja: b.unitKerja,
      remote: b.remote, driveFolder: b.driveFolder,
      template: b.template, copyFrom: b.copyFrom || req.profile.id,
    });
    res.json({ success: true, profile: ringkasProfil(profile) });
  } catch (e) { res.status(400).json({ success: false, error: e.message }); }
});

app.put('/api/profiles/:id', (req, res) => {
  try {
    const reg = pastikanProfil();
    const profile = reg.profiles.find((p) => p.id === req.params.id);
    if (!profile) return res.status(404).json({ success: false, error: 'Profil tidak ditemukan.' });
    const b = req.body || {};
    const namaLama = profile.nama;
    const nipLama = profile.nip;
    if (b.nama !== undefined) profile.nama = rapikanTeks(b.nama, 120) || profile.nama;
    if (b.nip !== undefined) profile.nip = rapikanTeks(b.nip, 40);
    if (b.jabatan !== undefined) profile.jabatan = rapikanTeks(b.jabatan, 120);
    if (b.unitKerja !== undefined) profile.unitKerja = rapikanTeks(b.unitKerja, 120);
    profile.updatedAt = new Date().toISOString();
    const store = profilStoreDari(profile);
    const config = store.read('config.json', {});
    const pegawaiLama = String(config.pegawai || '');
    const otomatis = !pegawaiLama || /^\[[^\]]+\]\s*/.test(pegawaiLama) || pegawaiLama === namaLama;
    if (b.pegawai !== undefined) config.pegawai = String(b.pegawai || '').trim();
    else if (otomatis && (profile.nama !== namaLama || profile.nip !== nipLama)) {
      config.pegawai = profile.nip ? `[${profile.nip}] ${profile.nama}` : profile.nama;
    }
    if (b.unitKerja !== undefined) config.unitKerja = profile.unitKerja;
    if (b.remote !== undefined) config.remote = rapikanTeks(b.remote, 60);
    if (b.driveFolder !== undefined) config.driveFolder = rapikanTeks(b.driveFolder, 200);
    store.write('config.json', config);
    tulisRegistry(reg);
    res.json({ success: true, profile: ringkasProfil(profile) });
  } catch (e) { res.status(400).json({ success: false, error: e.message }); }
});

app.post('/api/profiles/:id/duplicate', (req, res) => {
  try {
    const sumber = profilById(req.params.id);
    if (!sumber) return res.status(404).json({ success: false, error: 'Profil tidak ditemukan.' });
    const b = req.body || {};
    const { profile } = buatProfilBaru({
      nama: rapikanTeks(b.nama, 120) || `${sumber.nama} (salinan)`,
      nip: b.nip !== undefined ? b.nip : sumber.nip,
      jabatan: sumber.jabatan,
      unitKerja: sumber.unitKerja,
      template: 'salin',
      copyFrom: sumber.id,
    });
    res.json({ success: true, profile: ringkasProfil(profile) });
  } catch (e) { res.status(400).json({ success: false, error: e.message }); }
});

app.delete('/api/profiles/:id', (req, res) => {
  try {
    const reg = pastikanProfil();
    if (reg.profiles.length <= 1) {
      return res.status(400).json({ success: false, error: 'Minimal harus ada satu profil pegawai.' });
    }
    const idx = reg.profiles.findIndex((p) => p.id === req.params.id);
    if (idx < 0) return res.status(404).json({ success: false, error: 'Profil tidak ditemukan.' });
    const [dihapus] = reg.profiles.splice(idx, 1);
    tulisRegistry(reg);
    try { fs.rmSync(path.join(PROFILES_DIR, dihapus.id), { recursive: true, force: true }); } catch (e) { /* abaikan */ }
    res.json({ success: true, dihapus: dihapus.id });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.get('/api/profiles/:id/bundle', (req, res) => {
  try {
    const profile = profilById(req.params.id);
    if (!profile) return res.status(404).json({ success: false, error: 'Profil tidak ditemukan.' });
    const store = profilStoreDari(profile);
    res.json({
      success: true,
      bundle: {
        format: 'ckp-profile',
        version: 1,
        profile: {
          nama: profile.nama, nip: profile.nip, jabatan: profile.jabatan, unitKerja: profile.unitKerja,
        },
        config: store.read('config.json', {}),
        rk: store.read('rk-list.json', []),
        kamus: store.read('kamus-singkatan.json', []),
        kunci: store.read('rk-keywords.json', []),
      },
    });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

app.post('/api/profiles/import', (req, res) => {
  try {
    const bundle = (req.body && (req.body.bundle || req.body)) || {};
    const p = bundle.profile || bundle;
    if (!p || !p.nama) throw new Error('File profil tidak memuat nama pegawai.');
    const { profile } = buatProfilBaru({
      nama: p.nama, nip: p.nip, jabatan: p.jabatan, unitKerja: p.unitKerja,
      template: 'kosong',
    });
    const store = profilStoreDari(profile);
    if (bundle.config && typeof bundle.config === 'object') {
      store.write('config.json', {
        ...bundle.config,
        pegawai: profile.nip ? `[${profile.nip}] ${profile.nama}` : profile.nama,
        unitKerja: profile.unitKerja || bundle.config.unitKerja || '',
      });
    }
    if (Array.isArray(bundle.rk)) store.write('rk-list.json', bersihkanDaftarRK(bundle.rk));
    if (Array.isArray(bundle.kamus)) store.write('kamus-singkatan.json', bundle.kamus);
    if (Array.isArray(bundle.kunci)) store.write('rk-keywords.json', bersihkanAturanKunci(bundle.kunci));
    res.json({ success: true, profile: ringkasProfil(profile) });
  } catch (e) { res.status(400).json({ success: false, error: e.message }); }
});

// 2. Upload ZIP dari browser (multipart) + langsung inspect
app.post('/api/zip/upload', upload.single('zip'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, error: 'File ZIP tidak diterima.' });
    const ext = path.extname(req.file.originalname);
    const stem = path.basename(req.file.originalname, ext);
    const safeStem = stem.replace(/[\\/:*?"<>|]/g, ' ').trim().slice(0, 80) || 'upload';
    const finalPath = path.join(req.store.dirs.uploads, `${Date.now()}_${safeStem}.zip`);
    fs.renameSync(req.file.path, finalPath);
    const hasil = inspectZip(finalPath);
    if (!hasil.valid) {
      // tetap kembalikan path agar user bisa ganti file; file sampah dibiarkan (kecil)
      return res.json({ success: true, zipPath: finalPath, zipName: safeStem, ...hasil });
    }
    res.json({ success: true, zipPath: finalPath, zipName: safeStem, ...hasil });
  } catch (err) {
    res.status(500).json({ success: false, error: `Gagal membaca ZIP: ${err.message}` });
  }
});

// 2b. Inspect ZIP dari path server (untuk file yang sudah ada)
app.post('/api/zip/inspect', (req, res) => {
  const { zipPath } = req.body || {};
  if (!zipPath || !fs.existsSync(zipPath)) {
    return res.status(400).json({ success: false, error: 'File ZIP tidak ditemukan.' });
  }
  try {
    res.json({ success: true, zipPath, ...inspectZip(zipPath) });
  } catch (err) {
    res.status(500).json({ success: false, error: `Gagal membaca ZIP: ${err.message}` });
  }
});

// Nama file yang aman untuk disk Windows + Google Drive. ZIP dari komputer lain
// kadang memuat karakter seperti : ? * atau nama sangat panjang; tanpa
// pembersihan, ekstraksi bisa gagal dan seluruh upload ikut berhenti.
function namaDriveAman(nama) {
  let n = String(nama || '')
    .replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/[. ]+$/g, '');
  if (!n) n = 'berkas';
  if (n.length > 180) {
    const ext = path.extname(n).slice(0, 12);
    n = n.slice(0, 180 - ext.length) + ext;
  }
  return n;
}

// Satu sumber kebenaran untuk daftar berkas ZIP: dipakai saat pratinjau
// (inspectZip) dan saat upload, supaya id/nama di Drive selalu sama.
function susunBerkasZip(entries) {
  const valid = [];
  const nameCounts = {};
  for (const entry of entries) {
    if (entry.isDirectory) continue;
    const cleanName = entry.entryName.replace(/\\/g, '/');
    const parts = cleanName.split('/');
    if (parts.some((p) => p.startsWith('.') || p === '__MACOSX')) continue;
    const baseName = parts[parts.length - 1];
    if (['thumbs.db', 'desktop.ini'].includes(baseName.toLowerCase())) continue;
    const ext = path.extname(baseName).toLowerCase();
    if (!SUPPORTED_EXTENSIONS.has(ext)) continue;
    // Bandingkan tanpa beda huruf besar/kecil: Windows & Drive bisa bentrok.
    const kunciNama = baseName.toLowerCase();
    nameCounts[kunciNama] = (nameCounts[kunciNama] || 0) + 1;
    valid.push({
      entry,
      entryName: entry.entryName,
      originalName: baseName,
      relativePath: cleanName,
      ext,
      size: entry.header.size,
      isPhoto: PHOTO_EXTENSIONS.has(ext),
      isDoc: DOC_EXTENSIONS.has(ext),
    });
  }

  valid.sort((a, b) => a.originalName.localeCompare(b.originalName, undefined, { numeric: true, sensitivity: 'base' }));

  const dipakai = new Set();
  return valid.map((item, index) => {
    let driveName = item.originalName;
    if (nameCounts[item.originalName.toLowerCase()] > 1) {
      const parentDir = path.dirname(item.relativePath);
      const prefix = parentDir && parentDir !== '.' ? parentDir.replace(/\//g, '_') : 'root';
      driveName = `${prefix}__${item.originalName}`;
    }
    driveName = namaDriveAman(driveName);
    if (dipakai.has(driveName.toLowerCase())) {
      const ext = path.extname(driveName);
      const stem = driveName.slice(0, driveName.length - ext.length);
      let n = 2;
      while (dipakai.has(`${stem}_${n}${ext}`.toLowerCase())) n++;
      driveName = `${stem}_${n}${ext}`;
    }
    dipakai.add(driveName.toLowerCase());
    return { id: index, ...item, driveName };
  });
}

function inspectZip(zipPath) {
  const zip = new AdmZip(zipPath);
  // `entry` hanya dipakai internal proses upload; jangan ikut dikirim ke browser.
  const files = susunBerkasZip(zip.getEntries()).map(({ entry, ...sisa }) => sisa);
  if (files.length === 0) {
    return { valid: false, message: 'Tidak ditemukan foto/dokumen yang didukung di dalam ZIP.', files: [] };
  }
  const baseStem = path.basename(zipPath, path.extname(zipPath)).replace(/^\d+_/, '');
  return {
    valid: true,
    totalFiles: files.length,
    photosCount: files.filter((f) => f.isPhoto).length,
    docsCount: files.filter((f) => f.isDoc).length,
    totalBytes: files.reduce((a, f) => a + f.size, 0),
    suggestedFolder: `CKP ${baseStem}`,
    files,
  };
}

// 2c. Thumbnail / pratinjau isi ZIP (tanpa ekstrak permanen)
const zipCache = new Map();
const ZIP_CACHE_MAX_BYTES = 96 * 1024 * 1024;
// Tanpa cache, setiap thumbnail membuka & membaca ulang seluruh ZIP dari disk
// (ratusan kali untuk satu ZIP) — ini yang membuat pratinjau terasa lambat.
function bukaZipCached(filePath) {
  const resolved = path.resolve(filePath);
  let stat = null;
  try { stat = fs.statSync(resolved); } catch (e) { return new AdmZip(resolved); }
  const hit = zipCache.get(resolved);
  if (hit && hit.mtimeMs === stat.mtimeMs && hit.size === stat.size) {
    zipCache.delete(resolved); // sentuh agar jadi paling akhir (LRU)
    zipCache.set(resolved, hit);
    return hit.zip;
  }
  const zip = new AdmZip(resolved);
  if (stat.size <= ZIP_CACHE_MAX_BYTES) {
    zipCache.set(resolved, { mtimeMs: stat.mtimeMs, size: stat.size, zip });
    let total = 0;
    for (const v of zipCache.values()) total += v.size;
    while (total > ZIP_CACHE_MAX_BYTES * 2 && zipCache.size > 1) {
      const oldest = zipCache.keys().next().value;
      total -= zipCache.get(oldest).size;
      zipCache.delete(oldest);
    }
  }
  return zip;
}

app.get('/api/zip/file', (req, res) => {
  try {
    const zipPath = req.query.zipPath;
    const entryName = req.query.entry;
    if (!zipPath || !entryName) return res.status(400).send('Parameter kurang.');
    const resolved = path.resolve(zipPath);
    const allowed = [req.store.dirs.uploads, ...(req.profile.legacyData ? [LEGACY_UPLOAD_DIR] : [])];
    if (!allowed.some((d) => diDalamFolder(resolved, d))) return res.status(403).send('Akses ditolak.');
    if (!fs.existsSync(resolved)) return res.status(404).send('ZIP tidak ditemukan.');
    const zip = bukaZipCached(resolved);
    const entry = zip.getEntry(entryName);
    if (!entry || entry.isDirectory) return res.status(404).send('Berkas tidak ada di ZIP.');
    const ext = path.extname(entryName).toLowerCase();
    const MIME = {
      '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
      '.webp': 'image/webp', '.heic': 'image/heic', '.pdf': 'application/pdf',
    };
    if (MIME[ext]) res.setHeader('Content-Type', MIME[ext]);
    res.send(entry.getData());
  } catch (e) {
    res.status(500).send('Gagal membaca berkas: ' + e.message);
  }
});

// 3. Daftar folder Google Drive
app.get('/api/drive/folders', async (req, res) => {
  const remote = req.query.remote || 'gdrive';
  const folderPath = req.query.path || '';
  const target = folderPath ? `${remote}:${folderPath}` : `${remote}:`;
  try {
    const listRes = await runRclone([
      'lsf', target, '--dirs-only', '--max-depth', '1',
      '--drive-skip-shortcuts', '--drive-skip-dangling-shortcuts',
      '--drive-pacer-min-sleep', '10ms', '--drive-pacer-burst', '100',
    ]);
    if (listRes.code !== 0) {
      return res.status(500).json({ success: false, error: cleanRcloneError(listRes.stderr) });
    }
    const folders = listRes.stdout.split('\n').map((l) => l.trim().replace(/\/$/, '')).filter(Boolean).sort();
    res.json({ success: true, folders, currentPath: folderPath });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 4. Buat folder Drive
app.post('/api/drive/create-folder', async (req, res) => {
  const { remote = 'gdrive', parentPath = '', folderName } = req.body || {};
  if (!folderName || !folderName.trim()) {
    return res.status(400).json({ success: false, error: 'Nama folder tidak boleh kosong.' });
  }
  const cleanParent = String(parentPath).replace(/\\/g, '/').replace(/^\/+|\/+$/g, '');
  const target = cleanParent ? `${remote}:${cleanParent}/${folderName.trim()}` : `${remote}:${folderName.trim()}`;
  try {
    const mkdirRes = await runRclone(['mkdir', target]);
    if (mkdirRes.code !== 0) {
      return res.status(500).json({ success: false, error: cleanRcloneError(mkdirRes.stderr) });
    }
    res.json({ success: true, created: folderName.trim() });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. SSE stream progress (hanya event milik profil ini)
app.get('/api/upload/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();
  res.write('retry: 3000\n\n');
  const clientId = Date.now() + Math.random();
  const newClient = { id: clientId, res, profileId: req.profile.id };
  sseClients.push(newClient);

  // Kirim snapshot progres terkini. Ini menutup celah balapan: proses upload
  // bisa saja sudah mengirim "init" sebelum EventSource di browser tersambung.
  const job = uploadJobs.get(req.profile.id);
  if (job && job.state) {
    publikasikanState(job);
    try {
      res.write(ssePayload('snapshot', { jobId: job.id, running: !!job.isRunning, state: job.state }));
    } catch (e) { /* abaikan */ }
  }

  // Heartbeat agar koneksi tidak diputus proxy/browser saat upload lama sepi.
  const heartbeat = setInterval(() => {
    try { res.write(': ping\n\n'); } catch (e) { /* abaikan */ }
  }, 20000);
  if (heartbeat.unref) heartbeat.unref();
  req.on('close', () => {
    clearInterval(heartbeat);
    sseClients = sseClients.filter((c) => c.id !== clientId);
  });
});

// 5b. Status upload terakhir/aktif — jaring pengaman bila SSE terhalang
// extension browser atau koneksi sempat putus.
app.get('/api/upload/status', (req, res) => {
  const job = uploadJobs.get(req.profile.id);
  publikasikanState(job);
  res.json({
    success: true,
    running: !!(job && job.isRunning),
    jobId: job ? job.id : '',
    error: job ? (job.error || '') : '',
    state: job ? job.state : null,
  });
});

// 6. Mulai / retry upload
app.post('/api/upload/start', async (req, res) => {
  const b = req.body || {};
  const zipPath = b.zipPath;
  const config = req.store.read('config.json', {});
  const remote = String(b.remote || config.remote || 'gdrive').trim();
  const driveFolder = String(b.driveFolder || '').trim();
  const parallel = b.parallel ?? 8;
  const filterIds = b.filterIds || null;
  if (!zipPath || !fs.existsSync(zipPath)) {
    return res.status(400).json({ success: false, error: 'Berkas ZIP tidak valid.' });
  }
  const zipDiizinkan = [req.store.dirs.uploads, ...(req.profile.legacyData ? [LEGACY_UPLOAD_DIR] : [])]
    .some((d) => diDalamFolder(zipPath, d));
  if (!zipDiizinkan) {
    return res.status(403).json({ success: false, error: 'ZIP bukan milik profil ini. Unggah ulang ZIP di halaman Upload.' });
  }
  if (!driveFolder) {
    return res.status(400).json({ success: false, error: 'Nama folder tujuan Google Drive harus diisi.' });
  }
  if (!/^[A-Za-z0-9_.-]+$/.test(remote)) {
    return res.status(400).json({ success: false, error: 'Nama remote rclone tidak valid.' });
  }
  const jobLama = uploadJobs.get(req.profile.id);
  if (jobLama && jobLama.isRunning) {
    return res.status(409).json({ success: false, error: 'Proses upload lain sedang berjalan untuk profil ini.' });
  }
  const targetDrivePath = `${remote}:${driveFolder.replace(/\\/g, '/').replace(/^\/+|\/+$/g, '')}`;
  const job = jobBaru();
  // State awal supaya browser yang tersambung sangat cepat (sebelum ZIP selesai
  // dibaca) tetap menerima sesuatu, dan error awal tetap bisa ditampilkan.
  job.state = {
    jobId: job.id, folder: driveFolder, parallel, total: 0, completed: 0,
    percent: 0, running: true, done: false, items: [], result: null, error: '',
  };
  uploadJobs.set(req.profile.id, job);
  res.json({ success: true, message: 'Upload dimulai.', jobId: job.id });
  runUploadProcess({
    zipPath,
    remote,
    driveFolder: driveFolder.replace(/\\/g, '/').replace(/^\/+|\/+$/g, ''),
    targetDrivePath,
    parallel: Math.max(1, Math.min(32, parallel)),
    filterIds,
    job,
    profile: req.profile,
    store: req.store,
  }).catch((err) => {
    // Jangan biarkan UI menggantung "sedang mengunggah" bila ada error tak terduga.
    gagalkanJob(job, req.profile.id, err && err.message ? err.message : String(err));
  }).finally(() => {
    job.isRunning = false;
    job.finishedAt = Date.now();
    publikasikanState(job);
    const timer = setTimeout(() => {
      if (uploadJobs.get(req.profile.id) === job && !job.isRunning) uploadJobs.delete(req.profile.id);
    }, JOB_KEEP_MS);
    if (timer.unref) timer.unref();
  });
});

// 7. Batalkan upload
app.post('/api/upload/cancel', (req, res) => {
  const job = uploadJobs.get(req.profile.id);
  if (job && job.isRunning) {
    job.isCancelled = true;
    try { job.proc?.kill(); } catch (e) { /* abaikan */ }
    sendSSE(req.profile.id, 'log', { message: 'Membatalkan proses upload…', level: 'warn' });
    return res.json({ success: true, message: 'Permintaan pembatalan dikirim.' });
  }
  res.json({ success: false, message: 'Tidak ada proses yang sedang berjalan.' });
});

// ─── Config / RK / Kamus (selalu per profil aktif) ──────────────────────────
app.get('/api/config', (req, res) => res.json({ success: true, config: req.store.read('config.json', {}) }));
app.put('/api/config', (req, res) => {
  try {
    const config = req.body || {};
    req.store.write('config.json', config);
    // Jaga identitas profil tetap sinkron saat kolom "Pegawai" diubah.
    const identitas = pecahPegawai(config.pegawai);
    if (identitas.nama) {
      const reg = pastikanProfil();
      const profile = reg.profiles.find((p) => p.id === req.profile.id);
      if (profile && (profile.nama !== identitas.nama || (identitas.nip && profile.nip !== identitas.nip))) {
        profile.nama = identitas.nama;
        if (identitas.nip) profile.nip = identitas.nip;
        profile.updatedAt = new Date().toISOString();
        tulisRegistry(reg);
      }
    }
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});
app.get('/api/rk-list', (req, res) => {
  rekonsiliasiRkProfil(req.profile);
  res.json({ success: true, rk: req.store.read('rk-list.json', []) });
});

// ── Tambah / ubah daftar Rencana Kinerja ────────────────────────────────────
// RK baru (yang belum ada di rk-list.json) bisa ditambahkan langsung dari
// picker RK di halaman Draft / Kata kunci. Perubahan tersimpan permanen.
function rapikanNamaRK(v) {
  return String(v || '').replace(/\s+/g, ' ').trim();
}
function bersihkanDaftarRK(data) {
  const arr = Array.isArray(data) ? data : (data && data.rk);
  if (!Array.isArray(arr)) throw new Error('Format daftar RK tidak valid (harus array).');
  const hasil = [];
  const seen = new Set();
  for (const item of arr) {
    const nama = rapikanNamaRK(item);
    if (!nama) continue;
    const kunci = nama.toLowerCase();
    if (seen.has(kunci)) continue;
    seen.add(kunci);
    hasil.push(nama);
  }
  return hasil;
}
app.post('/api/rk-list', (req, res) => {
  try {
    const nama = rapikanNamaRK(req.body && (req.body.nama || req.body.rk));
    if (!nama) return res.status(400).json({ success: false, error: 'Nama RK tidak boleh kosong.' });
    if (nama.length > 300) return res.status(400).json({ success: false, error: 'Nama RK terlalu panjang (maks 300 karakter).' });
    const list = req.store.read('rk-list.json', []);
    const sudahAda = list.find((x) => String(x).toLowerCase() === nama.toLowerCase());
    if (!sudahAda) {
      list.push(nama);
      req.store.write('rk-list.json', list);
    }
    res.json({ success: true, nama: sudahAda || nama, ditambahkan: !sudahAda, rk: list });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});
app.put('/api/rk-list', (req, res) => {
  try {
    const list = bersihkanDaftarRK(req.body);
    if (!list.length) throw new Error('Daftar RK tidak boleh kosong. Tambahkan minimal satu RK.');
    req.store.write('rk-list.json', list);
    // Buang aturan kata kunci yang RK-nya sudah tidak ada.
    const kunci = req.store.read('rk-keywords.json', []);
    if (Array.isArray(kunci) && kunci.length) {
      const valid = new Set(list.map((x) => String(x).toLowerCase()));
      const sisa = kunci.filter((it) => valid.has(String(it.rk || '').toLowerCase()));
      if (sisa.length !== kunci.length) req.store.write('rk-keywords.json', sisa);
    }
    res.json({ success: true, jumlah: list.length, rk: list });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// ── Impor daftar RK massal (tempel teks / unggah Excel-CSV) ─────────────────
function bersihkanBarisRK(raw) {
  let v = String(raw || '').replace(/\u00a0/g, ' ').trim();
  v = v.replace(/^(?:[-*•–—]|\d{1,3}[.)])\s+/, '').trim();
  v = rapikanNamaRK(v);
  if (!v || v.length < 5 || v.length > 300) return '';
  if (!/[a-zA-Z]/.test(v)) return '';
  if (/^(no|nomor|rencana kinerja|rencana kerja|rk|uraian|kegiatan)$/i.test(v)) return '';
  return v;
}
function parseRkTeks(teks) {
  return String(teks || '')
    .split(/\r?\n/)
    .map(bersihkanBarisRK)
    .filter(Boolean);
}
function headerMiripRK(teks) {
  return /rencana\s*kinerja|rencana\s*kerja|^rk\b/i.test(String(teks || '').trim());
}
function parseCsvSederhana(teks) {
  return String(teks || '').replace(/^\uFEFF/, '').split(/\r?\n/).map((baris) => {
    // cukup untuk CSV sederhana; tanda kutip ganda di-escape.
    const sel = [];
    let cur = '';
    let kutip = false;
    for (let i = 0; i < baris.length; i += 1) {
      const c = baris[i];
      if (c === '"') {
        if (kutip && baris[i + 1] === '"') { cur += '"'; i += 1; }
        else kutip = !kutip;
      } else if ((c === ',' || c === ';' || c === '\t') && !kutip) {
        sel.push(cur); cur = '';
      } else cur += c;
    }
    sel.push(cur);
    return sel.map((x) => x.trim());
  });
}
function ekstrakRkDariMatriks(rows) {
  // Cari baris header berisi "rencana kinerja/kerja", lalu ambil kolom itu.
  for (let i = 0; i < Math.min(rows.length, 30); i += 1) {
    const kol = rows[i].findIndex(headerMiripRK);
    if (kol >= 0) {
      return rows.slice(i + 1).map((r) => bersihkanBarisRK(r[kol])).filter(Boolean);
    }
  }
  // Tidak ada header: ambil semua sel teks yang masuk akal.
  const hasil = [];
  for (const r of rows) for (const sel of r) {
    const v = bersihkanBarisRK(sel);
    if (v) hasil.push(v);
  }
  return hasil;
}
async function ekstrakRkDariBerkas(file) {
  const ext = path.extname(file.originalname || '').toLowerCase();
  if (ext === '.csv' || ext === '.txt') {
    const teks = file.buffer.toString('utf8');
    return parseRkTeks(teks).length > 1 && !teks.includes(',') ? parseRkTeks(teks) : ekstrakRkDariMatriks(parseCsvSederhana(teks));
  }
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.load(file.buffer);
  const hasil = [];
  wb.worksheets.forEach((ws) => {
    const rows = [];
    ws.eachRow({ includeEmpty: false }, (row) => {
      const vals = [];
      row.eachCell({ includeEmpty: false }, (cell) => {
        const v = cell && cell.value;
        if (v == null) { vals.push(''); return; }
        if (typeof v === 'object') {
          vals.push(String(v.text || v.hyperlink || v.result || ''));
        } else vals.push(String(v));
      });
      if (vals.length) rows.push(vals);
    });
    hasil.push(...ekstrakRkDariMatriks(rows));
  });
  return hasil;
}
const uploadBerkas = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
app.post('/api/rk-list/import', uploadBerkas.single('file'), async (req, res) => {
  try {
    const mode = String((req.body && req.body.mode) || 'append') === 'replace' ? 'replace' : 'append';
    let items = parseRkTeks(req.body && req.body.text);
    if (req.file) items = items.concat(await ekstrakRkDariBerkas(req.file));
    items = bersihkanDaftarRK(items);
    if (!items.length) {
      return res.status(400).json({ success: false, error: 'Tidak ada RK yang terbaca. Tempel satu RK per baris atau unggah file dengan kolom “Rencana Kinerja”.' });
    }
    const lama = req.store.read('rk-list.json', []);
    const hasil = mode === 'replace' ? items : bersihkanDaftarRK([...(Array.isArray(lama) ? lama : []), ...items]);
    req.store.write('rk-list.json', hasil);
    res.json({ success: true, mode, ditambahkan: hasil.length - (Array.isArray(lama) ? lama.length : 0), jumlah: hasil.length, rk: hasil });
  } catch (e) { res.status(500).json({ success: false, error: `Gagal membaca daftar RK: ${e.message}` }); }
});

// ─── Dataset RK per pegawai ──────────────────────────────────────────────────
app.get('/api/rk-dataset', (req, res) => {
  try {
    const dataset = bacaDatasetBundel();
    res.json({
      success: true,
      source: dataset.source || '',
      generatedAt: dataset.generatedAt || '',
      teams: dataset.teams || [],
      employees: dataset.employees || [],
      pegawaiPindah: [...bacaPegawaiPindah()],
      ringkasan: ringkasDataset(dataset),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/rk-dataset/import', (req, res) => {
  try {
    const body = req.body || {};
    const dataset = bacaDatasetBundel();
    if (!Array.isArray(dataset.employees) || !dataset.employees.length) {
      return res.status(400).json({ success: false, error: 'Dataset RK bawaan tidak ditemukan/kosong.' });
    }
    const mode = body.mode === 'gabung' ? 'gabung' : 'ganti';
    const nips = Array.isArray(body.nips)
      ? body.nips.map(String)
      : (body.nips ? String(body.nips).split(',').map((x) => x.trim()).filter(Boolean) : null);
    const out = imporDatasetProfiles(dataset, { mode, nips });
    if (!out.hasil.length) {
      return res.status(400).json({ success: false, error: 'Tidak ada pegawai yang dipilih/ditemukan di dataset.' });
    }
    res.json({
      success: true,
      mode,
      hasil: out.hasil,
      profiles: out.profiles,
      ringkasan: ringkasDataset(dataset),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/rk-dataset/import-file', uploadBerkas.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, error: 'File dataset (.zip/.xlsx) wajib diunggah.' });
    if (!/\.(zip|xlsx)$/i.test(req.file.originalname || '')) {
      return res.status(400).json({ success: false, error: 'File harus .zip berisi banyak .xlsx, atau satu .xlsx.' });
    }
    const dataset = await bacaDataset(req.file.buffer, req.file.originalname);
    if (!Array.isArray(dataset.employees) || !dataset.employees.length) {
      return res.status(400).json({ success: false, error: 'Tidak ada pegawai yang terbaca dari file dataset.' });
    }
    const mode = String((req.body && req.body.mode) || 'ganti') === 'gabung' ? 'gabung' : 'ganti';
    const out = imporDatasetProfiles(dataset, { mode, nips: null });
    res.json({
      success: true,
      mode,
      hasil: out.hasil,
      profiles: out.profiles,
      ringkasan: ringkasDataset(dataset),
      source: dataset.source || req.file.originalname,
    });
  } catch (e) {
    res.status(500).json({ success: false, error: `Gagal membaca dataset: ${e.message}` });
  }
});

app.get('/api/kamus', (req, res) => res.json({ success: true, kamus: req.store.read('kamus-singkatan.json', []) }));app.put('/api/kamus', (req, res) => {
  try {
    const kamus = Array.isArray(req.body) ? req.body : req.body.kamus;
    if (!Array.isArray(kamus)) throw new Error('Format kamus tidak valid (harus array).');
    req.store.write('kamus-singkatan.json', kamus);
    res.json({ success: true, jumlah: kamus.length });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// Kata kunci per RK: bila nama file memuat kunci → langsung diusulkan ke RK itu.
// Format: [{ rk: "Nama RK", kunci: ["kata", "frasa"] }, ...] — urutan = prioritas.
function bersihkanAturanKunci(data) {
  const arr = Array.isArray(data) ? data : (data && data.aturan);
  if (!Array.isArray(arr)) throw new Error('Format kata kunci RK tidak valid (harus array).');
  return arr.map((it) => ({
    rk: String((it && it.rk) || '').trim(),
    kunci: [...new Set((Array.isArray(it && it.kunci) ? it.kunci : String((it && it.kunci) || '').split(','))
      .map((k) => String(k || '').trim())
      .filter(Boolean))],
  })).filter((it) => it.rk && it.kunci.length);
}
app.get('/api/rk-keywords', (req, res) => res.json({ success: true, aturan: req.store.read('rk-keywords.json', []) }));
app.put('/api/rk-keywords', (req, res) => {
  try {
    const aturan = bersihkanAturanKunci(req.body);
    req.store.write('rk-keywords.json', aturan);
    res.json({ success: true, jumlah: aturan.length });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// ─── Draft ───────────────────────────────────────────────────────────────────
function susunDraft(items, kamus, rkList, aturanKustom = []) {
  const rows = items.map((f, i) => {
    const p = parseFileName(f.namaFile);
    const kegiatan = p.ok
      ? expandKegiatan(p.kegiatanRaw, kamus)
      : expandKegiatan(p.kegiatanRaw || f.namaFile, kamus);
    const usulan = suggestRK(kegiatan, rkList, 3, { namaFile: f.namaFile, aturanKustom }).map((s) => s.rk);
    return {
      id: i,
      namaFile: f.namaFile,
      link: f.link,
      // Tanggal tetap dipakai walau kegiatan belum terbaca (parser mengembalikan
      // tanggal parsial), supaya user tidak perlu mengetik ulang.
      tglAwal: p.tglAwal ?? null,
      tglAkhir: p.tglAkhir ?? null,
      bulan: p.bulan || '',
      bulanIndex: p.bulanIndex || 99,
      tahun: p.tahun || null,
      kegiatan,
      rk: usulan[0] || '',
      usulan,
      perluReview: !p.ok || !usulan[0],
      alasan: p.ok ? (usulan[0] ? '' : 'RK tidak yakin — pilih manual') : p.alasan,
    };
  });
  rows.sort((a, b) =>
    (a.bulanIndex - b.bulanIndex) ||
    ((a.tglAwal || 99) - (b.tglAwal || 99)) ||
    a.namaFile.localeCompare(b.namaFile, 'id')
  );
  return rows;
}

// ─── Payload KipApp (alternatif ambil data untuk bridge extension) ───────────
// Kontrak sama dengan window.postMessage CKP_SEND_RECORDS di public/app.js:
// { type:'CKP_SEND_RECORDS', fileName, sheetName, rows:[{ no, tanggalMulai ISO,
//   tanggalSelesai, rencanaKinerja, kegiatan, progres '100', capaian 'Telah …', dataDukung }] }
const CKP_BULAN_IDX = Object.fromEntries(Object.entries(BULAN).map(([k, v]) => [k, v.index]));
function ckpIsoDateSrv(tgl, bulanNama, tahun) {
  const d = parseInt(tgl, 10);
  const m = CKP_BULAN_IDX[String(bulanNama || '').trim().toLowerCase()];
  const y = parseInt(tahun, 10);
  if (!d || !m || !y) return '';
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
}
function ckpDraftKeRecordsSrv(draft, tahunData) {
  const tahunDefault = parseInt(tahunData, 10) || new Date().getFullYear();
  return (Array.isArray(draft) ? draft : []).map((d, i) => {
    const tahun = parseInt(d.tahun, 10) || tahunDefault;
    const akhir = d.tglAkhir || d.tglAwal;
    const kegiatan = String(d.kegiatan || '').trim();
    const rec = {
      rowNumber: i + 1,
      no: String(i + 1),
      tanggalMulai: ckpIsoDateSrv(d.tglAwal, d.bulan, tahun),
      tanggalSelesai: ckpIsoDateSrv(akhir, d.bulan, tahun),
      rencanaKinerja: String(d.rk || '').trim(),
      kegiatan,
      progres: '100',
      capaian: kegiatan ? `Telah ${kegiatan}` : '',
      dataDukung: String(d.link || '').trim(),
      status: 'pending',
    };
    rec.warnings = [];
    if (!rec.tanggalMulai) rec.warnings.push('Tanggal mulai belum diisi.');
    if (!rec.rencanaKinerja) rec.warnings.push('Rencana kinerja belum diisi.');
    if (!rec.kegiatan) rec.warnings.push('Uraian kegiatan belum diisi.');
    if (!rec.progres) rec.warnings.push('Progres belum diisi.');
    if (!rec.capaian) rec.warnings.push('Capaian belum diisi.');
    if (!rec.dataDukung) rec.warnings.push('Tautan bukti dukung belum diisi.');
    return rec;
  });
}
app.get('/api/ckp-payload', (req, res) => {
  const config = req.store.read('config.json', {});
  const tahun = parseInt((req.query && req.query.tahunData) || config.tahunData, 10) || new Date().getFullYear();
  res.json({
    success: true, type: 'CKP_SEND_RECORDS', tahunData: tahun, jumlah: 0, rows: [],
    profile: { id: req.profile.id, nama: req.profile.nama, nip: req.profile.nip },
    format: 'POST { draft:[{kegiatan,rk,tglAwal,tglAkhir,bulan,link}], header:{tahunData,sheetName} } → { type, fileName, sheetName, rows }',
  });
});
app.post('/api/ckp-payload', (req, res) => {
  try {
    const { draft, header } = req.body || {};
    if (!Array.isArray(draft) || !draft.length) {
      return res.status(400).json({ success: false, error: 'Kirim draft:[{kegiatan,rk,tglAwal,tglAkhir,bulan,link}].' });
    }
    const tahun = (header && header.tahunData) || req.store.read('config.json', {}).tahunData || new Date().getFullYear();
    const rows = ckpDraftKeRecordsSrv(draft, tahun);
    res.json({
      success: true, type: 'CKP_SEND_RECORDS',
      fileName: ((header && header.sheetName) || 'CKP') + '.xlsx',
      sheetName: (header && header.sheetName) || '',
      profile: { id: req.profile.id, nama: req.profile.nama, nip: req.profile.nip },
      jumlah: rows.length, rows,
    });
  } catch (e) { res.status(500).json({ success: false, error: e.message }); }
});

// 8a. Draft dari hasil upload (jalur utama — tanpa file perantara)
app.post('/api/draft/generate', (req, res) => {
  try {
    const items = (req.body && req.body.items) || [];
    const valid = items.filter((f) => f.namaFile && f.link);
    if (valid.length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada baris berhasil (nama + link Drive) untuk disusun.' });
    }
    const rkList = req.store.read('rk-list.json', []);
    const kamus = req.store.read('kamus-singkatan.json', []);
    const aturanKustom = req.store.read('rk-keywords.json', []);
    const config = req.store.read('config.json', {});
    res.json({
      success: true,
      totalBerhasil: valid.length,
      tahunDefault: (config && config.tahunData) || new Date().getFullYear(),
      rows: susunDraft(valid.map((f) => ({ namaFile: f.namaFile, link: f.link })), kamus, rkList, aturanKustom),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// 8a-2. Hitung ulang saran RK untuk draft yang sudah ada.
// Dipakai saat aturan kata kunci / daftar RK berubah, tanpa upload ulang.
app.post('/api/draft/resuggest', (req, res) => {
  try {
    const rows = (req.body && req.body.rows) || [];
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada baris untuk dihitung ulang.' });
    }
    const rkList = req.store.read('rk-list.json', []);
    const aturanKustom = req.store.read('rk-keywords.json', []);
    const hasil = rows.map((r) => {
      const usulan = suggestRK(String(r.kegiatan || ''), rkList, 3, {
        namaFile: r.namaFile || '',
        aturanKustom,
      }).map((s) => s.rk);
      return { rk: usulan[0] || '', usulan };
    });
    res.json({ success: true, rows: hasil });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// 8a-3. Isi tanggal dari nama file untuk draft lama (tanpa upload ulang).
app.post('/api/draft/parse-dates', (req, res) => {
  try {
    const rows = (req.body && req.body.rows) || [];
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada baris untuk dibaca tanggalnya.' });
    }
    const hasil = rows.map((r) => {
      const p = parseFileName(String(r.namaFile || ''));
      return {
        tglAwal: p.tglAwal ?? null,
        tglAkhir: p.tglAkhir ?? null,
        bulan: p.bulan || '',
        bulanIndex: p.bulanIndex || 99,
        tahun: p.tahun || null,
        alasan: p.alasan || '',
      };
    });
    res.json({ success: true, rows: hasil });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// 8b. Daftar hasil_*.xlsx lama (kompatibilitas mundur)
app.get('/api/hasil-files', (req, res) => {
  try {
    const seen = new Set();
    const files = [];
    for (const { dir } of req.store.historyDirs()) {
      if (!fs.existsSync(dir)) continue;
      for (const f of fs.readdirSync(dir)) {
        if (!/^hasil_.*\.xlsx$/i.test(f) || seen.has(f.toLowerCase())) continue;
        seen.add(f.toLowerCase());
        const full = path.join(dir, f);
        const st = fs.statSync(full);
        files.push({ nama: f, path: full, ukuran: st.size, diubah: st.mtime });
      }
    }
    files.sort((a, b) => b.diubah - a.diubah);
    res.json({ success: true, files });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// 8c. Draft dari file hasil_*.xlsx lama
app.post('/api/draft/from-hasil', async (req, res) => {
  try {
    const hasilPath = req.body && req.body.hasilPath;
    if (!hasilPath || !fs.existsSync(hasilPath)) {
      return res.status(400).json({ success: false, error: 'File hasil tidak ditemukan.' });
    }
    const diizinkan = req.store.historyDirs().some(({ dir }) => diDalamFolder(hasilPath, dir));
    if (!diizinkan) return res.status(403).json({ success: false, error: 'File hasil bukan milik profil ini.' });
    const rkList = req.store.read('rk-list.json', []);
    const kamus = req.store.read('kamus-singkatan.json', []);
    const aturanKustom = req.store.read('rk-keywords.json', []);
    const config = req.store.read('config.json', {});
    const { ok, gagal } = await bacaHasilUpload(hasilPath);
    if (ok.length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada baris BERHASIL di file hasil itu.' });
    }
    res.json({
      success: true,
      gagalSkip: gagal,
      totalBerhasil: ok.length,
      tahunDefault: (config && config.tahunData) || new Date().getFullYear(),
      rows: susunDraft(ok, kamus, rkList, aturanKustom),
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

function bacaHasilUpload(hasilPath) {
  const wb = new ExcelJS.Workbook();
  return wb.xlsx.readFile(hasilPath).then(() => {
    const ws = wb.worksheets[0];
    if (!ws) throw new Error('File hasil tidak memiliki sheet.');
    const header = [];
    ws.getRow(1).eachCell((c, n) => { header[n] = String(c.value || '').toLowerCase(); });
    const idxNama = header.findIndex((h) => (h || '').includes('nama file asli'));
    const idxStatus = header.findIndex((h) => (h || '') === 'status');
    const idxLink = header.findIndex((h) => (h || '').includes('link'));
    if (idxNama < 1 || idxLink < 1) throw new Error('Format kolom file hasil tidak dikenali.');
    const ok = [];
    let gagal = 0;
    for (let r = 2; r <= ws.rowCount; r++) {
      const row = ws.getRow(r);
      const namaCell = row.getCell(idxNama);
      const nama = namaCell && namaCell.value ? String(namaCell.value.text || namaCell.value).trim() : '';
      if (!nama || nama === '-') continue;
      const status = idxStatus > 0 && row.getCell(idxStatus).value
        ? String(row.getCell(idxStatus).value).toUpperCase()
        : '';
      const linkCell = row.getCell(idxLink);
      let link = '';
      if (linkCell) {
        if (linkCell.hyperlink) link = String(linkCell.hyperlink);
        else if (linkCell.value && typeof linkCell.value === 'object' && linkCell.value.hyperlink) link = String(linkCell.value.hyperlink);
        else if (linkCell.value) link = String(linkCell.value.text || linkCell.value).trim();
      }
      if (link === '-') link = '';
      const berhasil = idxStatus < 1
        ? !!link
        : (status.includes('BERHASIL') || status === 'SUCCESS' || status === 'OK');
      if (berhasil && link) ok.push({ namaFile: nama, link });
      else gagal++;
    }
    return { ok, gagal };
  });
}

// ─── Integrasi SIKAP ─────────────────────────────────────────────────────────
// Token disimpan per profil di data/profiles/<id>/sikap-integration.json.
// Jangan pernah mengirim token balik ke browser; hanya status hasToken.
function bacaSikap(store) {
  const raw = store.read('sikap-integration.json', {});
  return {
    baseUrl: String(raw.baseUrl || ''),
    token: String(raw.token || ''),
    user: raw.user || null,
    rks: Array.isArray(raw.rks) ? raw.rks : [],
    subRks: Array.isArray(raw.subRks) ? raw.subRks : [],
    source: raw.source || '',
    verifiedAt: raw.verifiedAt || '',
    lastSyncAt: raw.lastSyncAt || '',
    lastUpload: raw.lastUpload || null,
    pairing: raw.pairing || null,
  };
}
function simpanSikap(store, data) {
  store.write('sikap-integration.json', data);
}
function ringkasSikap(sikap) {
  return {
    configured: Boolean(sikap.baseUrl && sikap.token),
    baseUrl: sikap.baseUrl,
    hasToken: Boolean(sikap.token),
    user: sikap.user,
    rkCount: sikap.rks.length,
    subRkCount: (sikap.subRks || []).length,
    source: sikap.source,
    verifiedAt: sikap.verifiedAt,
    lastSyncAt: sikap.lastSyncAt,
    lastUpload: sikap.lastUpload,
    pairing: sikap.pairing
      ? {
        active: true,
        code: sikap.pairing.code || '',
        pairUrl: sikap.pairing.pairUrl || '',
        expiresAt: sikap.pairing.expiresAt || '',
      }
      : null,
  };
}
async function fetchSikap(sikap, pathname, options = {}) {
  if (typeof fetch !== 'function' || typeof FormData !== 'function') {
    const err = new Error('Node.js terlalu lama untuk integrasi SIKAP. Gunakan Node.js 18 atau lebih baru.');
    err.status = 500;
    throw err;
  }
  if (!sikap.baseUrl || !sikap.token) {
    const err = new Error('Integrasi SIKAP belum diatur. Buka Profil & rekan → Integrasi SIKAP.');
    err.status = 400;
    throw err;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs || 45000);
  try {
    const res = await fetch(`${sikap.baseUrl}${pathname}`, {
      ...options,
      headers: {
        Authorization: `Bearer ${sikap.token}`,
        ...(options.headers || {}),
      },
      signal: controller.signal,
    });
    const tipe = res.headers.get('content-type') || '';
    const data = tipe.includes('json') ? await res.json().catch(() => ({})) : {};
    if (!res.ok) {
      const html = tipe.includes('html');
      let pesan = data.error;
      if (!pesan) {
        pesan = (html || [307, 404, 405].includes(res.status))
          ? `Alamat SIKAP belum memuat fitur integrasi (HTTP ${res.status}). Deploy ulang SIKAP versi terbaru.`
          : `SIKAP menolak permintaan (HTTP ${res.status}).`;
      }
      const err = new Error(pesan);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  } catch (e) {
    if (e.name === 'AbortError') {
      const err = new Error('SIKAP tidak merespons dalam batas waktu. Cek koneksi/alamat SIKAP.');
      err.status = 504;
      throw err;
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

// Untuk pairing: belum ada token. Hanya memanggil endpoint /pair milik SIKAP.
async function fetchSikapPublik(baseUrl, pathname, options = {}) {
  if (typeof fetch !== 'function') {
    const err = new Error('Node.js terlalu lama untuk integrasi SIKAP. Gunakan Node.js 18 atau lebih baru.');
    err.status = 500;
    throw err;
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeoutMs || 30000);
  try {
    const res = await fetch(`${baseUrl}${pathname}`, {
      ...options,
      headers: { ...(options.headers || {}) },
      signal: controller.signal,
    });
    const tipe = res.headers.get('content-type') || '';
    const data = tipe.includes('json') ? await res.json().catch(() => ({})) : {};
    if (!res.ok) {
      const html = tipe.includes('html');
      let pesan = data.error;
      if (!pesan) {
        pesan = (html || [307, 404, 405].includes(res.status))
          ? `Alamat SIKAP belum memuat fitur integrasi (HTTP ${res.status}). Deploy ulang SIKAP versi terbaru.`
          : `SIKAP menolak permintaan (HTTP ${res.status}).`;
      }
      const err = new Error(pesan);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  } catch (e) {
    if (e.name === 'AbortError') {
      const err = new Error('SIKAP tidak merespons dalam batas waktu. Cek koneksi/alamat SIKAP.');
      err.status = 504;
      throw err;
    }
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

app.get('/api/sikap/status', (req, res) => {
  const sikap = ringkasSikap(bacaSikap(req.store));
  sikap.defaultBaseUrl = String(process.env.SIKAP_BASE_URL || '').trim();
  res.json({ success: true, sikap });
});

app.put('/api/sikap/config', (req, res) => {
  try {
    const b = req.body || {};
    const base = normalizeBaseUrl(b.baseUrl);
    if (!base.ok) return res.status(400).json({ success: false, error: base.error });
    const lama = bacaSikap(req.store);
    const token = String(b.token || '').trim() || lama.token;
    if (!token) {
      return res.status(400).json({ success: false, error: 'Token integrasi SIKAP belum diisi.' });
    }
    if (token.length > 300) {
      return res.status(400).json({ success: false, error: 'Token terlalu panjang / tidak valid.' });
    }
    const gantiAlamat = base.url !== lama.baseUrl;
    const data = {
      ...lama,
      baseUrl: base.url,
      token,
      // Ganti alamat = data RK lama tidak relevan lagi.
      user: gantiAlamat ? null : lama.user,
      rks: gantiAlamat ? [] : lama.rks,
      source: gantiAlamat ? '' : lama.source,
      verifiedAt: gantiAlamat ? '' : lama.verifiedAt,
      lastSyncAt: gantiAlamat ? '' : lama.lastSyncAt,
      lastUpload: gantiAlamat ? null : lama.lastUpload,
      pairing: null,
    };
    simpanSikap(req.store, data);
    res.json({ success: true, sikap: ringkasSikap(data) });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ── Pairing satu klik ────────────────────────────────────────────────────────
// CKP App membuat kode di SIKAP, membuka tab persetujuan, lalu polling.
// User tidak perlu menyalin token.
app.post('/api/sikap/pair/start', async (req, res) => {
  try {
    const base = normalizeBaseUrl((req.body && req.body.baseUrl) || '');
    if (!base.ok) return res.status(400).json({ success: false, error: base.error });

    const mulai = await fetchSikapPublik(base.url, '/api/integrations/ckp-app/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
    });
    if (!mulai || mulai.success !== true || !mulai.pairingId || !mulai.secret) {
      return res.status(400).json({ success: false, error: (mulai && mulai.error) || 'SIKAP tidak mengembalikan kode pairing.' });
    }

    const lama = bacaSikap(req.store);
    const data = {
      ...lama,
      baseUrl: base.url,
      token: '',
      user: null,
      rks: [],
      source: '',
      verifiedAt: '',
      lastSyncAt: '',
      lastUpload: null,
      pairing: {
        id: mulai.pairingId,
        secret: mulai.secret,
        code: mulai.code || '',
        pairUrl: mulai.pairUrl || '',
        expiresAt: mulai.expiresAt || '',
        startedAt: new Date().toISOString(),
      },
    };
    simpanSikap(req.store, data);
    res.json({
      success: true,
      code: data.pairing.code,
      pairUrl: data.pairing.pairUrl,
      expiresAt: data.pairing.expiresAt,
      sikap: ringkasSikap(data),
    });
  } catch (e) {
    res.status(e.status || 500).json({ success: false, error: e.message });
  }
});

app.get('/api/sikap/pair/status', async (req, res) => {
  try {
    const sikap = bacaSikap(req.store);
    if (!sikap.pairing || !sikap.pairing.id || !sikap.pairing.secret) {
      return res.status(400).json({ success: false, error: 'Tidak ada proses pairing yang aktif.' });
    }
    const p = sikap.pairing;
    const qs = `?secret=${encodeURIComponent(p.secret)}`;
    const hasil = await fetchSikapPublik(
      sikap.baseUrl,
      `/api/integrations/ckp-app/pair/${encodeURIComponent(p.id)}${qs}`,
      { method: 'GET' },
    );

    if (hasil.status === 'pending') {
      return res.json({
        success: true,
        status: 'pending',
        code: p.code,
        pairUrl: p.pairUrl,
        expiresAt: p.expiresAt,
      });
    }

    if (hasil.status !== 'approved' || !hasil.token) {
      const baru = { ...sikap, pairing: null };
      simpanSikap(req.store, baru);
      return res.status(400).json({
        success: false,
        status: hasil.status || 'error',
        error: hasil.error || 'Pairing tidak berhasil. Buat kode baru dari CKP App.',
        sikap: ringkasSikap(baru),
      });
    }

    // Token diterima. Simpan lalu langsung ambil profil + RK.
    const sementara = { ...sikap, token: hasil.token, pairing: null };
    let profil = null;
    try {
      profil = await fetchSikap(sementara, '/api/integrations/ckp-app', { method: 'GET' });
    } catch (e) {
      // Token valid tapi GET gagal: simpan token dulu supaya tidak hilang.
      simpanSikap(req.store, sementara);
      return res.json({
        success: true,
        status: 'connected',
        warning: e.message,
        sikap: ringkasSikap(sementara),
        periode: null,
      });
    }
    const baru = {
      ...sementara,
      user: (profil && profil.user) || null,
      rks: (profil && Array.isArray(profil.rks)) ? profil.rks : [],
      source: (profil && profil.source) || '',
      verifiedAt: new Date().toISOString(),
      lastSyncAt: new Date().toISOString(),
      lastUpload: (profil && profil.lastUpload) || null,
    };
    simpanSikap(req.store, baru);
    // Gabungkan RK SIKAP dengan RK lokal yang sudah ada agar RK lokal tidak hilang.
    if (baru.rks.length) {
      const namaRk = [...new Set(baru.rks.map((rk) => String(rk.rencana_kinerja || '').trim()).filter(Boolean))];
      if (namaRk.length) {
        const lamaRk = req.store.read('rk-list.json', []);
        const hasil = [...(Array.isArray(lamaRk) ? lamaRk : [])];
        const ada = new Set(hasil.map((x) => String(x).toLowerCase()));
        for (const nama of namaRk) {
          if (!ada.has(nama.toLowerCase())) { ada.add(nama.toLowerCase()); hasil.push(nama); }
        }
        req.store.write('rk-list.json', hasil);
      }
    }
    res.json({
      success: true,
      status: 'connected',
      sikap: ringkasSikap(baru),
      periode: (profil && profil.periode) || null,
    });
  } catch (e) {
    if (e.status === 404) {
      const sikap = bacaSikap(req.store);
      const baru = { ...sikap, pairing: null };
      simpanSikap(req.store, baru);
      return res.status(400).json({
        success: false,
        status: 'expired',
        error: 'Kode pairing tidak ditemukan/kedaluwarsa. Buat kode baru dari CKP App.',
        sikap: ringkasSikap(baru),
      });
    }
    res.status(e.status || 500).json({ success: false, error: e.message });
  }
});

app.post('/api/sikap/pair/cancel', (req, res) => {
  try {
    const sikap = bacaSikap(req.store);
    simpanSikap(req.store, { ...sikap, pairing: null });
    res.json({ success: true, sikap: ringkasSikap(bacaSikap(req.store)) });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/sikap/disconnect', (req, res) => {
  try {
    const lama = bacaSikap(req.store);
    const baru = {
      ...lama,
      token: '',
      user: null,
      rks: [],
      source: '',
      verifiedAt: '',
      lastSyncAt: '',
      lastUpload: null,
      pairing: null,
    };
    simpanSikap(req.store, baru);
    res.json({ success: true, sikap: ringkasSikap(baru) });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.post('/api/sikap/test', async (req, res) => {
  try {
    const sikap = bacaSikap(req.store);
    const config = req.store.read('config.json', {});
    const periode = periodeKeBulanTahun(config);
    const qs = periode.ok ? `?bulan=${periode.bulan}&tahun=${periode.tahun}` : '';
    const data = await fetchSikap(sikap, `/api/integrations/ckp-app${qs}`, { method: 'GET' });
    if (!data || data.success !== true) {
      return res.status(400).json({ success: false, error: (data && data.error) || 'SIKAP tidak mengenali token ini.' });
    }
    const baru = {
      ...sikap,
      user: data.user || null,
      rks: Array.isArray(data.rks) ? data.rks : [],
      subRks: Array.isArray(data.subRks) ? data.subRks : [],
      source: data.source || '',
      verifiedAt: new Date().toISOString(),
      lastSyncAt: new Date().toISOString(),
      lastUpload: data.lastUpload || sikap.lastUpload || null,
    };
    simpanSikap(req.store, baru);
    res.json({
      success: true,
      sikap: ringkasSikap(baru),
      periode: data.periode || null,
      lastUpload: data.lastUpload || null,
    });
  } catch (e) {
    res.status(e.status || 500).json({
      success: false,
      error: e.message,
      unmatchedRks: (e.data && e.data.unmatchedRks) || undefined,
    });
  }
});

app.post('/api/sikap/sync-rk', async (req, res) => {
  try {
    const mode = String((req.body && req.body.mode) || 'append') === 'replace' ? 'replace' : 'append';
    const sikap = bacaSikap(req.store);
    const config = req.store.read('config.json', {});
    const periode = periodeKeBulanTahun(config);
    const qs = periode.ok ? `?bulan=${periode.bulan}&tahun=${periode.tahun}` : '';
    const data = await fetchSikap(sikap, `/api/integrations/ckp-app${qs}`, { method: 'GET' });
    if (!data || data.success !== true || (!Array.isArray(data.rks) && !Array.isArray(data.subRks))) {
      return res.status(400).json({ success: false, error: (data && data.error) || 'Daftar RK SIKAP tidak terbaca.' });
    }
    // Yang dipakai di kolom "Rencana Kinerja" Excel adalah Sub-RK (RK Anggota),
    // bukan RK Ketua Tim. Utamakan subRks; rks tetap dipakai untuk SIKAP lama.
    const subRks = Array.isArray(data.subRks) ? data.subRks : [];
    const namaSikap = (subRks.length
      ? subRks.map((s) => String(s.kegiatan_nama || '').trim())
      : (Array.isArray(data.rks) ? data.rks : []).map((rk) => String(rk.rencana_kinerja || '').trim())
    ).filter(Boolean);
    if (!namaSikap.length) {
      return res.status(400).json({ success: false, error: 'SIKAP belum punya Sub-RK (RK Anggota) untuk profil ini.' });
    }
    const lama = req.store.read('rk-list.json', []);
    let hasil;
    // Peta RK per pegawai (rk-pegawai.json) adalah sumber utama daftar RK.
    // Sync lama (append) menumpuk nama parent + Sub-RK dari beberapa versi,
    // sehingga jumlahnya bisa jauh di atas jumlah RK sebenarnya (mis. 86 vs 44).
    // Bila profil ada di peta, pakai daftar peta; selain itu pakai perilaku lama.
    const peta = rkPegawaiUntuk(req.profile);
    const namaPeta = peta
      ? [...new Set(peta.rks.map((r) => String(r.nama || '').trim()).filter(Boolean))]
      : [];
    if (namaPeta.length) {
      hasil = namaPeta;
    } else if (mode === 'append') {
      const seen = new Set((Array.isArray(lama) ? lama : []).map((x) => String(x).toLowerCase()));
      hasil = [...(Array.isArray(lama) ? lama : [])];
      for (const nama of namaSikap) {
        if (!seen.has(nama.toLowerCase())) { seen.add(nama.toLowerCase()); hasil.push(nama); }
      }
    } else {
      hasil = [...new Set(namaSikap)];
    }
    req.store.write('rk-list.json', hasil);
    const baru = {
      ...sikap,
      user: data.user || sikap.user,
      rks: Array.isArray(data.rks) ? data.rks : sikap.rks,
      subRks,
      source: data.source || '',
      verifiedAt: sikap.verifiedAt || new Date().toISOString(),
      lastSyncAt: new Date().toISOString(),
    };
    simpanSikap(req.store, baru);
    res.json({
      success: true,
      mode,
      jumlah: hasil.length,
      rk: hasil,
      sikap: ringkasSikap(baru),
      periode: data.periode || null,
    });
  } catch (e) {
    res.status(e.status || 500).json({
      success: false,
      error: e.message,
      unmatchedRks: (e.data && e.data.unmatchedRks) || undefined,
    });
  }
});

app.post('/api/sikap/kirim', async (req, res) => {
  let tempPath = '';
  try {
    const { rows, header } = req.body || {};
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada baris draft untuk dikirim.' });
    }
    const periode = periodeKeBulanTahun(header || {});
    if (!periode.ok) return res.status(400).json({ success: false, error: periode.error });

    const sikap = bacaSikap(req.store);
    if (!sikap.baseUrl || !sikap.token) {
      return res.status(400).json({ success: false, error: 'Integrasi SIKAP belum diatur. Buka Profil & rekan → Integrasi SIKAP.' });
    }
    if (!sikap.rks.length && !sikap.subRks.length) {
      return res.status(400).json({ success: false, error: 'Daftar RK SIKAP belum ditarik. Klik “Tarik RK dari SIKAP” dulu.' });
    }
    // Pencocokan final ada di SIKAP (Sub-RK → RK Ketua Tim). Aplikasi tidak
    // menebak lagi di sini supaya Sub-RK yang baru ditambahkan di SIKAP tidak
    // ikut diblokir oleh salinan daftar yang lama. Bila ada yang tidak cocok,
    // SIKAP mengembalikan daftarnya dan Export menampilkannya.

    const rkList = req.store.read('rk-list.json', []);
    const final = susunBarisFinal(rows, rkList, periode.tahun);
    if (final.errors.length) {
      return res.status(400).json({ success: false, error: 'Masih ada baris belum lengkap:', detail: final.errors });
    }

    const stem = ('SIKAP_' + String((header && header.sheetName) || 'CKP'))
      .replace(/^SIKAP_CKP\s+/i, 'SIKAP_')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/\s+/g, '_')
      .slice(0, 80);
    tempPath = path.join(os.tmpdir(), `${stem}_${Date.now()}.xlsx`);
    const saved = await buildCKP({
      rows: final.finalRows,
      header: header || {},
      rkList,
      outPath: tempPath,
    });
    tempPath = saved;
    const buffer = fs.readFileSync(saved);
    const fileName = path.basename(saved);

    const fd = new FormData();
    fd.append('file', new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    }), fileName);
    fd.append('bulan', String(periode.bulan));
    fd.append('tahun', String(periode.tahun));
    fd.append('clientUploadId', buatClientUploadId(rows, header || {}));
    fd.append('expectedRows', String(rows.length));

    const data = await fetchSikap(sikap, '/api/integrations/ckp-app', {
      method: 'POST',
      body: fd,
      timeoutMs: 120000,
    });
    if (!data || data.success !== true) {
      return res.status(400).json({
        success: false,
        error: (data && data.error) || 'SIKAP tidak mengonfirmasi penyimpanan.',
        unmatchedRks: (data && data.unmatchedRks) || undefined,
      });
    }

    const baru = {
      ...sikap,
      lastUpload: {
        at: new Date().toISOString(),
        uploadId: data.uploadId || '',
        version: data.version || null,
        status: data.status || '',
        bulan: periode.bulan,
        tahun: periode.tahun,
      },
    };
    simpanSikap(req.store, baru);
    res.json({
      success: true,
      uploadId: data.uploadId,
      version: data.version,
      status: data.status,
      duplicate: Boolean(data.duplicate),
      url: data.url ? `${sikap.baseUrl}${data.url}` : sikap.baseUrl,
      warnings: data.warnings || [],
      sikap: ringkasSikap(baru),
    });
  } catch (e) {
    res.status(e.status || 500).json({
      success: false,
      error: e.message,
      unmatchedRks: (e.data && e.data.unmatchedRks) || undefined,
    });
  } finally {
    if (tempPath) {
      try { fs.unlinkSync(tempPath); } catch (e) { /* abaikan */ }
    }
  }
});

// ─── Export Excel CKP ────────────────────────────────────────────────────────
// Validasi + bentuk baris final Excel. Dipakai export web dan kirim SIKAP.
function susunBarisFinal(rows, rkList, tahunDefault) {
  const errors = [];
  const finalRows = rows.map((d, i) => {
    const no = i + 1;
    if (!d.kegiatan || !String(d.kegiatan).trim()) errors.push(`Baris ${no}: kegiatan kosong.`);
    if (!d.rk || !rkList.includes(d.rk)) errors.push(`Baris ${no}: RK belum dipilih / tidak valid.`);
    if (!d.tglAwal || !d.bulan) errors.push(`Baris ${no}: tanggal belum lengkap.`);
    if (!d.link) errors.push(`Baris ${no}: link Drive kosong.`);
    const akhir = d.tglAkhir || d.tglAwal;
    const tahunBaris = parseInt(d.tahun, 10) || tahunDefault;
    return {
      tanggalMulai: d.tglAwal && d.bulan ? formatTanggal(d.tglAwal, d.bulan, tahunBaris) : '',
      tanggalSelesai: akhir && d.bulan ? formatTanggal(akhir, d.bulan, tahunBaris) : '',
      rk: d.rk || '',
      kegiatan: String(d.kegiatan || '').trim(),
      capaian: `Telah ${String(d.kegiatan || '').trim()}`,
      link: d.link || '',
    };
  });
  return { finalRows, errors };
}

app.post('/api/export', async (req, res) => {
  try {
    const { rows, header } = req.body || {};
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ success: false, error: 'Tidak ada baris untuk diekspor.' });
    }
    const rkList = req.store.read('rk-list.json', []);
    const tahun = parseInt(header && header.tahunData, 10) || new Date().getFullYear();
    const { finalRows, errors } = susunBarisFinal(rows, rkList, tahun);
    if (errors.length > 0) {
      return res.status(400).json({ success: false, error: 'Masih ada baris belum lengkap:', detail: errors });
    }
    const stem = ('CKP_' + ((header && header.sheetName) || 'Hasil'))
      .replace(/^CKP_CKP\s+/i, 'CKP_')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/\s+/g, '_')
      .slice(0, 80) || 'CKP_Hasil';
    const outPath = path.join(req.store.dirs.ckp, `${stem}.xlsx`);
    const saved = await buildCKP({ rows: finalRows, header: header || {}, rkList, outPath });
    res.json({ success: true, path: saved, jumlah: finalRows.length });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

app.get('/api/download', (req, res) => {
  const p = req.query.path;
  if (!p) return res.status(404).send('File tidak ditemukan.');
  const resolved = path.resolve(p);
  const allowed = req.store.historyDirs().map(({ dir }) => path.resolve(dir));
  if (!allowed.some((a) => diDalamFolder(resolved, a))) return res.status(403).send('Akses ditolak.');
  if (!fs.existsSync(resolved)) return res.status(404).send('File tidak ditemukan.');
  res.download(resolved);
});

// ─── Riwayat ─────────────────────────────────────────────────────────────────
app.get('/api/history', (req, res) => {
  try {
    const kumpul = [];
    const seen = new Set();
    for (const { dir, jenis } of req.store.historyDirs()) {
      if (!fs.existsSync(dir)) continue;
      for (const f of fs.readdirSync(dir)) {
        if (!/\.xlsx$/i.test(f)) continue;
        const full = path.join(dir, f);
        const kunci = `${jenis}:${f}`.toLowerCase();
        if (seen.has(kunci)) continue;
        seen.add(kunci);
        try {
          const st = fs.statSync(full);
          kumpul.push({ nama: f, path: full, ukuran: st.size, diubah: st.mtime, jenis });
        } catch (e) { /* lewati */ }
      }
    }
    kumpul.sort((a, b) => new Date(b.diubah) - new Date(a.diubah));
    res.json({ success: true, files: kumpul.slice(0, 50) });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// ─── Buka path di Explorer (lokal saja) ──────────────────────────────────────
app.post('/api/open-path', (req, res) => {
  const { targetPath } = req.body || {};
  if (!targetPath || !fs.existsSync(targetPath)) {
    return res.status(404).json({ success: false, error: 'Path tidak ditemukan.' });
  }
  try {
    const stat = fs.statSync(targetPath);
    if (stat.isDirectory()) spawn('explorer.exe', [targetPath], { detached: true });
    else spawn('explorer.exe', [`/select,${targetPath}`], { detached: true });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ═══════════════════════ Upload Engine (rclone) ═════════════════════════════
async function runUploadProcess({ zipPath, remote, driveFolder, targetDrivePath, parallel, filterIds, job, profile, store }) {
  const startTime = Date.now();
  sendSSE(profile.id, 'log', { message: 'Menyiapkan berkas dari ZIP…', level: 'info' });

  let zip;
  try {
    zip = new AdmZip(zipPath);
  } catch (e) {
    gagalkanJob(job, profile.id, `Gagal membuka berkas ZIP: ${e.message}`);
    return;
  }

  const semuaBerkas = susunBerkasZip(zip.getEntries());
  const allItems = semuaBerkas.map((item) => ({
    id: item.id, entryName: item.entryName, originalName: item.originalName,
    relativePath: item.relativePath, driveName: item.driveName, sizeBytes: item.size,
    status: 'pending', link: '', error: '',
  }));

  const itemsToUpload = filterIds && Array.isArray(filterIds)
    ? allItems.filter((it) => filterIds.includes(it.id))
    : allItems;

  const totalFiles = itemsToUpload.length;
  if (totalFiles === 0) {
    gagalkanJob(job, profile.id, 'Tidak ada berkas yang bisa diunggah dari ZIP ini.');
    return;
  }
  job.state = {
    jobId: job.id,
    folder: driveFolder,
    parallel,
    total: totalFiles,
    completed: 0,
    percent: 0,
    running: true,
    done: false,
    items: itemsToUpload.map((it) => ({
      id: it.id, originalName: it.originalName, relativePath: it.relativePath,
      driveName: it.driveName, sizeBytes: it.sizeBytes, status: it.status,
      link: '', error: '',
    })),
    result: null,
    error: '',
  };
  sendSSE(profile.id, 'init', {
    jobId: job.id, totalFiles, parallel, driveFolder, targetDrivePath,
    items: itemsToUpload.map((it) => ({
      id: it.id, originalName: it.originalName, relativePath: it.relativePath,
      driveName: it.driveName, sizeBytes: it.sizeBytes, status: it.status,
    })),
  });

  const stageDir = path.join(os.tmpdir(), `ckp_stage_${Date.now()}`);
  fs.mkdirSync(stageDir, { recursive: true });
  sendSSE(profile.id, 'log', { message: `Mengekstrak ${totalFiles} berkas ke folder staging…`, level: 'info' });
  try {
    for (const item of itemsToUpload) {
      const entry = zip.getEntry(item.entryName);
      if (entry) fs.writeFileSync(path.join(stageDir, item.driveName), entry.getData());
    }
  } catch (err) {
    try { fs.rmSync(stageDir, { recursive: true, force: true }); } catch (e) { /* abaikan */ }
    gagalkanJob(job, profile.id, `Gagal mengekstrak isi ZIP: ${err.message}`);
    return;
  }

  sendSSE(profile.id, 'log', { message: `Mengunggah ${totalFiles} berkas ke Drive (${parallel}x paralel)…`, level: 'info' });

  // Flag di bawah ini fokus pada throughput: transfer paralel, tanpa pemindaian
  // ulang folder tujuan, chunk besar agar berkas besar tidak dipecah terlalu
  // banyak request, retry otomatis, dan pacer yang tetap aman dari rate limit.
  const copyArgs = [
    'copy', stageDir, targetDrivePath,
    '--transfers', String(parallel),
    '--checkers', String(Math.max(8, parallel * 2)),
    '--drive-chunk-size', '64M',
    '--drive-upload-cutoff', '64M',
    '--buffer-size', '32M',
    '--no-traverse',
    '--retries', '3',
    '--retries-sleep', '2s',
    '--low-level-retries', '20',
    '--drive-skip-shortcuts',
    '--drive-skip-dangling-shortcuts',
    '--drive-pacer-min-sleep', '10ms',
    '--drive-pacer-burst', '200',
    '--stats', '500ms',
    '--stats-one-line',
    '-v',
  ];

  let completedCount = 0;
  const copiedFiles = new Set();
  const fileErrors = new Map();
  const semuaOutput = { out: '', err: '' };
  let spawnError = '';

  const copyExitCode = await new Promise((resolve) => {
    const copyProc = spawn(RCLONE_EXE, copyArgs, { windowsHide: true });
    job.proc = copyProc;
    // Buffer terpisah untuk stdout & stderr. Kalau digabung, potongan baris
    // dari dua stream bisa saling menyisip dan membuat nama berkas salah baca.
    const buffers = { out: '', err: '' };
    const prosesBaris = (rawLine) => {
      const line = rawLine.trim();
      if (!line) return;
      const copiedMatch = line.match(/INFO\s+:\s+(.+?):\s+Copied/);
      if (copiedMatch) {
        const finishedName = copiedMatch[1].trim();
        if (!copiedFiles.has(finishedName)) {
          copiedFiles.add(finishedName);
          completedCount++;
          const matchedItem = itemsToUpload.find((it) => it.driveName === finishedName);
          const itemId = matchedItem ? matchedItem.id : completedCount;
          const originalName = matchedItem ? matchedItem.originalName : finishedName;
          const percent = Math.round((completedCount / Math.max(1, totalFiles)) * 100);
          if (job.state) {
            job.state.completed = completedCount;
            job.state.percent = percent;
            const baris = job.state.items.find((x) => x.id === itemId);
            if (baris) baris.status = 'success';
          }
          sendSSE(profile.id, 'file_start', { id: itemId, originalName });
          sendSSE(profile.id, 'file_complete', {
            id: itemId, originalName, driveName: finishedName, status: 'success',
            completedCount, totalFiles, percent,
          });
          sendSSE(profile.id, 'log', { message: `[${completedCount}/${totalFiles}] Terunggah: ${originalName}`, level: 'success' });
        }
      }
      const errorMatch = line.match(/ERROR\s+:\s+(.+?):\s+Failed to copy:\s+(.+)/);
      if (errorMatch) {
        const failedName = errorMatch[1].trim();
        const errReason = cleanRcloneError(errorMatch[2].trim());
        fileErrors.set(failedName, errReason);
        completedCount++;
        const matchedItem = itemsToUpload.find((it) => it.driveName === failedName);
        const itemId = matchedItem ? matchedItem.id : completedCount;
        const originalName = matchedItem ? matchedItem.originalName : failedName;
        const percent = Math.round((completedCount / Math.max(1, totalFiles)) * 100);
        if (job.state) {
          job.state.completed = completedCount;
          job.state.percent = percent;
          const baris = job.state.items.find((x) => x.id === itemId);
          if (baris) { baris.status = 'failed'; baris.error = errReason; }
        }
        sendSSE(profile.id, 'file_complete', {
          id: itemId, originalName, driveName: failedName, status: 'failed', error: errReason,
          completedCount, totalFiles, percent,
        });
        sendSSE(profile.id, 'log', { message: `[${completedCount}/${totalFiles}] GAGAL: ${originalName} (${errReason})`, level: 'error' });
      }
      if (line.includes('Transferred:') && line.includes('%')) {
        const percentMatch = line.match(/,\s*(\d+)%/);
        const etaMatch = line.match(/ETA\s+([0-9a-z]+)/i);
        if (percentMatch) {
          sendSSE(profile.id, 'progress_stats', { percent: parseInt(percentMatch[1], 10), eta: etaMatch ? etaMatch[1] : '', raw: line });
        }
      }
    };
    const handleOutput = (key) => (data) => {
      const teks = data.toString();
      semuaOutput[key] += teks;
      buffers[key] += teks;
      const lines = buffers[key].split('\n');
      buffers[key] = lines.pop();
      for (const rawLine of lines) prosesBaris(rawLine);
    };
    copyProc.stdout?.on('data', handleOutput('out'));
    copyProc.stderr?.on('data', handleOutput('err'));
    copyProc.on('close', (code) => {
      // Sisa baris terakhir yang belum berakhiran newline.
      prosesBaris(buffers.out);
      prosesBaris(buffers.err);
      resolve(code);
    });
    copyProc.on('error', (err) => {
      spawnError = err.message;
      sendSSE(profile.id, 'log', { message: `Error proses upload: ${err.message}`, level: 'error' });
      resolve(-1);
    });
  });

  try { fs.rmSync(stageDir, { recursive: true, force: true }); } catch (e) { /* abaikan */ }

  if (job.isCancelled) {
    job.isRunning = false;
    const hasilBatal = {
      jobId: job.id,
      totalFiles, successCount: 0, failedCount: 0, cancelled: true,
      csvPath: '', xlsxPath: '', results: [], elapsedSec: Math.round((Date.now() - startTime) / 1000),
    };
    if (job.state) {
      job.state.done = true;
      job.state.running = false;
      job.state.percent = job.state.percent || 0;
      job.state.result = hasilBatal;
    }
    sendSSE(profile.id, 'done', hasilBatal);
    return;
  }

  // Bila rclone berhenti dengan error (remote salah, token kedaluwarsa, dsb),
  // tampilkan alasannya di UI — jangan hanya "berkas tidak terdeteksi".
  if (copyExitCode !== 0) {
    const alasan = spawnError || cleanRcloneError(semuaOutput.err || semuaOutput.out);
    sendSSE(profile.id, 'log', { message: `rclone berhenti (kode ${copyExitCode}): ${alasan}`, level: 'error' });
    if (!fileErrors.size && !copiedFiles.size) {
      for (const item of itemsToUpload) fileErrors.set(item.driveName, alasan);
    }
  }

  sendSSE(profile.id, 'log', { message: 'Mengambil tautan publik Google Drive…', level: 'info' });
  // Tautan folder dibuat di latar belakang (tidak menahan proses), supaya
  // penerima link bisa membuka berkas tanpa mengubah proses upload.
  const folderSharePath = targetDrivePath.endsWith('/') ? targetDrivePath : `${targetDrivePath}/`;
  runRclone(['link', folderSharePath, '--drive-skip-shortcuts', '--drive-skip-dangling-shortcuts',
    '--drive-pacer-min-sleep', '10ms', '--drive-pacer-burst', '200']).catch(() => {});

  const lsfRes = await runRclone([
    'lsf', targetDrivePath, '--format', 'ip', '--separator', ';', '--files-only',
    '--max-depth', '1',
    '--drive-skip-shortcuts', '--drive-skip-dangling-shortcuts',
    '--drive-pacer-min-sleep', '10ms', '--drive-pacer-burst', '200',
  ]);

  const fileIdMap = new Map();
  const lsfError = lsfRes.code === 0 ? '' : cleanRcloneError(lsfRes.stderr);
  if (lsfRes.code === 0 && lsfRes.stdout) {
    for (const rawLine of lsfRes.stdout.split('\n')) {
      const line = rawLine.trim();
      if (!line || line.startsWith('NOTICE:')) continue;
      const parts = line.split(';');
      if (parts.length >= 2) {
        const id = parts[0].trim();
        const fileName = parts.slice(1).join(';').trim();
        if (id && fileName) fileIdMap.set(fileName, id);
      }
    }
  }

  const results = [];
  let successCount = 0;
  let failedCount = 0;
  for (const item of itemsToUpload) {
    const driveId = fileIdMap.get(item.driveName);
    const hasError = fileErrors.has(item.driveName);
    if (driveId && !hasError) {
      item.status = 'success'; item.link = `https://drive.google.com/open?id=${driveId}`; item.error = ''; successCount++;
    } else if (copiedFiles.has(item.driveName) && driveId) {
      item.status = 'success'; item.link = `https://drive.google.com/open?id=${driveId}`; item.error = ''; successCount++;
    } else if (copiedFiles.has(item.driveName) && !driveId) {
      item.status = 'success';
      item.link = `https://drive.google.com/drive/search?q=${encodeURIComponent(item.driveName)}`;
      item.error = ''; successCount++;
    } else {
      item.status = 'failed'; item.link = '';
      item.error = fileErrors.get(item.driveName)
        || (lsfError ? `Gagal membaca folder Drive: ${lsfError}` : 'Berkas tidak terdeteksi di Google Drive');
      failedCount++;
    }
    results.push(item);
  }

  // Laporan cadangan (format lama, tetap berguna)
  const zipStem = path.basename(zipPath, path.extname(zipPath)).replace(/^\d+_/, '');
  let reportPaths = { csvPath: '', xlsxPath: '' };
  try {
    reportPaths = await generateReports(results, store.dirs.link, zipStem);
    sendSSE(profile.id, 'log', { message: `Laporan tersimpan: ${reportPaths.xlsxPath}`, level: 'info' });
  } catch (err) {
    sendSSE(profile.id, 'log', { message: `Gagal membuat laporan: ${err.message}`, level: 'error' });
  }

  job.isRunning = false;
  const payload = {
    jobId: job.id,
    totalFiles, successCount, failedCount,
    csvPath: reportPaths.csvPath, xlsxPath: reportPaths.xlsxPath,
    results, elapsedSec: Math.round((Date.now() - startTime) / 1000),
    isCancelled: job.isCancelled,
  };
  if (job.state) {
    job.state.done = true;
    job.state.running = false;
    job.state.completed = totalFiles;
    job.state.percent = 100;
    job.state.items = results.map((r) => ({
      id: r.id, originalName: r.originalName, relativePath: r.relativePath,
      driveName: r.driveName, sizeBytes: r.sizeBytes, status: r.status,
      link: r.link || '', error: r.error || '',
    }));
    job.state.result = payload;
  }
  sendSSE(profile.id, 'done', payload);
}

async function generateReports(results, outputDir, zipStem) {
  const headers = ['nama_file_asli', 'path_relatif', 'nama_di_drive', 'ukuran_bytes', 'status', 'link', 'error'];
  let csvFileName = `hasil_${zipStem}.csv`;
  let csvPath = path.join(outputDir, csvFileName);
  let csvCounter = 1;
  while (true) {
    try { const h = fs.openSync(csvPath, 'w'); fs.closeSync(h); break; }
    catch (e) { csvFileName = `hasil_${zipStem}_${csvCounter++}.csv`; csvPath = path.join(outputDir, csvFileName); }
  }
  const csvRows = [headers.join(',')];
  for (const r of results) {
    csvRows.push([
      `"${(r.originalName || '').replace(/"/g, '""')}"`,
      `"${(r.relativePath || '').replace(/"/g, '""')}"`,
      `"${(r.driveName || '').replace(/"/g, '""')}"`,
      r.sizeBytes || 0, `"${r.status}"`,
      `"${(r.link || '').replace(/"/g, '""')}"`,
      `"${(r.error || '').replace(/"/g, '""')}"`,
    ].join(','));
  }
  fs.writeFileSync(csvPath, '﻿' + csvRows.join('\r\n'), 'utf8');

  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'CKP App';
  workbook.created = new Date();
  workbook.modified = new Date();
  const worksheet = workbook.addWorksheet('Hasil Upload', { views: [{ showGridLines: true }] });
  worksheet.columns = [
    { header: 'No', key: 'no', width: 6 },
    { header: 'Nama File Asli', key: 'nama_file_asli', width: 32 },
    { header: 'Path Relatif', key: 'path_relatif', width: 36 },
    { header: 'Nama di Drive', key: 'nama_di_drive', width: 34 },
    { header: 'Ukuran (Bytes)', key: 'ukuran_bytes', width: 16 },
    { header: 'Status', key: 'status', width: 14 },
    { header: 'Link Google Drive', key: 'link', width: 48 },
    { header: 'Pesan Error', key: 'error', width: 32 },
  ];
  const headerRow = worksheet.getRow(1);
  headerRow.height = 28;
  headerRow.eachCell((cell) => {
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F766E' } };
    cell.font = { name: 'Segoe UI', size: 11, bold: true, color: { argb: 'FFFFFFFF' } };
    cell.alignment = { vertical: 'middle', horizontal: 'center' };
  });
  results.forEach((r, idx) => {
    const isSuccess = r.status === 'success';
    const row = worksheet.addRow({
      no: idx + 1, nama_file_asli: r.originalName, path_relatif: r.relativePath,
      nama_di_drive: r.driveName, ukuran_bytes: r.sizeBytes,
      status: isSuccess ? 'BERHASIL' : 'GAGAL',
      link: r.link ? { text: r.link, hyperlink: r.link } : '-', error: r.error || '-',
    });
    row.height = 22;
    const rowBg = isSuccess ? 'FFF0FDF4' : 'FFFEE2E2';
    row.eachCell((cell, colNumber) => {
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: rowBg } };
      cell.border = {
        top: { style: 'thin', color: { argb: 'FFE2E8F0' } }, left: { style: 'thin', color: { argb: 'FFE2E8F0' } },
        bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } }, right: { style: 'thin', color: { argb: 'FFE2E8F0' } },
      };
      cell.alignment = { vertical: 'middle' };
      if (colNumber === 1 || colNumber === 6) cell.alignment = { vertical: 'middle', horizontal: 'center' };
      if (colNumber === 6) cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: isSuccess ? 'FF15803D' : 'FFB91C1C' } };
      if (colNumber === 7 && r.link) cell.font = { name: 'Segoe UI', size: 10, color: { argb: 'FF0284C7' }, underline: true };
    });
  });
  let xlsxFileName = `hasil_${zipStem}.xlsx`;
  let xlsxPath = path.join(outputDir, xlsxFileName);
  let xlsxCounter = 1;
  while (true) {
    try { await workbook.xlsx.writeFile(xlsxPath); break; }
    catch (e) { xlsxFileName = `hasil_${zipStem}_${xlsxCounter++}.xlsx`; xlsxPath = path.join(outputDir, xlsxFileName); }
  }
  return { csvPath, xlsxPath };
}

// ─── Start ───────────────────────────────────────────────────────────────────
pastikanProfil();
rekonsiliasiRkSemuaProfil();
const server = app.listen(PORT, HOST, () => {
  const urls = networkUrls(PORT);
  console.log(`\nCKP App berjalan di http://localhost:${PORT}`);
  if (HOST === '0.0.0.0' && urls.length) {
    console.log('Rekan sekantor bisa membuka:');
    urls.forEach((u) => console.log(`  ${u}`));
    console.log('(pastikan Windows Firewall mengizinkan Node.js di jaringan kantor)\n');
  } else {
    console.log('');
  }
});
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.log(`Port ${PORT} sudah dipakai — kemungkinan app sudah berjalan.`);
    process.exit(0);
  } else console.error('Server error:', err);
});
process.on('uncaughtException', (err) => console.error('[UNCAUGHT]', err));
process.on('unhandledRejection', (reason) => console.error('[UNHANDLED]', reason));
